/**
 * Created by sanjay kumar on 25/06/2020..
 */

// Opera 8.0+
var isOpera =
  (!!window.opr && !!opr.addons) ||
  !!window.opera ||
  navigator.userAgent.indexOf(" OPR/") >= 0;

// Firefox 1.0+
var isFirefox = typeof InstallTrigger !== "undefined";

// Safari 3.0+ "[object HTMLElementConstructor]"
var isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

// Edge 20+
var isEdge = window.navigator.userAgent.indexOf("Edg/") > -1 ? true : false;

// Chrome 1 - 71
var isChrome =
  !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);

// var reviewLink = document.querySelector(".review-link");
var modalReviewLink1 = document.querySelector(".modalReviewLink1");
var modalReviewLink2 = document.querySelector(".modalReviewLink2");
var linkValue = "https://bit.ly/SelectorsHub-Review";

var newFeatureLaunch = document.querySelector("#newFeatureLaunch");
var newFeatureLink = "https://bit.ly/tcs_chrome";

// https://shubads.testcasehub.net/
const API_URL = "https://testshubads.testcasehub.net/";
// const API_URL = "https://shubads.testcasehub.net/";
// const API_URL = "http://localhost:4000/";
const EXT_ID = "1";
const TOP_EXT_ID = "12";
const OFFER_EXT_ID = API_URL === "https://shubads.testcasehub.net/" ? 13 : 7;

// const OFFER_EXT_ID = 13;

let platform = "";
var browserType = chrome;
if (isChrome) {
  //reviewLink.setAttribute("href","https://addons.mozilla.org/en-US/firefox/addon/testcase-studio/");
  platform = "chrome";
}
if (isFirefox) {
  linkValue =
    "https://addons.mozilla.org/en-US/firefox/addon/selectorshub/reviews/";
  newFeatureLink =
    "https://addons.mozilla.org/en-US/firefox/addon/testcase-studio/";
  //reviewLink.setAttribute("href","https://addons.mozilla.org/en-US/firefox/addon/selectorshub/");
  platform = "firefox";
  document.querySelector("body").style.fontFamily =
    "RooneySans-Regular, Lucida Grande, Lucida Sans Unicode, Trebuchet MS, sans-serif";
  document.querySelector("#selectorsHubEleContainer").style.fontSize = "12px";
}

if (isOpera) {
  platform = "opera";
  linkValue = "https://addons.opera.com/en-gb/extensions/details/selectorshub/";
  //reviewLink.setAttribute("href","https://addons.opera.com/en-gb/extensions/details/selectorshub/");
  newFeatureLink =
    "https://addons.opera.com/en-gb/extensions/details/testcase-studio/";
}

if (isEdge) {
  platform = "edge";
  linkValue =
    "https://microsoftedge.microsoft.com/addons/detail/selectorshub/iklfpdeiaeeookjohbiblmkffnhdippe";
  newFeatureLink =
    "https://microsoftedge.microsoft.com/addons/detail/testcase-studio/jdglgpgchkgiciogpolofelfdfkdgfcg";
  //reviewLink.setAttribute("href","https://microsoftedge.microsoft.com/addons/detail/selectorshub/iklfpdeiaeeookjohbiblmkffnhdippe");
}

let isSidePanelView = false;
let unavailableDevtoolsApi = !browserType.devtools;
if (unavailableDevtoolsApi) isSidePanelView = true;

let countryName = null;

if (Intl) {
  let userCity;
  let userTimeZone;

  userTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  let tzArr = userTimeZone.split("/");
  userCity = tzArr[tzArr.length - 1];
  countryName = COUNTRIES[userCity];
}

trackEvent("open extension");
// document.querySelector(".requestHeader.review").setAttribute("href", linkValue);

// reviewLink.setAttribute("href", linkValue);
modalReviewLink2.setAttribute("href", linkValue);

// newFeatureLaunch.setAttribute("href", newFeatureLink);

const getActiveTabId = async () => {
  let tab = await browserType.tabs.query({
    active: true,
    currentWindow: true,
  });
  return tab[0].id;
};

function postSafeMessage(message){
  try{
      connectBackgroundPage.postMessage(message);
  }catch(_){
  }
}

var connectBackgroundPage = browserType.runtime.connect({
  name: "devtools-page",
});

if (isSidePanelView) {
  getActiveTabId().then((tabId) => {
    postSafeMessage({ name: "tag-element", query: "body", tabId });

    postSafeMessage({
      name: "init",
      tabId,
      contentScript: "../content-script/contentScript.js",
      contentCSS: "../content-script/contentScript.css",
    });
  });
} else {
  postSafeMessage({
    name: "init",
    tabId: browserType.devtools.inspectedWindow.tabId,
    contentScript: "../content-script/contentScript.js",
    contentCSS: "../content-script/contentScript.css",
  });

  postSafeMessage({
    name: "block-side-panel",
    tabId: browserType.devtools.inspectedWindow.tabId,
    isDevtoolsOpen: true,
  });
}

window.addEventListener("beforeunload", async (e) => {
  if(!isSidePanelView){
      postSafeMessage({ name: "block-side-panel", tabId: browserType.devtools.inspectedWindow.tabId, isDevtoolsOpen: false });
      if(inspectorActivated){
          browserType.devtools.inspectedWindow.eval("desactivateInspector()", { useContentScriptContext: true });
      }
  }else{
      let tabId = await getActiveTabId();
      postSafeMessage({ name: "desactivate-inspector", tabId });
  }
})

var openedRecorder = false;
var openUploadModal = false;
var userEmail = "Anonymous";
var SMsteps = [];
var SMstepsWithOutCmd = [];
var CPstepsWithOutCmd = [];
var CPsteps = [];

var quotes = document.querySelector(".quotes-btn");
var quotesBtn = isSidePanelView ? document.querySelector(".quotes-btn-c") : quotes;

var smartFixPlaceholder =
  "1. Open the page where XPaths need to be verified.\r\n2. Click on Editor icon (above in header).\r\n3. Set the XPath driver command.\r\n4. Paste the selectors page or complete script in the box.\r\n5. Click on Submit.\r\n6. SH will list all the xpaths with their occurrences.\r\n7. You can also download the XPath file.";

if(!isSidePanelView){
  var themeName = window.browserType.devtools.panels.themeName;
  var iconColor = "grey";
  if (themeName === "dark") {
    document.querySelector("#cssFile").setAttribute("href", "darkTheme.css");
    iconColor = "yellow";
  } else {
    document.querySelector("#cssFile").setAttribute("href", "lightTheme.css");
    iconColor = "black";
  }
}

var OS = window.navigator.userAgent.includes("Mac") ? "mac" : "windows";
var browserLang = window.navigator.language;
var relXpathMatchingNodeLeft = "6px";
var attrCheckbox = document.querySelectorAll(".chooseAttr");
var eleContainerHeight = 0;
if(!isSidePanelView){
  var totalCountMargin = isFirefox ? "39px" : "7px";
  var totalCountMarginIframe = isFirefox ? "40px" : "2px";
  var totalCountMarginFrame = isFirefox ? "37px" : "2px";
  var totalCountMarginShadow = isFirefox ? "70px" : "17px";
  var totalCountMarginSvg = isFirefox ? "61px" : "8px";
}
var selectorEditBoxWidth = "calc(100% - 128px)";
var selectorEditBoxWidthShadow = "calc(100% - 138px)";
var toggleElement = document.querySelector(".toggle-btn");
// var form=document.getElementById("register_form");
// var email=document.getElementById("email");
// var pass=document.getElementById("password");
// var company=document.getElementById("company");
// var registerBtn=document.getElementById("submit_btn");
// var loginLink=document.getElementById("login_a");
// var spanLogin=document.getElementById("login");
if (OS.includes("mac")) {
  selectorEditBoxWidth = "calc(100% - 128px)";
  document.querySelector(".selector-editor-div").style.width =
    selectorEditBoxWidth;
  document.querySelector(".chooseAttr.user").style.width = isFirefox
    ? "calc(100% - 367px)"
    : "calc(100% - 460px)";
  document.querySelector("label").style.margin = "4px 6px 3px 4px";
  // document.querySelector(".id-xpath").style.margin = '0px 0px 0px 8px';
  //document.querySelector(".editorTitle").style.margin = isFirefox ? "3px 2px 0px 0px" : '0px 2px 0px 0px';
  var editorContent = document.querySelector(".editorContent");
  editorContent.style.padding = isFirefox
    ? "2px 1px 3px 3px"
    : "3px 1px 3px 3px";

  relXpathMatchingNodeLeft = "6px";
  // document.querySelector(".toggle-btn").style.margin = "-5px 6px 0px 31px";
  document.querySelector(".toggle-btn").style.lineHeight = "30px";
  document.querySelectorAll(".chooseAttr");
  // for(var i=0; i<attrCheckbox.length; i++){
  //     attrCheckbox[i].style.verticalAlign = "middle";
  // }
  document.querySelector(".uploadModalIcon").innerText =
    "click to upload downloaded xpath xls file.";
  eleContainerHeight = "calc(100% - 85px)";
  totalCountMargin = isFirefox ? "8px" : "7px";
  totalCountMarginIframe = isFirefox ? "3px" : "2px";
  totalCountMarginFrame = isFirefox ? "3px" : "2px";
  totalCountMarginShadow = isFirefox ? "18px" : "17px";
  totalCountMarginSvg = isFirefox ? "9px" : "8px";

  selectorEditBoxWidthShadow = "calc(100% - 138px)";

  if (browserLang.includes("zh")) {
    //this is fix for chinese language...chinese language code is zh
    var autosuggestToggleBtn = document.querySelector(
      ".autosuggest-toggle-btn"
    );
    var autosuggestToggleCircle = document.querySelector(
      ".autosuggest-toggle-circle"
    );

    var toggleBtn = document.querySelector(".toggle-btn");
    var toggleCircle = document.querySelector(".toggle-circle");

    autosuggestToggleBtn.style.width = "34px";
    autosuggestToggleCircle.style.marginLeft = "5px";

    toggleBtn.style.width = "34px";
    toggleCircle.style.marginLeft = "5px";

    totalCountMargin = "32px";

    editorContent.style.padding = "1px 1px 3px 3px";
  }
} else {
  var toggleBtn = document.querySelector(".toggle-btn");
  selectorEditBoxWidth = isFirefox
    ? "calc(100% - 130px)"
    : "calc(100% - 134px)";
  document.querySelector(".selector-editor-div").style.width =
    selectorEditBoxWidth;
  // document.querySelector(".chooseAttr.user").style.width = isFirefox
  //   ? "calc(100% - 367px)"
  //   : "calc(100% - 445px)";
  document.querySelector("label").style.margin = "4px 0px 3px 6px";
  // document.querySelector(".id-xpath").style.margin = '0px 0px 0px 12px';
  document.querySelector(".editorHeader").style.padding = isFirefox
    ? "5px 5px 12px 5px"
    : "6px 5px 9px 5px";
  //document.querySelector(".editorTitle").style.margin = isFirefox ? "0px 2px 0px 0px" : '0px 0px 2px 0px';
  //document.querySelector(".editorTitle").style.padding = "3px 3px 5px 3px";
  relXpathMatchingNodeLeft = "-16px";
  toggleBtn.style.marginLeft = isFirefox
    ? "calc(100% - 34px)"
    : "calc(100% - 39px)";
  toggleBtn.style.lineHeight = "29px";
  toggleBtn.style.marginTop = "-18px";
  var typeOfLocator = document.querySelectorAll(".typeOfLocator");
  var noOfMatch = document.querySelectorAll(".noOfMatch");
  var selectorsCopyBtn = document.querySelectorAll("button.copy-btn");

  for (var i = 0; i < typeOfLocator.length - 1; i++) {
    typeOfLocator[i].style.verticalAlign = "super";
    noOfMatch[i].style.verticalAlign = "super";
    noOfMatch[i].style.padding = isFirefox
      ? "0px 4px 0px 4px"
      : "0px 5px 0px 4px";
    selectorsCopyBtn[i].style.verticalAlign = isFirefox
      ? "text-top"
      : "inherit";
  }

  document.querySelector(".uploadModalIcon").innerText =
    "click to upload downloaded xpath csv file.";
  eleContainerHeight = isFirefox ? "calc(100% - 89px)" : "calc(100% - 86px)";
  if(!isSidePanelView){
    totalCountMargin = isFirefox ? "18px" : "10px";
    totalCountMarginIframe = isFirefox ? "10px" : "5px";
    totalCountMarginFrame = isFirefox ? "9px" : "5px";
    totalCountMarginShadow = isFirefox ? "27px" : "19px";
    totalCountMarginSvg = isFirefox ? "20px" : "12px";
  }

  document.querySelector(".configContainer").style.marginTop = isFirefox
    ? "1px"
    : "2px";
  document.querySelector(".editorContent").style.fontFamily = "inherit";
  selectorEditBoxWidthShadow = isFirefox
    ? "calc(100% - 137px)"
    : "calc(100% - 143px)";
  var errorInfo = document.querySelector(".errorInfo");
  errorInfo.style.padding = isFirefox ? "2px 5px" : "2px 5px";
  var cheetSheet = document.querySelector(".cheetSheet");
  cheetSheet.style.marginTop = isFirefox ? "4px" : "2px";

  document.querySelector(".ignoreCaseBtn").style.marginTop = isFirefox
    ? "-27px"
    : "-18px";
  // document.querySelector(".configOptions").style.marginTop = "-122px";

  var autoSuggestTop = isFirefox ? "32" : "30";
  var autosuggestToggleBtn = document.querySelector(".autosuggest-toggle-btn");
  autosuggestToggleBtn.style.setProperty("--top", autoSuggestTop);
  autosuggestToggleBtn.style.verticalAlign = "middle";

  var toggleTop = isFirefox ? "31" : "29";
  document.querySelector(".toggle-btn").style.setProperty("--top", toggleTop);

  // var attributeFilter = document.querySelector(".attributeFilter");
  // attributeFilter.style.height = isFirefox ? "26px" : "25px";

  var nestedCodeCopyBtn = document.querySelector(".nestedCodeCopyBtn");
  nestedCodeCopyBtn.style.verticalAlign = isFirefox ? "top" : "bottom";

  var axesBtn = document.querySelector(".axes-btn");
  axesBtn.style.verticalAlign = "middle";
  var totalCountMessage = document.querySelector(".total-match-count");
  totalCountMessage.style.verticalAlign = "middle";
  var errorInfo = document.querySelector(".errorInfo");
  errorInfo.style.verticalAlign = "middle";
  // document.querySelector(".donation-btn").style.marginBottom = isFirefox ? "-22px" : "0px";
}

var showTotalCount = false;
var showTotalResults = function (count) {
  var totalCountElem = document.querySelector(".jsTotalMatchCount");
  var inputBoxValue = document.querySelector(".jsSelector").value;
  var errorInfo = document.querySelector(".errorInfo");
  var cheetSheetLink = document.querySelector(".cheetSheetLink");
  let fixSelectorBtn = document.querySelector("#fix-selector");

  if (inputBoxValue) {
    totalCountElem.style.padding = OS.includes("mac")
      ? "2px 5px"
      : isFirefox
      ? "2px 5px"
      : "2px 5px";
  } else {
    totalCountElem.style.padding = "0px 0px 0px 0px";
  }
  try {
    if (
      !showTotalCount ||
      count.includes("blank") ||
      (count.length === 1 &&
        multiSelectorRecord.className.includes("red")) ||
      !inputBoxValue
    ) {
      totalCountElem.className += " hideMatchCountMsg";
      errorInfo.className += " hideMatchCountMsg";
      fixSelectorBtn.className = "hideMatchCountMsg fix-selector-success";
      fixSelectorBtn.children[1].innerText = "Fix Selector";
      cheetSheetLink.className += " hideMatchCountMsg";
    } else {
      // totalCountElem.style.padding = "1px 3px 0px 4px";
      totalCountElem.classList.remove("hideMatchCountMsg");
      errorInfo.className += " hideMatchCountMsg";
      cheetSheetLink.className += " hideMatchCountMsg";
      var xpathValue = document.querySelector(".jsSelector").value;
      if (count.includes("wrong")) {
        errorInfo.classList.remove("hideMatchCountMsg");
        fixSelectorBtn.classList.remove("hideMatchCountMsg");
        cheetSheetLink.classList.remove("hideMatchCountMsg");
        totalCountElem.style.background = "red";
        totalCountElem.textContent =
          "Invalid " + count.split("wrong")[1].split("errorInfo")[0];
        if (count.split("errorInfo")[1]) {
          errorInfo.textContent = count.split("errorInfo")[1];
          errorInfo.setAttribute("title", count.split("errorInfo")[1]);
        } else {
          errorInfo.className += " hideMatchCountMsg";
          fixSelectorBtn.className = "hideMatchCountMsg fix-selector-success";
          fixSelectorBtn.children[1].innerText = "Fix Selector";
          cheetSheetLink.className += " hideMatchCountMsg";
        }
      } else if (count.length === 0) {
        totalCountElem.textContent = count.length + " element matching.";
        totalCountElem.style.background = "#f29a00";
      } else if (
        xpathValue === "/" ||
        xpathValue === "." ||
        xpathValue === "/."
      ) {
        totalCountElem.textContent = "It's default DOM.";
        totalCountElem.style.background = "#0cb9a9";
      } else if (xpathValue === "//.") {
        totalCountElem.textContent = count.length + " matching all nodes.";
        totalCountElem.style.background = "#0cb9a9";
      } else {
        if (count.length === 1) {
          totalCountElem.textContent = count.length + " element matching.";
          totalCountElem.style.background = "#0cb9a9";
        } else {
          totalCountElem.textContent = count.length + " elements matching.";
          totalCountElem.style.background = "#f29a00";
        }
      }
    }
  } catch (err) {
    console.log(err);
  }
  showTotalCount = false;
};

var highlighter = function (ele) {
  var xpathOrCss = "";
  var inputBoxValue = document.querySelector(".jsSelector").value;
  if (
    !insideShadowDom &&
    (!document.querySelector(".jsSelector").value ||
      inputBoxValue.charAt(0).includes("/") ||
      ele.hasAttribute("xpath"))
  ) {
    xpathOrCss = "xpath";
  } else {
    xpathOrCss = "css";
  }

  xpathOrCss = insideShadowDom ? "css" : xpathOrCss;
  var eleIndex = ele.getAttribute(xpathOrCss);
  let message = { name: xpathOrCss, index: eleIndex };
  message = JSON.stringify(message);

  if(isSidePanelView){
    getActiveTabId().then((tabId) => {
      postSafeMessage({
              name: xpathOrCss,
              tabId,
              index: eleIndex,
              isSidePanel: true
      })
    });
  }else{
    browserType.devtools.inspectedWindow.eval(
      "outlineOnHover(`" + message + "`)",
      { useContentScriptContext: true }
    );
  }

  // connectBackgroundPage.postMessage({
  //         name: xpathOrCss,
  //         tabId: browserType.devtools.inspectedWindow.tabId,
  //         index: eleIndex
  // })
};

var removeHighlighter = function (ele) {
  var xpathOrCss = "";
  var inputBoxValue = document.querySelector(".jsSelector").value;

  if (
    !insideShadowDom &&
    (!inputBoxValue ||
      inputBoxValue.charAt(0).includes("/") ||
      ele.hasAttribute("xpath"))
  ) {
    xpathOrCss = "xpath";
  } else {
    xpathOrCss = "css";
  }
  xpathOrCss = insideShadowDom ? "css" : xpathOrCss;
  var eleIndex = ele.getAttribute(xpathOrCss);

  xpathOrCss = xpathOrCss + "-remove";

  let message = { name: xpathOrCss, index: eleIndex };
  message = JSON.stringify(message);

  if(isSidePanelView){
    getActiveTabId().then(tabId => {
        postSafeMessage({
            name: xpathOrCss,
            tabId,
            index: eleIndex
        })
    })
}else{
  browserType.devtools.inspectedWindow.eval(
    "outlineOnHover(`" + message + "`)",
    { useContentScriptContext: true });
}

  // connectBackgroundPage.postMessage({
  //         name: xpathOrCss+"-remove",
  //         tabId: browserType.devtools.inspectedWindow.tabId,
  //         index: eleIndex
  // })
};

let fixTries = 0;
const selectorInput = document.querySelector(".jsSelector");
let fixSelectorBtn = document.querySelector("#fix-selector");

function correctSelectorValue(selector) {
  if (selector && selector != "undefined") {
    selectorInput.value = selector;
    showTotalCount = true;
    selectElements("xpath", true);
    fixSelectorBtn.className = "hideMatchCountMsg fix-selector-success";
    fixSelectorBtn.children[1].innerText = "Fix Selector";
    fixTries = 0;
  } else {
    fixSelectorBtn.className = "fix-selector-wrong";
    if (fixTries < 2) {
      fixSelectorBtn.children[1].innerText = "Try again";
    } else {
      fixSelectorBtn.className += " btn-disabled";
      fixSelectorBtn.children[1].innerText = "Couldn't fix selector";
    }
  }
}

function localSelectorFix(selector, xpathOrCss) {
  if (!selectorInput.value || selectorInput.value.charAt(0).includes("/")) {
    xpathOrCss = "xpath";
  } else {
    xpathOrCss = "css";
  }
  xpathOrCss = insideShadowDom ? "css" : xpathOrCss;

  if (isSidePanelView) {
    // postSafeMessage({
    //   name: "fix-selector",
    //   xpathOrCss,
    //   selector,
    //   tabId: chrome.devtools.inspectedWindow.tabId,
    // });
    getActiveTabId().then((tabId) => {
      postSafeMessage({
          name: "fix-selector",
          xpathOrCss,
          selector,
          tabId
      })
    })
  } else {
    chrome.devtools.inspectedWindow.eval(
      "fullFixSelector(`" + xpathOrCss + "`, `" + selector + "`)",
      { useContentScriptContext: true },
      (result) => {
        correctSelectorValue(result);
      }
    );
  }
}

let forGPT = false;

fixSelectorBtn.addEventListener("click", async () => {
  let xpathOrCss = "";
  fixTries++;
  if (fixTries < 3) {
    fixSelectorBtn.className = "fix-selector-success";
    fixSelectorBtn.children[1].innerText = "Fixing...";

    if (!selectorInput.value || selectorInput.value.charAt(0).includes("/")) {
      xpathOrCss = "xpath";
    } else {
      xpathOrCss = "css";
    }
    xpathOrCss = insideShadowDom ? "css" : xpathOrCss;

    // chat gpt fix
    try {
      const response = await fetch(API_URL + "gpt/fixpath", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          xpath: selectorInput.value,
          xpathOrCss,
        }),
      });
      if (response.status >= 400) {
        // local fix
        localSelectorFix(selectorInput.value);
        return;
      }

      const data = await response.json();
      if (data.error) {
        localSelectorFix(selectorInput.value);
        return;
      }

      forGPT = true;

      if (isSidePanelView) {
        // postSafeMessage({
        //   name: "check-invalid-selector",
        //   xpathValue: data.fix,
        //   tabId: browserType.devtools.inspectedWindow.tabId,
        // });
        let tabId = await getActiveTabId();
        postSafeMessage({
            name: "check-invalid-selector",
            xpathValue: data.fix,
            tabId: tabId
        })
      } else {
        browserType.devtools.inspectedWindow.eval(
          "checkInvalidSelector(`" + data.fix + "`)",
          { useContentScriptContext: true },
          function (result) {
            if (result) {
              localSelectorFix(selectorInput.value);
              return;
            } else {
              correctSelectorValue(data.fix);
            }
          }
        );
      }
    } catch (_) {
      localSelectorFix(selectorInput.value);
    }
  }
});

let toggleInspector = () => {};

let inspectorActivated = false;
if(isSidePanelView){
  const inspectorBtn = document.querySelector(".insp-tool");
  
  toggleInspector = async () => {
      inspectorActivated = !inspectorActivated;
      let tabId = await getActiveTabId();
  
      if(inspectorActivated){
        inspectorBtn.children[1].style.background = `url("../icons/inspect_side_panel_yellow.svg") no-repeat center 5px`
        inspectorBtn.children[1].style.backgroundSize = `12px`;
        inspectorBtn.children[1].style.backgroundColor = `black`

        postSafeMessage({
            tabId: tabId,
            name: "activate-inspector"
        })
      }else{
        inspectorBtn.children[1].style.background = `url("../icons/inspect_side_panel_black.svg") no-repeat center 5px`
        inspectorBtn.children[1].style.backgroundSize = `12px`;
        inspectorBtn.children[1].style.backgroundColor = `transparent`

        postSafeMessage({
            tabId: tabId,
            name: "desactivate-inspector"
        })
      }
  }
  
  inspectorBtn.addEventListener("click", toggleInspector);
}

var showAllMatchingNode = function (allNode) {
  var nodeDom = document.querySelector("#selectorsHubEleContainer");
  var xpathOrCss = "";
  var inputBoxValue = document.querySelector(".jsSelector").value;
  // var selectorValue = document.querySelector(".valueSelector."+xpathOrCss.substring(0,3)).getAttribute(xpathOrCss.toLowerCase());

  if (!inputBoxValue || inputBoxValue.charAt(0).includes("/")) {
    xpathOrCss = "xpath";
  } else {
    xpathOrCss = "css";
  }
  xpathOrCss = insideShadowDom ? "css" : xpathOrCss;
  nodeDom.innerHTML = "";
  if (allNode != "blank" && allNode[0].includes("<")) {
    for (var i = 1; i <= allNode.length; i++) {
      allNode[i - 1] = allNode[i - 1] ? allNode[i - 1] : "";
      if (allNode[i - 1]) {
        var domStr = allNode[i - 1];
        domStr = domStr.replace(/(\r\n|\n|\r)/gm, ""); //replace new line with blank
        var elementToCreate = "";
        if (domStr.match(/^<td/) || domStr.match(/^<th/)) {
          elementToCreate = "tr";
        } else if (domStr.match(/^<tr/)) {
          elementToCreate = "tbody";
        } else if (domStr.match(/^<tbody/)) {
          elementToCreate = "table";
        } else if (domStr.match(/^<body/)) {
          domStr = domStr
            .replace("<body", "<bodytag")
            .replace("body>", "bodytag>");
          elementToCreate = "li";
        } else if (domStr.match(/^<html/)) {
          domStr = domStr
            .replace("<html", "<htmltag")
            .replace("html>", "htmltag>");
          elementToCreate = "li";
        } else if (domStr.match(/^<head/)) {
          domStr = domStr
            .replace("<head", "<headtag")
            .replace("head>", "headtag>");
          elementToCreate = "li";
        } else if (domStr.match(/^<frame/)) {
          domStr = domStr
            .replace("<frame", "<frametag")
            .replace("frame>", "frametag>");
          elementToCreate = "li";
        } else {
          elementToCreate = "li";
        }
        var dummyElement = createElement(elementToCreate);
        dummyElement.innerHTML = domStr;

        var treeStructure = convertToTreeStructure(
          dummyElement,
          "parent closed"
        );
        treeStructure.setAttribute(xpathOrCss, i);
        nodeDom.appendChild(treeStructure);

        //this is to highlight in orangered color on mouse hover
        treeStructure.onmouseover = function () {
          highlighter(this);
        };
        treeStructure.onmouseout = function () {
          removeHighlighter(this);
        };
      }
    }
  } else {
    for (var i = 1; i <= allNode.length; i++) {
      var dummyElement = createElement(elementToCreate);
      dummyElement.innerHTML = allNode[i - 1];

      var treeStructure = convertToTreeStructure(dummyElement, "parent closed");
      treeStructure.setAttribute(xpathOrCss, i);
      nodeDom.appendChild(treeStructure);
    }
  }
};

var createDummyElement = function () {
  var domStr = "<nav></nav>";
  var dummyElement = createElement("div");
  dummyElement.innerHTML = domStr;
  var resultElem = document.querySelector(".result");
  var treeStructure = convertToTreeStructure(
    dummyElement,
    "parent closed",
    domStr
  );
  resultElem.appendChild(treeStructure);
};

var selectElements = function (xpathOrCss, onChange) {
  chooseAttrsOption();
  var val = "";

  if (!onChange) {
    xpathOrCss = xpathOrCss.toLowerCase().includes("xpath")
      ? "relXpath"
      : xpathOrCss;
    val = document
      .querySelector(".valueSelector." + xpathOrCss.substring(0, 3))
      .getAttribute(xpathOrCss.toLowerCase());
  } else {
    val = document.querySelector(".jsSelector").value;
  }

  clearElements();

  if(isSidePanelView){
    getActiveTabId().then(tabId => {
        postSafeMessage({
            name: "highlight-element",
            tabId,
            xpathOrCss,
            val,
            onChange,
            chooseAttrs
        }); 
    })
  }else{
    browserType.devtools.inspectedWindow.eval(
      "verifyXpathSelectors(`highlight-element`,`" +
        xpathOrCss +
        "`,`" +
        val +
        "`,`" +
        onChange +
        "`,`" +
        chooseAttrs +
        "`)",
      { useContentScriptContext: true },
    function (result) {
      receiveXpathResults(result);
    });
  }
};

var secondPageUrl = "xyz";
var insideShadowDom = false;
var insideFrame = false;
var bothListOfTextAndAttr = [];
var listOfTextAndAttr = [];
var shadowHostSelector = "";
var nestedBlockOn = "no";

function assignSelectorsValue(xpath) {
  var relXpathContainer = document.querySelector(".selectorsRow.relXpath");
  var indexXpathContainer = document.querySelector(".selectorsRow.indexXpath");
  var cssSelectorContainer = document.querySelector(
    ".selectorsRow.cssSelector"
  );
  var jsPathContainer = document.querySelector(".selectorsRow.jsPath");
  var jQueryContainer = document.querySelector(".selectorsRow.jQuery");
  var idContainer = document.querySelector(".selectorsRow.id");
  var nameContainer = document.querySelector(".selectorsRow.name");

  var classNameContainer = document.querySelector(".selectorsRow.className");

  var linkTextContainer = document.querySelector(".selectorsRow.linkText");
  var partialLinkTextContainer = document.querySelector(
    ".selectorsRow.partialLinkText"
  );
  var absXpathContainer = document.querySelector(".selectorsRow.absXpath");
  var tagNameContainer = document.querySelector(".selectorsRow.tagName");
  var testRigorPathContainer = document.querySelector(
    ".selectorsRow.testRigorPath"
  );

  relXpathWithCount = xpath[0];
  cssSelectorWithCount = xpath[1];

  if (quotes.classList.contains("active")) {
    relXpathWithCount[0] = relXpathWithCount[0].replaceAll(`'`, `"`);
    cssSelectorWithCount[0] = cssSelectorWithCount[0].replaceAll(`'`, `"`);
  }
  var cssWithOutCmd = cssSelectorWithCount[0];
  indexXpathWithCount = xpath[2];
  idWithCount = xpath[3];
  nameWithCount = xpath[4];
  classNameWithCount = xpath[5];
  linkTextWithCount = xpath[6];

  partialLinkTextWithCount = xpath[7];
  absXpathWithCount = xpath[8];
  tagNameWithCount = xpath[9];

  if (
    toggleElement.classList.contains("active") &&
    multiSelectorRecord.className.includes("red")
  ) {
    label = xpath[10];
  }

  if (xpath[11]) {
    shadowHostSelector = xpath[11][0];
  }

  testRigorPathWithCount = xpath[12];

  toggleElement = document.querySelector(".toggle-btn");
  //addRow(); //to add row while multiselector generation
  if (toggleElement.classList.contains("active")) {
    var inputBox = document.querySelector(".jsSelector");
    // var xpathOrCss = "xpath";
    var CopyBtn = document.querySelector(".header-copy-btn");
    inputBox.focus();
    var editorContent = document.querySelector(".editorContent");

    inputBox.setAttribute(
      "placeholder",
      "Write & verify XPath & CSS Selector here......Click on ➕ icon to save value ➡️"
    );

    relXpathWithCount
      ? generateColoredRelXpath()
      : (relXpathContainer.style.display = "none");

    indexXpathWithCount
      ? generateIndexXpath()
      : (indexXpathContainer.style.display = "none");

    //generateCss();
    cssSelectorWithCount
      ? generateCss()
      : (cssSelectorContainer.style.display = "none");
    if (
      cssSelectorWithCount.includes("closed shadow") ||
      !cssSelectorWithCount
    ) {
      jsPathContainer.style.display = "none";
      jQueryContainer.style.display = "none";
    }

    idWithCount ? generateId() : (idContainer.style.display = "none");

    nameWithCount ? generateName() : (nameContainer.style.display = "none");

    classNameWithCount
      ? generateClassName()
      : (classNameContainer.style.display = "none");
    linkTextWithCount
      ? generateLinkText()
      : (linkTextContainer.style.display = "none");
    partialLinkTextWithCount
      ? generatePartialLinkText()
      : (partialLinkTextContainer.style.display = "none");
    absXpathWithCount
      ? generateAbsXpath()
      : (absXpathContainer.style.display = "none");
    tagNameWithCount
      ? generateTagName()
      : (tagNameContainer.style.display = "none");
    testRigorPathWithCount
      ? generateTestRigorPath()
      : (testRigorPathContainer.style.display = "none");

    setTimeout(function () {
      xpathOrCss = insideShadowDom ? "css" : "xpath";
      selectElements(xpathOrCss, false);
    }, 100);

    var nestedBlock = document.querySelector("#nestedBlock");
    var nestedCode = document.querySelector("#nestedCode");

    if (
      !xpath[0][0].includes("closed Shadow DOM") &&
      xpath[11] &&
      !multiSelectorRecord.classList.contains("red") &&
      !smartFix.classList.contains("defaultsmartFix") &&
      !uiSetting.classList.contains("active") &&
      !axesBtn.classList.contains("active")
    ) {
      nestedBlockOn = "yes";
      nestedBlock.style.display = "block";
      var finalScript =
        xpath[11].length == 1
          ? "//This Element is inside single shadow DOM."
          : "//This Element is inside " +
            xpath[11].length +
            " nested shadow DOM.";

      xpath[11].reverse(); //reverse the order of host received.
      var script1,
        script2,
        script3,
        script4,
        script5 = "";
      for (var i = 0; i < xpath[11].length; i++) {
        finalScript =
          finalScript +
          "\n" +
          `String cssSelectorForHost` +
          (i + 1) +
          ` = "` +
          xpath[11][i] +
          `";`;
      }
      finalScript = finalScript + "\n" + "Thread.sleep(1000);";
      if (xpath[11].length == 1) {
        script1 =
          `SearchContext shadow = driver.findElement(By.cssSelector("` +
          xpath[11][0] +
          `")).getShadowRoot();`;
        script2 = `Thread.sleep(1000);`;
        script3 =
          `shadow.findElement(By.cssSelector("` + cssWithOutCmd + `"));`;
        finalScript =
          finalScript + "\n" + script1 + "\n" + script2 + "\n" + script3;
      } else {
        for (var i = 0; i < xpath[11].length; i++) {
          if (i == 0) {
            script1 =
              `SearchContext shadow` +
              i +
              ` = driver.findElement(By.cssSelector("` +
              xpath[11][i] +
              `")).getShadowRoot();`;
          } else {
            script1 =
              `SearchContext shadow` +
              i +
              ` = shadow` +
              (i - 1) +
              `.findElement(By.cssSelector("` +
              xpath[11][i] +
              `")).getShadowRoot();`;
          }
          script2 = `Thread.sleep(1000);`;
          finalScript = finalScript + "\n" + script1 + "\n" + script2;
        }
        var script3 =
          `shadow` +
          (xpath[11].length - 1) +
          `.findElement(By.cssSelector("` +
          cssWithOutCmd +
          `"));`;

        finalScript = finalScript + "\n" + script3;
      }
      nestedCode.textContent = finalScript;
    } else {
      nestedCode.textContent = "";
      nestedBlock.style.display = "none";
      nestedBlockOn = "no";
    }
  }
}

let generatorCallback = () => {};

const displayInPOM = () => {
  if(multiSelectorRecord.className.includes("red") && toggleElement.classList.contains("active")){
      nestedBlock.style.display = "none";
      insertRow = true;
      var onChange = false;
      
      chooseAttrsOption();

      var selector = "";
      var tempSelector = "";
      var selectorName = ""; 
      var cssSelector = "";
      var id = "";
      var name = "";
      var className = "";
      var linkText = "";
      var partialLinkText = "";
      var tagName = "";
      var cssSelector1 = "";
      generateSelectors(() => {
          //tempSelector = relXpathWithCount[0];
          if(addDriverCommand.className.includes('inactive') || !preCommandInput.value.trim()){
              selector = xpathWithoutCommand;
              cssSelector1 = cssSelectorWithoutCommand;
          }else {
              selector = addPreCommandInSelector(xpathWithoutCommand);
              selector = selector.includes("cy.get") ? selector.replace("cy.get","cy.xpath") : selector;
              cssSelector1 = addPreCommandInSelector(cssSelectorWithoutCommand);
              cssSelector1 = cssSelector1.includes("By.xpath")?cssSelector1.replace("By.xpath", "By.cssSelector"):cssSelector1.includes("By(xpath")?cssSelector1.replace("By(xpath", "By(cssSelector"):cssSelector1.includes("ByXPath")?cssSelector1.replace("ByXPath", "ByCssSelector"):cssSelector1.includes("cy.xpath")?cssSelector1.replace("cy.xpath", "cy.get"):cssSelector1.replace("cy.Xpath", "cy.get");
          }
          try{cssSelector = cssSelectorWithCount[0];}catch(err){}
          try{id = idWithCount[0];}catch(err){}
          try{name = nameWithCount[0];}catch(err){}
          try{className = classNameWithCount[0];}catch(err){}
          try{linkText = linkTextWithCount[0];}catch(err){}
          try{partialLinkText = partialLinkTextWithCount[0];}catch(err){}
          try{tagName = tagNameWithCount[0];}catch(err){}

          selectorName = label?label.slice(0, 30):label;
          if(insertRow && multiSelectorRecord.className.includes("red") && toggleElement.classList.contains("active") && selector!==undefined){
              var tempCPstepsWithOutCmd = [];
              tempCPstepsWithOutCmd.push({ selectorName, selector, cssSelector1, idWithoutCommand, nameWithoutCommand, classNameWithoutCommand, linkTextWithoutCommand, partialLinkTextWithoutCommand, tagNameWithoutCommand });
              CPstepsWithOutCmd.push({ selectorName, selector: xpathWithoutCommand, cssSelector1: cssSelectorWithoutCommand, idWithoutCommand, nameWithoutCommand, classNameWithoutCommand, linkTextWithoutCommand, partialLinkTextWithoutCommand, tagNameWithoutCommand });
              CPsteps.push({ selectorName, selector, cssSelector1, id, name, className, linkText, partialLinkText, tagName });
              insRow(tempCPstepsWithOutCmd[0]);
          }
          cssSelectorWithoutCommand = "";
          idWithoutCommand = ""; 
          nameWithoutCommand = "";
          classNameWithoutCommand = "";
          linkTextWithoutCommand = "";
          partialLinkTextWithoutCommand = "";
          tagNameWithoutCommand = "";
      });
  }else{
    generateSelectors();
  }
}

var pageDomainName = "";
var elementInfoContainer = document.querySelector(".elementInfo");

connectBackgroundPage.onMessage.addListener(function (message) {
  if (message.url && !pageDomainName) {
    pageDomainName = message.url.replace(/.+\/\/|www.|\..+/g, "");
  }

  if (message.showInspected) {
    var xpath = message.xpath;
    assignSelectorsValue(xpath);
  }

  // var wrong;
  // var iframe;
  // var notIframe;
  // var iframeXpath;
  // var suggestedSelector;
  // var shadowDom;
  // var textAndAttr;
  // var svgElement;
  // var xpathOrCss = "xpath";
  // var pageReload = "";
  // var sanjayXpathIndex;

  // var userSelectorValue = document.querySelector(".jsSelector").value;
  // var inputBox = document.querySelector(".selectors-input");
  // var selectorEditBox = document.querySelector(".selector-editor-div");
  // var suggestedXpathContainer = document.querySelector(
  //   ".selectorsRow.suggestedXpath"
  // );
  // var iframeXpathContainer = document.querySelector(
  //   ".selectorsRow.iframeXpath"
  // );
  // var editorTitle = document.querySelector(".editorTitle");
  // var editorContent = document.querySelector(".editorContent");
  // var totalMatchingCount = document.querySelector(".total-match-count");
  // suggestedXpathContainer.style.display = "none";

  // var axesXpathWithCount;
  // var elementInfo;

  // //elementInfoContainer.style.display="none";

  // try {
  //   axesXpathWithCount = message.axesXpathWithCount;
  // } catch (err) {}

  // try {
  //   wrong = message.count.includes("wrong");
  //   iframe =
  //     message.count == "frame"
  //       ? true
  //       : message.count == "iframe"
  //       ? true
  //       : false;
  //   iframeXpath =
  //     message.count[0] == "iframe"
  //       ? true
  //       : message.count[0] == "frame"
  //       ? true
  //       : false;
  //   svgElement = message.count === "svgelement";
  //   shadowDom = message.count.includes("shadowdom");
  //   notIframe = message.count.includes("notIframe");
  //   suggestedSelector = message.count.includes("suggestedSelector");
  //   textAndAttr = message.count.includes("z$*[shub]");
  //   pageReload = message.count.includes("pageReload");
  //   sanjayXpathIndex = message.count.includes("sanjayXpathIndex");
  //   elementInfo = message.count.split("elementInfo-")[1];
  // } catch (err) {}

  // if (axesXpathWithCount) {
  //   assignAxesXpath(axesXpathWithCount);
  // }

  // if (iframe || shadowDom || svgElement) {
  //   if (shadowDom) {
  //     editorTitle.innerText = "in ShadowDOM";
  //     insideShadowDom = true;
  //     selectorEditBox.style.width = selectorEditBoxWidthShadow;
  //     editorContent.style.backgroundColor = "#2196F3";
  //     editorContent.style.color = "#ffffff";
  //     totalMatchingCount.style.marginLeft = totalCountMarginShadow;
  //     inputBox.setAttribute(
  //       "placeholder",
  //       "Write & verify cssSelector as XPath doesn't support shadowDOM......Click on ➕ icon to save value ➡️"
  //     );
  //     var info = `Alert: This element is inside shadow dom which can't be accessed through XPath, use cssSelector for it.<a class="training" href="https://bit.ly/sh_courses_recordings" target="_blank"> Learn more...</a>`;
  //     elementInfoAlert(info, "#2196f3");
  //   } else if (svgElement) {
  //     editorContent.style.color = "#ffffff";
  //     selectorEditBox.style.width = selectorEditBoxWidth;
  //     editorTitle.innerText = "SVG element...";
  //     if (!shadowDom && !iframe) {
  //       editorContent.style.backgroundColor = "#f5388fb3";
  //     }
  //     totalMatchingCount.style.marginLeft = totalCountMarginSvg;
  //     inputBox.setAttribute(
  //       "placeholder",
  //       "Write & verify XPath & CSS Selector here......Click on ➕ icon to save value ➡️"
  //     );
  //     var info = `Alert: This is a svg element & it doesn't support standard XPath format.<a class="training" href="https://bit.ly/sh_courses_recordings" target="_blank"> Learn more...</a>`;
  //     elementInfoAlert(info, "#f5388fb3");
  //   } else {
  //     //insideShadowDom = false;
  //     insideFrame = true;

  //     //selectorEditBox.style.width = OS.includes('mac') ? "calc(100% - 104px)" : "calc(100% - 110px)";

  //     editorContent.style.color = "black";
  //     // editorTitle.innerText = " in "+message.count+" ";
  //     editorTitle.innerText = " inside iframe ";
  //     editorContent.style.backgroundColor = "#cccccc";
  //     totalMatchingCount.style.marginLeft =
  //       message.count == "frame"
  //         ? totalCountMarginFrame
  //         : totalCountMarginIframe;
  //     inputBox.setAttribute(
  //       "placeholder",
  //       "Write & verify XPath & CSS Selector here......Click on ➕ icon to save value ➡️"
  //     );
  //     var info = `Alert: This element is inside iframe. Switch inside iframe to access it through automation.<a class="training" href="https://bit.ly/sh_courses_recordings" target="_blank"> Learn more...</a>`;
  //     elementInfoAlert(info, "#747272");
  //   }

  //   if (message.count[1] === undefined || shadowDom || svgElement) {
  //     iframeXpathContainer.style.display = "none";
  //   }
  //   // }else{
  //   //     //message.count[1][0] = addDriverCommand.className.includes('inactive')?message.count[1][0]:addPreCommandInSelector(message.count[1][0]);
  //   //     iframeXpathBox.innerText = addDriverCommand.className.includes('inactive')?message.count[1][0]:addPreCommandInSelector(message.count[1][0]);;
  //   //     // iframeXpathBox.setAttribute("title",message.count[1][0]);
  //   //     document.querySelector(".noOfMatch.iframeXpath").textContent = message.count[1][1];
  //   //     var count = document.querySelector(".noOfMatch.iframeXpath");

  //   //     count.style.backgroundColor = message.count[1][1]=="1"?"#0cb9a9":message.count[1][1]=="0"?"#ff0000":"#f78f06";
  //   // }
  //   // setElementContainerHeight();
  // } else if (iframeXpath) {
  //   var iframeXpathBox = document.querySelector(".valueSelector.iframeXpath");
  //   var typeOfLocator = document.querySelector(
  //     ".typeOfLocator.box.iframeCopyBtn"
  //   );
  //   typeOfLocator.innerText = message.count[0] + " XPath";

  //   iframeXpathBox.style.color = "white";

  //   iframeXpathContainer.style.display = "block";
  //   message.count[1][0] = addDriverCommand.className.includes("inactive")
  //     ? message.count[1][0]
  //     : addPreCommandInSelector(message.count[1][0]);
  //   //message.count[1][0] = message.count[1][0].includes("By.xpath")?message.count[1][0].replace("By.xpath", "By.cssSelector"):message.count[1][0].includes("By(xpath")?message.count[1][0].replace("By(xpath", "By(cssSelector"):message.count[1][0].includes("ByXPath")?message.count[1][0].replace("ByXPath", "ByCssSelector"):message.count[1][0].includes("XPath")?message.count[1][0].replace("XPath", "CssSelector"):message.count[1][0].includes("Xpath")?message.count[1][0].replace("Xpath", "CssSelector"):message.count[1][0].includes("XPATH")?message.count[1][0].replace("XPATH", "CSSSELECTOR"):message.count[1][0].replace("xpath","cssSelector");
  //   var nestedIframe = message.count[2];
  //   var nestedCode = document.querySelector("#nestedCode");
  //   var nestedBlock = document.querySelector("#nestedBlock");
  //   if (
  //     nestedIframe.length > 0 &&
  //     !multiSelectorRecordBtn.classList.contains("red") &&
  //     !smartFix.classList.contains("defaultsmartFix") &&
  //     !uiSettingBtn.classList.contains("active") &&
  //     !axesBtn.classList.contains("active")
  //   ) {
  //     nestedBlockOn = "yes";
  //     nestedBlock.style.display = "block";
  //     var finalScript =
  //       "//This element is inside " +
  //       (nestedIframe.length + 1) +
  //       " nested frames.";

  //     var eleOrXpath = addDriverCommand.className.includes("inactive")
  //       ? "XPath for"
  //       : "WebElement";
  //     var driverCommandBox = document.querySelector(".driver-command");
  //     if (
  //       !addDriverCommand.className.includes("inactive") &&
  //       driverCommandBox.value
  //     ) {
  //       eleOrXpath = "WebElement";
  //     } else {
  //       eleOrXpath = "XPath for";
  //     }

  //     for (var i = 1; i <= nestedIframe.length; i++) {
  //       nestedIframe[i - 1] = addDriverCommand.className.includes("inactive")
  //         ? nestedIframe[i - 1]
  //         : addPreCommandInSelector(nestedIframe[i - 1]);
  //       finalScript =
  //         finalScript +
  //         "\n" +
  //         eleOrXpath +
  //         " frame" +
  //         i +
  //         " = " +
  //         nestedIframe[i - 1] +
  //         ";";
  //     }
  //     var tempXpath = addDriverCommand.className.includes("inactive")
  //       ? relXpathWithCount[0]
  //       : addPreCommandInSelector(relXpathWithCount[0]);
  //     finalScript =
  //       finalScript +
  //       "\n" +
  //       eleOrXpath +
  //       " frame" +
  //       (nestedIframe.length + 1) +
  //       " = " +
  //       message.count[1][0] +
  //       ";" +
  //       "\n" +
  //       eleOrXpath +
  //       " inspectedElement = " +
  //       tempXpath +
  //       ";";
  //     nestedCode.textContent = finalScript;
  //   } else if (!insideShadowDom) {
  //     nestedBlock.style.display = "none";
  //     nestedBlockOn = "no";
  //   }

  //   iframeXpathBox.innerText = message.count[1][0];
  //   // iframeXpathBox.setAttribute("title",message.count[1][0]);
  //   document.querySelector(".noOfMatch.iframeXpath").textContent =
  //     message.count[1][1];
  //   var count = document.querySelector(".noOfMatch.iframeXpath");

  //   count.style.backgroundColor =
  //     message.count[1][1] == "1"
  //       ? "#0cb9a9"
  //       : message.count[1][1] == "0"
  //       ? "#ff0000"
  //       : "#f78f06";

  //   setElementContainerHeight();
  // } else if (notIframe) {
  //   insideShadowDom = false;
  //   editorContent.style.color = "black";
  //   editorTitle.innerText = "XPath/cssSel..";
  //   editorContent.style.backgroundColor =
  //     themeName === "dark" ? "#f29a00db" : "#f29a00a8";
  //   selectorEditBox.style.width = selectorEditBoxWidth;
  //   iframeXpathContainer.style.display = "none";
  //   totalMatchingCount.style.marginLeft = totalCountMargin;
  //   inputBox.setAttribute(
  //     "placeholder",
  //     "Write & verify XPath & CSS Selector here......Click on ➕ icon to save value ➡️"
  //   );
  //   setElementContainerHeight();
  // } else if (textAndAttr) {
  //   bothListOfTextAndAttr = [];
  //   bothListOfTextAndAttr = message.count;
  // } else if (sanjayXpathIndex) {
  //   sanjayXpathIndex = "";
  //   bothListOfTextAndAttr[3] = message.count;
  // } else if (suggestedSelector) {
  //   var suggestedXpathBox = document.querySelector(
  //     ".valueSelector.suggestedXpath"
  //   );
  //   suggestedXpathContainer.style.display = "block";

  //   var suggestedXpathChoice = document.querySelector(".choose.suggestedXpath");
  //   if (!suggestedXpathChoice.checked) {
  //     suggestedXpathContainer.style.display = "none";
  //   }

  //   if (message.count[1] === undefined || insideShadowDom) {
  //     suggestedXpathContainer.style.display = "none";
  //   } else {
  //     message.count[1][0] = addDriverCommand.className.includes("inactive")
  //       ? message.count[1][0]
  //       : addPreCommandInSelector(message.count[1][0]);
  //     message.count[1][0] = message.count[1][0].includes("By.xpath")
  //       ? message.count[1][0].replace("By.xpath", "By.cssSelector")
  //       : message.count[1][0].includes("By(xpath")
  //       ? message.count[1][0].replace("By(xpath", "By(cssSelector")
  //       : message.count[1][0].includes("ByXPath")
  //       ? message.count[1][0].replace("ByXPath", "ByCssSelector")
  //       : message.count[1][0].includes("XPath")
  //       ? message.count[1][0].replace("XPath", "CssSelector")
  //       : message.count[1][0].includes("Xpath")
  //       ? message.count[1][0].replace("Xpath", "CssSelector")
  //       : message.count[1][0].includes("XPATH")
  //       ? message.count[1][0].replace("XPATH", "CSSSELECTOR")
  //       : message.count[1][0].replace("xpath", "cssSelector");
  //     suggestedXpathBox.innerText = message.count[1][0];
  //     // suggestedXpathBox.setAttribute("title",message.count[1][0]);
  //     document.querySelector(".noOfMatch.suggestedXpath").textContent =
  //       message.count[1][1];
  //     var count = document.querySelector(".noOfMatch.suggestedXpath");

  //     count.style.backgroundColor =
  //       message.count[1][1] == "1"
  //         ? "#0cb9a9"
  //         : message.count[1][1] == "0"
  //         ? "#ff0000"
  //         : "#f78f06";
  //   }
  //   setElementContainerHeight();
  // } else if (pageReload) {
  //   setTimeout(() => {
  //     if (isSidePanelView) {
  //       getActiveTabId().then((tabId) => {
  //         postSafeMessage({
  //           name: "init",
  //           tabId,
  //           contentScript: "../content-script/contentScript.js",
  //           contentCSS: "../content-script/contentScript.css",
  //         });
  //       });
  //     }else{
  //       postSafeMessage({
  //         name: "init",
  //         tabId: browserType.devtools.inspectedWindow.tabId,
  //         contentScript: "../content-script/contentScript.js",
  //         contentCSS: "../content-script/contentScript.css",
  //       });
  //     }
  //     setTimeout(() => {
  //       if (!multiSelectorRecordBtn.className.includes("red")) {
  //         generateSelectors();
  //       }
  //     }, 1000);
  //   }, 1000);
  // } else if (elementInfo) {
  //   var info = elementInfo;
  //   elementInfoAlert(info, "#eb3030");
  // } else {
  //   if (wrong) {
  //     suggestedXpathContainer.style.display = "none";
  //     highlightWrongXpath();
  //     showTotalResults(message.count);
  //     return;
  //   } else {
  //     removeWrongXpath();
  //     if (showTotalCount) {
  //       showTotalResults(message.count);
  //     }
  //     try {
  //       if (
  //         document.querySelector(".jsSelector").value ||
  //         (message.count.length === 1 &&
  //           !toggleElement.classList.contains("inactive"))
  //       ) {
  //         showAllMatchingNode(message.count);
  //       }
  //     } catch (err) {}
  //     if (message.event) {
  //       if (message.event === "shown") {
  //         selectElements(xpathOrCss, false);
  //       }
  //     }
  //   }
  // }
  // //scroll selectors to top
  // document.querySelector(".selectorsGenerator").scrollTop = 0;
});

function elementInfoAlert(info, color) {
  var elementInfoContainer = document.querySelector(".elementInfo");
  var elementInfoMsgBox = document.querySelector(".elementInfoMsg");
  setTimeout(function () {
    elementInfoMsgBox.innerHTML = info;
    elementInfoContainer.style.display = "block";
    elementInfoContainer.style.background = color;
  }, 100);
}

function appendElementsCount(obj) {
  if(obj){
    let ele = document.getElementById(obj.id);
    let countClass = nodesColor(obj.elementCount);
  
    ele.textContent = `${obj.elementCount}`;
    ele.classList.add(countClass);
  }
}

browserType.runtime.onMessage.addListener(function (
  message,
  sender,
  sendResponse
) {
  if (message.type === "elementsCount") {
    appendElementsCount(message);
  }

  if(isSidePanelView){
    if(message && message.action === "check-inspector-state"){
      let messageName = inspectorActivated ? "activate-inspector" : "desactivate-inspector";
  
      getActiveTabId().then(tabId => {
          postSafeMessage({ 
              name: messageName, 
              tabId
          });
      })
  }
  
    if(message && message.action === "select-inspected-element"){
      displayInPOM();
    }
    if(message && message.action === "toggle-inspector"){
      if(isSidePanelView) toggleInspector();
    }
  
    if(message && message.name === "calculate-elements-result"){
      appendElementsCount(message.result);
    }
  
    if(message.name && message.name === "highlight-element-result"){
      if(message.result){
        receiveXpathResults(message.result);
      }
    }
  
    if(message.name && message.name === "check-invalid-selector-result"){
      if(message.result){
          if(forGPT){
              localSelectorFix(selectorInput.value);
          }else{
              highlightWrongXpath();   
          }
          return;
      }
      if(forGPT) correctSelectorValue(message.xpathValue);
  
      forGPT = false;
    }
  
    if(message.name && message.name === "prepare-list-of-attr-text-result"){
      //elementInfoContainer.style.display="none";
      domContentCopyBtn.style.display="none";
      bothListOfTextAndAttr = [];
      if(message.result){
          bothListOfTextAndAttr = message.result;
      }
    }
  
    if(message.name && message.name === "element-type-and-info-result"){
        elementInfoContainer.style.display="none";
        try{
            if(message.result.elementType){
                setElementType(message.result.elementType);    
            }
            if(message.result.elementInfo){
                setElementAlertInfo(message.result.elementInfo);    
            }
        }catch(err){
            console.log(err);
        }
    }
  
    if(message.name && message.name === "create-axes-xpath-for-element-result"){
        if(message.result){
            assignAxesXpath(message.result);
        }
    }
  
    if(message.name && message.name === "on-inspect-element-click-result"){
        if(message.result){
            document.querySelector(".infoPlaceholder div").style.display = "none";
            assignSelectorsValue(message.result);
            generatorCallback();
        }
    }
  }

  if (
    message.message === "generate-selector" &&
    !multiSelectorRecord.className.includes("red")
  ) {
    generateSelectors();
  }

  if (message.message === "StopRecording") {
    document.querySelector(".testCaseStudioBtn").classList.remove("redBlink");
  }

  if (message.message === "AttachStudio") {
    document.querySelector(".testCaseStudioBtn").classList.add("redBlink");
    openedRecorder = true;
    updateRecorderAttr();
  }
  if (message.message === "DeattachStudio") {
    document.querySelector(".testCaseStudioBtn").classList.remove("redBlink");
    openedRecorder = false;
  }

  if (message.name === "execute-js-result") {
    let { result } = message;
    if (result) {
      if (result.length > 0) {
        showAllMatchingNode(result);
      }
      showTotalResults(result);
    }
  }

  if (message.name && message.name === "fix-selector-result") {
    correctSelectorValue(message.result);
  }

  if (message.type === "updateCPAttr") {
    updateCPAttributes(message.data);
  }
  if (message.name === "contextmenu") {
    var event = "contextmenu: " + message.value;
    //alert(event);

    trackEvent(event);
  }
});

function updateRecorderAttr() {
  // var userAttr = userAttrName.value.trim();
  // var idChecked = idCheckbox.checked?"withid":"withoutid";
  var idChecked = idAttr.checked;
  var classChecked = classAttr.checked;
  var nameChecked = nameAttr.checked;
  var placeholderChecked = placeholderAttr.checked;
  var textChecked = textCheckbox.checked;

  if(isSidePanelView){
    getActiveTabId().then(tabId => {
        postSafeMessage({
            name: "recorderAttr",
            tabId,
            data: {
                idChecked,
                classChecked,
                nameChecked,
                placeholderChecked,
                textChecked,
                placeholderText: preCommandInput.value
            }
        });
    });
  }else{
    postSafeMessage({
      name: "recorderAttr",
      tabId: browserType.devtools.inspectedWindow.tabId,
      data: {
        idChecked,
        classChecked,
        nameChecked,
        placeholderChecked,
        textChecked,
        placeholderText: preCommandInput.value,
      },
    });
  }
}

function updateCPAttributes(data) {
  idAttr.checked = data.idChecked;
  classAttr.checked = data.classChecked;
  nameAttr.checked = data.nameChecked;
  placeholderAttr.checked = data.placeholderChecked;
  textCheckbox.checked = data.textChecked;

  // preCommandInput.value = data.placeholderText;

  browserType.storage.local.set(
    { classChecked: data.classChecked },
    function () {}
  );
  browserType.storage.local.set(
    { nameChecked: data.nameChecked },
    function () {}
  );
  browserType.storage.local.set(
    { placeholderChecked: data.placeholderChecked },
    function () {}
  );
  browserType.storage.local.set({ idChecked: data.idChecked }, function () {});
  browserType.storage.local.set(
    { textCheckboxChecked: data.textChecked },
    function () {}
  );

  // browserType.storage.local.set({'preCommandValue':data.placeholderText}, function(){});
}

var infoPlaceholderParent = document.querySelector(".infoPlaceholder");
var infoPlaceholder = document.querySelector(".infoPlaceholder div");

document.addEventListener("DOMContentLoaded", async function () {
  var inputBox = document.querySelector(".jsSelector");

  var chooseAttrBox = document.querySelector(".chooseAttr.user");
  driverCommandBox.style.display = "none";
  var CopyBtn = document.querySelector(".header-copy-btn");
  inputBox.focus();
  var editorTitle = document.querySelector(".editorTitle");

  setTimeout(() => {
    if (!multiSelectorRecord.className.includes("red")) {
      generateSelectors();
    }
  }, 100);

  setTimeout(() => {
    if (relXpathWithCount && relXpathWithCount !== "") {
      infoPlaceholder.style.display = "none";
      infoPlaceholderParent.style.display = "none";
    } else if (
      (relXpathWithCount === "") &
      !toggleElement.classList.contains("inactive")
    ) {
      var relXpathContainer = document.querySelector(".valueSelector.rel");
      var cssContainer = document.querySelector(".valueSelector.css");
      var idContainer = document.querySelector(".valueSelector.id");
      relXpathContainer.innerText =
        "After installation, restart browser or open website in new tab.";
      cssContainer.innerHTML =
        "Don't use it in blank tab, open <a  target='_blank' href='https://www.google.com/'>google.com</a>";
      idContainer.innerHTML =
        "For more details watch <a  target='_blank' href='https://bit.ly/2SzENm1'>this tutorial.</a>";

      infoPlaceholder.style.display = "block";
      infoPlaceholderParent.style.display = "block";

      infoPlaceholder.style.color = "red";
      infoPlaceholder.style.marginLeft = "60px";
      infoPlaceholder.innerHTML =
        "Ooops.....Looks like you are missing something.\n1. Close DevTools & open website in the new tab.\n2. There should be a url like <a  target='_blank' href='https://www.google.com/'>google.com</a> in the address bar.\n3. Neither Element should be inside cross-origin iframe nor inside shadow-root (closed).\n4. For more details watch <a  target='_blank' href='https://bit.ly/2SzENm1'>this tutorial.</a>\n5. If issue still persist, pls email me at <a href='mailto:selectorshub@gmail.com'>selectorshub@gmail.com</a>";

      return;
    }
  }, 600);
  // editorTitle.addEventListener("change", function(event){
  //     let relXpath = document.getElementById('relXpathSelector');

  //     setElementContainerHeight();
  //     generateSelectors();

  //     if(event.target.value === 'relXpath'){
  //         relXpath.classList.add('listPosition');
  //     }else {
  //         relXpath.classList.remove('listPosition');
  //     }

  // });

  inputBox.addEventListener("search", function (event) {
    if (!document.querySelector(".jsSelector").value) {
      generateSelectors();
    }
  });

  var tempValue = "";
  inputBox.addEventListener("keyup", function (event) {
    fixTries = 0;

    var xpathOrCss = "xpath";
    var key = event.which || event.keyCode;
    var userValue = document.querySelector(".jsSelector").value;
    var patronKeys = [
      "f43axAVwxUiplyooQJfYTRRj0UtPYSac",
      "DM2QfjpVMMtRn5zRliMJC4VVoFImyUmq",
      "eA5aj9R4pO5ybBLIbzo7iIFIxg3M64Y8",
      "2s8anL1BlMfSCXwwJVg3EkkXqlzN00Uf",
    ];
    if (key === 13) {
      trackEvent("Verify Selectors");
      savedSelectors.style.display = "none";
      if (userValue && patronKeys.includes(userValue)) {
        hideFooter();
        footerCounter.style.display = "none";
        toggleElement.classList.remove("notPatron");
        plusBtn.classList.remove("notPatron");
        copyAllBtnXPath.classList.remove("notPatron");
        copyAllBtnCssSelector.classList.remove("notPatron");
        nestedCodeCopyBtn.classList.remove("notPatron");
        toggleElement.classList.remove("inactive");
        toggleElement.classList.add("active");
        browserType.storage.local.set(
          { toggleElement: "active" },
          function () {}
        );
        toggleState();
        generateSelectors();
      }
      showTotalCount = true;
      if (
        userValue.slice(0, 9).includes("document.") ||
        userValue.slice(0, 2).includes("$(")
      ) {
        clearElements();
        executeScript();
      } else {
        checkWrongXpath();
        selectElements(xpathOrCss, true); //here passing true to tell SH to suggest selectors
      }
      document.querySelector(".infoPlaceholder div").style.display = "none";
      document.querySelector(".infoPlaceholder").style.display = "none";
      setElementContainerHeight();
    } else if (
      document.querySelector(".jsSelector").value ||
      key == 8 ||
      key == 46
    ) {
      //showTotalCount = true;
      checkWrongXpath();
      //selectElements(xpathOrCss, true);
      tempValue = document.querySelector(".jsSelector").value;
    } else if (!document.querySelector(".jsSelector").value) {
      selectElements(xpathOrCss, true);
      generateSelectors();
    }

    setTimeout(function () {
      var textNode = document.querySelector(
        "#selectorsHubEleContainer > .text-node"
      );
      var domContentCopyBtn = document.querySelector(".domContentCopyBtn");
      if (textNode) {
        domContentCopyBtn.style.display = "block";
      } else {
        domContentCopyBtn.style.display = "none";
      }
      domContentCopyBtn.addEventListener("click", function () {
        trackEvent("copy dom content");
        copyToClipboard("#selectorsHubEleContainer");
        showCopied();
      });
    }, 100);
  });

  if (isChrome) {
    inputBox.addEventListener("keydown", function (e) {
      var key = e.keyCode || e.charCode || 0;
      var evtobj = window.event ? event : e;
      if (
        (evtobj.keyCode == 90 && evtobj.ctrlKey) ||
        (evtobj.keyCode == 90 && evtobj.metaKey)
      ) {
        document.querySelector(".jsSelector").value = tempValue;
      }
    });
  }

  chooseAttrBox.addEventListener("keyup", async function (event) {
    var key = event.which || event.keyCode;

    if (key === 13) {
      if (event.target.value === "what is my sh_id") {
        const data = await browserType.storage.local.get(["ext_uniq_id"]);
        if (data.ext_uniq_id) {
          const extensionIdContainer = document.createElement("div");
          extensionIdContainer.classList.add("extension__id__wrapper");

          extensionIdContainer.innerHTML = `
                            <div class="extension__id">
                                <div class="extension__id__close"></div>
                                <h4>Your unique sh_id</h4>
                                <div class="extension__id__container">
                                    <input type="text" name="extension-id" id="extension-id" value="${data.ext_uniq_id}" readOnly />
                                    <div class="extension__id__copy">
                                        <div class="icon"></div>
                                    </div>
                                </div>
                            </div>
                        `;
          let extensionIdInput =
            extensionIdContainer.querySelector("#extension-id");
          let closeBtn = extensionIdContainer.querySelector(
            ".extension__id__close"
          );
          let copyBtn = extensionIdContainer.querySelector(
            ".extension__id__copy"
          );

          closeBtn.addEventListener("click", () =>
            extensionIdContainer.remove()
          );

          copyBtn.addEventListener("click", async () => {
            extensionIdInput.select();
            document.execCommand("Copy");

            copyBtn.style.backgroundColor = "#ffe0a6";
            setTimeout(() => (copyBtn.style.backgroundColor = "#ffffff"), 300);
          });

          document.body.appendChild(extensionIdContainer);
          event.target.value = "";
        }
        return;
      }
      trackEvent("Enter user attr");
      generateSelectors();
      generateSuggestedXpath();
    }
  });

  preCommandInput.addEventListener("keyup", function (event) {
    var key = event.which || event.keyCode;

    this.value = this.value.replace(/“/g, '"').replace(/”/g, '"');

    if (key === 13) {
      this.value.replace(/xpathvalue/i, "xpathvalue");
      if (this.value && !this.value.toLowerCase().includes("xpathvalue")) {
        this.classList.add("wrongXpath");
        // document.querySelector('.commandTip').style.visibility = "visible";
        showXpathValueAlertMsg(
          "xpathValue keyword should be there in the command."
        );
        return;
      }

      if (
        this.value &&
        this.value.toLowerCase().includes(`"xpathvalue"`) &&
        quotes.classList.contains("active")
      ) {
        this.classList.add("wrongXpath");
        // document.querySelector('.commandTip').style.visibility = "visible";
        showXpathValueAlertMsg(
          'Put xpathValue inside single quote as XPath is generated with "".'
        );
        return;
      }

      generateSelectors();
      generateSuggestedXpath();

      if (smartFix.classList.contains("defaultsmartFix")) {
        updateSMSteps();
      }

      if (multiSelectorRecord.classList.contains("red")) {
        updateselectorsHubSteps();
      }
    }

    if (
      this.value &&
      (!this.value.toLowerCase().includes("xpathvalue") ||
        (this.value.toLowerCase().includes(`"xpathvalue"`) &&
          quotes.classList.contains("active")))
    ) {
      this.classList.add("wrongXpath");
      // document.querySelector('.commandTip').style.visibility = "visible";
      addDriverCommand.classList.add("inactive");
      addDriverCommand.classList.remove("active");
    } else if (!this.value || this.value.toLowerCase().includes("xpathvalue")) {
      this.classList.remove("wrongXpath");
      // document.querySelector('.commandTip').style.visibility = "hidden";
      addDriverCommand.classList.remove("inactive");
      addDriverCommand.classList.add("active");
    }
  });

  addClickHandlers();

  clickToCopyIframeXpath();
  clickToEditIframeXpath();

  clickToCopySuggestedXpath();
  clickToEditSuggestedXpath();

  clickToCopyRelXpath();
  clickToEditRelXpath();

  clickToCopyIndexXpath();
  clickToEditIndexXpath();

  clickToCopyId();
  clickToEditId();

  clickToCopyName();
  clickToEditName();

  clickToCopyClassName();
  clickToEditClassName();

  clickToCopyCss();
  clickToEditCss();

  clickToCopyJQuery();
  clickToEditJQuery();

  clickToCopyJsPath();
  clickToEditJsPath();

  clickToCopyLinkText();
  clickToEditLinkText();

  clickToCopyPartialLinkText();
  clickToEditPartialLinkText();

  clickToCopyTagName();
  clickToEditTagName();

  clickToCopyAbsXpath();
  clickToEditAbsXpath();

  clickToCopyAxesXpath();
  clickToEditAxesXpath();

  clickToCopyLastAxesXpath();
  clickToEditLastAxesXpath();

  clickToCopyTestRigorPath();
  clickToEditTestRigorPath();

  setTimeout(() => {}, 2000);
});

function setElementContainerHeight() {
  var headerHeight = 47 + 25 + 7; //here 47 is header height which is fixed and 51 is for footer and to show till last element
  var selectorsRowHeight = 0;

  var allSelectors = document.querySelectorAll(".selectorsRow");
  var selectorsGeneratorHeight = document.querySelector(
    ".selectorsGenerator"
  ).offsetHeight;

  if (expandBtn.classList.contains("inactive")) {
    //selectorsGeneratorHeight = 125;
  }

  for (var i = 0; i < allSelectors.length; i++) {
    if (
      !allSelectors[i].style.display.includes("none") &&
      selectorsRowHeight < selectorsGeneratorHeight
    ) {
      selectorsRowHeight = selectorsRowHeight + 25;
    }
  }

  if (driverCommandBox.style.display != "none") {
    headerHeight = headerHeight + 25;
  }

  if (attributeFilter.style.display != "none") {
    headerHeight = headerHeight + 25;
  }

  if (patronRequest.style.display == "none") {
    headerHeight = headerHeight - 24;
  }

  // if(footerBanner.style.display == "none"){
  //     headerHeight = headerHeight-26;
  // }

  toggleElement = document.querySelector(".toggle-btn");

  if (toggleElement.classList.contains("inactive")) {
    document.querySelector("#selectorsHubEleContainer").style.height =
      eleContainerHeight;
  } else {
    document.querySelector("#selectorsHubEleContainer").style.height =
      "calc(100% - " + (selectorsRowHeight + headerHeight - 15) + "px)";
  }
  // document.querySelector(".selectorsGenerator").style.height = selectorsRowHeight+"px";
}

function generateAbsXpath() {
  var xpathOrCss = "xpath";
  var absXpath = "";
  var totalMatchingNode = "";
  // var absXPath = browserType.devtools.inspectedWindow.eval('generateAbsXpath($0)', { useContentScriptContext: true }, function(result) {
  var inputBox = document.querySelector(".valueSelector.abs");
  var absXpathContainer = document.querySelector(".selectorsRow.absXpath");

  var absXpathChoice = document.querySelector(".choose.absXpath");
  if (!absXpathChoice.checked) {
    absXpathContainer.style.display = "none";
  }

  if (absXpathWithCount === undefined) {
    absXpath =
      "Element might be inside cross-origin iframe. Use SH contextMenu feature to copy selectors.";
    totalMatchingNode = "0";
    if (!xpathOrCss.includes("abs")) {
      absXpathContainer.style.display = "none";
    }
  } else {
    absXpath = absXpathWithCount[0];
    totalMatchingNode = absXpathWithCount[1];
  }
  inputBox.setAttribute("absXpath", absXpath);
  // inputBox.setAttribute("title", absXpath);

  absXpath = addDriverCommand.className.includes("inactive")
    ? absXpath
    : addPreCommandInSelector(absXpath);
  absXpath = absXpath.includes("cy.get")
    ? absXpath.replace("cy.get", "cy.xpath")
    : absXpath;
  inputBox.innerText = absXpath;

  var count = document.querySelector(".noOfMatch.absXpath");
  count.textContent = totalMatchingNode;
  count.style.backgroundColor =
    totalMatchingNode == "1"
      ? "#0cb9a9"
      : totalMatchingNode == "0"
      ? "#ff0000"
      : "#f78f06";

  if (xpathOrCss.includes("abs")) {
    selectElements(xpathOrCss, false);
    setElementContainerHeight();
    document.querySelector(".noOfMatch.absXpath").parentElement.style.width =
      "26px";
  }
  if (totalMatchingNode == "0" && !xpathOrCss.includes("abs")) {
    absXpathContainer.style.display = "none";
  }
  //});
}

function generateCss() {
  var xpathOrCss = "xpath";
  var totalMatchingNode = "";

  // var css = browserType.devtools.inspectedWindow.eval('generateCSS($0, "'+chooseAttrs+'")', { useContentScriptContext: true }, function(result) {
  var inputBox = document.querySelector(".valueSelector.css");
  var cssContainer = document.querySelector(".selectorsRow.cssSelector");
  var count = document.querySelector(".noOfMatch.cssSelector");

  var jQueryInputBox = document.querySelector(".valueSelector.jQuery");
  var jQueryContainer = document.querySelector(".selectorsRow.jQuery");
  var jQueryCount = document.querySelector(".noOfMatch.jQuery");

  var jsPathInputBox = document.querySelector(".valueSelector.jsPath");
  var jsPathContainer = document.querySelector(".selectorsRow.jsPath");
  var jsPathCount = document.querySelector(".noOfMatch.jsPath");

  var cssChoice = document.querySelector(".choose.cssSelector");
  var jsPathChoice = document.querySelector(".choose.jsPath");
  var jQueryChoice = document.querySelector(".choose.jQuery");

  cssContainer.style.display = "";
  jsPathContainer.style.display = "";
  jQueryContainer.style.display = "";
  if (
    cssSelectorWithCount === undefined ||
    cssSelectorWithCount[1] == 0 ||
    cssSelectorWithCount[0] == undefined
  ) {
    if (cssSelectorWithCount[0].includes("closed shadow dom")) {
      totalMatchingNode = "0";
      count.textContent = totalMatchingNode;
      inputBox.innerHTML =
        '<a href="https://youtu.be/Qtdmo9H0JZA" target="blank">Please watch this Tutorial to handle closed shadow dom element</a>';
    } else {
      inputBox.textContent =
        "Element inside cross-origin iframe. Copy Selectors by right click on element or open iframe src url in new tab.";
      count.textContent = "0";
      jsPathInputBox.textContent =
        "Element inside cross-origin iframe. Copy Selectors by right click on element or open iframe src url in new tab.";
      jsPathCount.textContent = "0";
      jQueryInputBox.textContent =
        "Element inside cross-origin iframe. Copy Selectors by right click on element or open iframe src url in new tab.";
      jQueryCount.textContent = "0";
      if (!xpathOrCss.includes("css")) {
        cssContainer.style.display = "none";
      }
    }
    jsPathContainer.style.display = "none";
    jQueryContainer.style.display = "none";
  } else {
    try {
      inputBox.setAttribute("css", cssSelectorWithCount[0].trim());
      // inputBox.setAttribute("title", result[0]);
      if (quotes.classList.contains("active")) {
        jsPathInputBox.innerText =
          "document.querySelector(`" + cssSelectorWithCount[0].trim() + "`)";
        jQueryInputBox.innerText =
          "$(`" + cssSelectorWithCount[0].trim() + "`)";
      } else {
        jsPathInputBox.innerText =
          'document.querySelector("' + cssSelectorWithCount[0].trim() + '")';
        jQueryInputBox.innerText =
          '$("' + cssSelectorWithCount[0].trim() + '")';
      }
      cssSelectorWithoutCommand = cssSelectorWithCount[0].trim();
      cssSelectorWithCount[0] = addDriverCommand.className.includes("inactive")
        ? cssSelectorWithCount[0].trim()
        : addPreCommandInSelector(cssSelectorWithCount[0].trim());
      cssSelectorWithCount[0] = cssSelectorWithCount[0].includes("By.xpath")
        ? cssSelectorWithCount[0].replace("By.xpath", "By.cssSelector")
        : cssSelectorWithCount[0].includes("By(xpath")
        ? cssSelectorWithCount[0].replace("By(xpath", "By(cssSelector")
        : cssSelectorWithCount[0].includes("ByXPath")
        ? cssSelectorWithCount[0].replace("ByXPath", "ByCssSelector")
        : cssSelectorWithCount[0].includes("cy.xpath")
        ? cssSelectorWithCount[0].replace("cy.xpath", "cy.get")
        : cssSelectorWithCount[0].replace("cy.Xpath", "cy.get");

      inputBox.innerText = cssSelectorWithCount[0];
      totalMatchingNode = cssSelectorWithCount[1];

      count.textContent = totalMatchingNode;

      jQueryCount.textContent = totalMatchingNode;
      jQueryCount.style.backgroundColor =
        totalMatchingNode == "1"
          ? "#0cb9a9"
          : totalMatchingNode == "0"
          ? "#ff0000"
          : "#f78f06";

      jsPathCount.textContent = totalMatchingNode;
      jsPathCount.style.backgroundColor =
        totalMatchingNode == "1"
          ? "#0cb9a9"
          : totalMatchingNode == "0"
          ? "#ff0000"
          : "#f78f06";

      //var relXpath = document.querySelector(".valueSelector.rel").getAttribute("relxpath").toLowerCase();
      if (xpathOrCss.includes("css") || insideShadowDom) {
        //selectElements("css", false);
        setElementContainerHeight();
        //document.querySelector(".noOfMatch.cssSelector").parentElement.style.width = "26px";
      }
      if (totalMatchingNode == "0" && !xpathOrCss.includes("css")) {
        inputBox.textContent =
          "Element inside cross-origin iframe. Copy Selectors by right click on element or open iframe src url in new tab.";
        cssContainer.style.display = "none";
        jsPathContainer.style.display = "none";
        jQueryContainer.style.display = "none";
      }
    } catch (err) {
      if (relXpathWithCount[0].includes("cross-origin")) {
        totalMatchingNode = "0";
        count.textContent = totalMatchingNode;
        inputBox.innerHTML =
          '<a href="https://youtu.be/vil6Ks5P-Ng" target="blank">Please watch this Tutorial to handle this element</a>';
      } else {
        cssContainer.style.display = "none";
      }
    }
    count.style.backgroundColor =
      totalMatchingNode == "1"
        ? "#0cb9a9"
        : totalMatchingNode == "0"
        ? "#ff0000"
        : "#f78f06";

    cssContainer.style.display = cssChoice.checked ? "block" : "none";
    jsPathContainer.style.display = jsPathChoice.checked ? "block" : "none";
    jQueryContainer.style.display = jQueryChoice.checked ? "block" : "none";
  }
  //});
}

function generateIndexXpath() {
  var inputBox = document.querySelector(".valueSelector.indexXpath");
  var indexXpathContainer = document.querySelector(".selectorsRow.indexXpath");
  indexXpathContainer.style.display = "";

  var indexXpathChoice = document.querySelector(".choose.indexXpath");
  if (!indexXpathChoice.checked) {
    indexXpathContainer.style.display = "none";
  }

  if (indexXpathWithCount === undefined || indexXpathWithCount[1] === 0) {
    indexXpathContainer.style.display = "none";
  } else {
    //linkTextHeight = 25;
    inputBox.setAttribute("selector", indexXpathWithCount[0]);
    // inputBox.setAttribute("title", result[0]);
    indexXpathWithoutCommand = indexXpathWithCount[0];
    indexXpathWithCount[0] = addDriverCommand.className.includes("inactive")
      ? indexXpathWithCount[0]
      : addPreCommandInSelector(indexXpathWithCount[0]);
    indexXpathWithCount[0] = indexXpathWithCount[0].includes("cy.get")
      ? indexXpathWithCount[0].replace("cy.get", "cy.xpath")
      : indexXpathWithCount[0];
    //indexXpathWithCount[0] = indexXpathWithCount[0].includes("By.xpath")?indexXpathWithCount[0].replace("By.xpath", "By.id"):indexXpathWithCount[0].includes("By(xpath")?indexXpathWithCount[0].replace("By(xpath", "By(id"):indexXpathWithCount[0].includes("ByXPath")?indexXpathWithCount[0].replace("ByXPath", "ById"):indexXpathWithCount[0].includes("XPath")?indexXpathWithCount[0].replace("XPath", "Id"):idWithCount[0].includes("Xpath")?idWithCount[0].replace("Xpath", "Id"):idWithCount[0].includes("XPATH")?idWithCount[0].replace("XPATH", "ID"):idWithCount[0].replace("xpath", "id");
    inputBox.innerText = indexXpathWithCount[0];
    var totalMatchingNode = indexXpathWithCount[1];
    var count = document.querySelector(".noOfMatch.indexXpath");
    count.textContent = totalMatchingNode;
    count.style.backgroundColor =
      totalMatchingNode == "1"
        ? "#0cb9a9"
        : totalMatchingNode == "0"
        ? "#ff0000"
        : "#f78f06";
  }
}

function generateId() {
  var inputBox = document.querySelector(".valueSelector.id");
  var idContainer = document.querySelector(".selectorsRow.id");
  idContainer.style.display = "";

  var idChoice = document.querySelector(".choose.id");
  if (!idChoice.checked) {
    idContainer.style.display = "none";
  }

  if (idWithCount === undefined || idWithCount[1] === 0) {
    idContainer.style.display = "none";
  } else {
    //linkTextHeight = 25;
    inputBox.setAttribute("selector", idWithCount[0]);
    // inputBox.setAttribute("title", result[0]);
    idWithoutCommand = idWithCount[0];
    idWithCount[0] = addDriverCommand.className.includes("inactive")
      ? idWithCount[0]
      : addPreCommandInSelector(idWithCount[0]);
    idWithCount[0] = idWithCount[0].includes("By.xpath")
      ? idWithCount[0].replace("By.xpath", "By.id")
      : idWithCount[0].includes("By(xpath")
      ? idWithCount[0].replace("By(xpath", "By(id")
      : idWithCount[0].includes("ByXPath")
      ? idWithCount[0].replace("ByXPath", "ById")
      : idWithCount[0].includes("XPath")
      ? idWithCount[0].replace("XPath", "Id")
      : idWithCount[0].includes("Xpath")
      ? idWithCount[0].replace("Xpath", "Id")
      : idWithCount[0].includes("XPATH")
      ? idWithCount[0].replace("XPATH", "ID")
      : idWithCount[0].replace("xpath", "id");
    inputBox.innerText = idWithCount[0];
    var totalMatchingNode = idWithCount[1];
    var count = document.querySelector(".noOfMatch.id");
    count.textContent = totalMatchingNode;
    count.style.backgroundColor =
      totalMatchingNode == "1"
        ? "#0cb9a9"
        : totalMatchingNode == "0"
        ? "#ff0000"
        : "#f78f06";
  }
}

function generateClassName() {
  // var className = browserType.devtools.inspectedWindow.eval('generateClassName($0)', { useContentScriptContext: true }, function(result) {
  var inputBox = document.querySelector(".valueSelector.className");
  var classNameContainer = document.querySelector(".selectorsRow.className");
  classNameContainer.style.display = "";

  var classNameChoice = document.querySelector(".choose.className");
  if (!classNameChoice.checked) {
    classNameContainer.style.display = "none";
  }

  if (classNameWithCount === undefined || classNameWithCount[1] === 0) {
    classNameContainer.style.display = "none";
  } else {
    //linkTextHeight = 25;
    inputBox.setAttribute("selector", classNameWithCount[0]);
    // inputBox.setAttribute("title", result[0]);
    classNameWithoutCommand = classNameWithCount[0];
    classNameWithCount[0] = addDriverCommand.className.includes("inactive")
      ? classNameWithCount[0]
      : addPreCommandInSelector(classNameWithCount[0]);
    classNameWithCount[0] = classNameWithCount[0].includes("By.xpath")
      ? classNameWithCount[0].replace("By.xpath", "By.className")
      : classNameWithCount[0].includes("By(xpath")
      ? classNameWithCount[0].replace("By(xpath", "By(className")
      : classNameWithCount[0].includes("ByXPath")
      ? classNameWithCount[0].replace("ByXPath", "ByClassName")
      : classNameWithCount[0].includes("XPath")
      ? classNameWithCount[0].replace("XPath", "ClassName")
      : classNameWithCount[0].includes("Xpath")
      ? classNameWithCount[0].replace("Xpath", "ClassName")
      : classNameWithCount[0].includes("XPATH")
      ? classNameWithCount[0].replace("XPATH", "CLASSNAME")
      : classNameWithCount[0].replace("xpath", "className");
    inputBox.innerText = classNameWithCount[0];
    var totalMatchingNode = classNameWithCount[1];
    var count = document.querySelector(".noOfMatch.className");
    count.textContent = totalMatchingNode;
    count.style.backgroundColor =
      totalMatchingNode == "1"
        ? "#0cb9a9"
        : totalMatchingNode == "0"
        ? "#ff0000"
        : "#f78f06";
  }
  // });
}

function generateName() {
  // var name = browserType.devtools.inspectedWindow.eval('generateName($0)', { useContentScriptContext: true }, function(result) {
  var inputBox = document.querySelector(".valueSelector.name");
  var nameContainer = document.querySelector(".selectorsRow.name");
  nameContainer.style.display = "";

  var nameChoice = document.querySelector(".choose.name");
  if (!nameChoice.checked) {
    nameContainer.style.display = "none";
  }

  if (nameWithCount === undefined || nameWithCount.length === 0) {
    // result[0] = "couldn't find unique name.";
    nameContainer.style.display = "none";
  } else {
    //linkTextHeight = 25;
    inputBox.setAttribute("selector", nameWithCount[0]);
    // inputBox.setAttribute("title", result[0]);
    nameWithoutCommand = nameWithCount[0];
    nameWithCount[0] = addDriverCommand.className.includes("inactive")
      ? nameWithCount[0]
      : addPreCommandInSelector(nameWithCount[0]);
    nameWithCount[0] = nameWithCount[0].includes("By.xpath")
      ? nameWithCount[0].replace("By.xpath", "By.name")
      : nameWithCount[0].includes("By(xpath")
      ? nameWithCount[0].replace("By(xpath", "By(name")
      : nameWithCount[0].includes("ByXPath")
      ? nameWithCount[0].replace("ByXPath", "ByName")
      : nameWithCount[0].includes("XPath")
      ? nameWithCount[0].replace("XPath", "Name")
      : nameWithCount[0].includes("Xpath")
      ? nameWithCount[0].replace("Xpath", "Name")
      : nameWithCount[0].includes("XPATH")
      ? nameWithCount[0].replace("XPATH", "NAME")
      : nameWithCount[0].replace("xpath", "name");
    inputBox.innerText = nameWithCount[0];
    var totalMatchingNode = nameWithCount[1];
    var count = document.querySelector(".noOfMatch.name");
    count.textContent = totalMatchingNode;
    count.style.backgroundColor =
      totalMatchingNode == "1"
        ? "#0cb9a9"
        : totalMatchingNode == "0"
        ? "#ff0000"
        : "#f78f06";
  }
  // });
}

function generateTagName() {
  // var tagName = browserType.devtools.inspectedWindow.eval('generateTagName($0)', { useContentScriptContext: true }, function(result) {
  var inputBox = document.querySelector(".valueSelector.tagName");
  var tagNameContainer = document.querySelector(".selectorsRow.tagName");
  tagNameContainer.style.display = "";

  var tagNameChoice = document.querySelector(".choose.tagName");
  if (!tagNameChoice.checked) {
    tagNameContainer.style.display = "none";
  }

  if (tagNameWithCount === undefined || tagNameWithCount[1] === 0) {
    // result = "couldn't find unique tagName.";
    tagNameContainer.style.display = "none";
  } else {
    //linkTextHeight = 25;
    inputBox.setAttribute("selector", tagNameWithCount[0]);
    // inputBox.setAttribute("title", result[0]);
    tagNameWithoutCommand = tagNameWithCount[0];
    tagNameWithCount[0] = addDriverCommand.className.includes("inactive")
      ? tagNameWithCount[0]
      : addPreCommandInSelector(tagNameWithCount[0]);
    tagNameWithCount[0] = tagNameWithCount[0].includes("By.xpath")
      ? tagNameWithCount[0].replace("By.xpath", "By.tagName")
      : tagNameWithCount[0].includes("By(xpath")
      ? tagNameWithCount[0].replace("By(xpath", "By(tagName")
      : tagNameWithCount[0].includes("ByXPath")
      ? tagNameWithCount[0].replace("ByXPath", "ByTagName")
      : tagNameWithCount[0].includes("XPath")
      ? tagNameWithCount[0].replace("XPath", "TagName")
      : tagNameWithCount[0].includes("Xpath")
      ? tagNameWithCount[0].replace("Xpath", "TagName")
      : tagNameWithCount[0].includes("XPATH")
      ? tagNameWithCount[0].replace("XPATH", "TAGNAME")
      : tagNameWithCount[0].replace("xpath", "tagName");
    inputBox.innerText = tagNameWithCount[0];
    var totalMatchingNode = tagNameWithCount[1];
    var count = document.querySelector(".noOfMatch.tagName");
    count.textContent = totalMatchingNode;
    count.style.backgroundColor =
      totalMatchingNode == "1"
        ? "#0cb9a9"
        : totalMatchingNode == "0"
        ? "#ff0000"
        : "#f78f06";
  }
  setElementContainerHeight();
  //set the width of matching node numbers
  setWidthOfSelectorHeader();
  // });
}

function generateTestRigorPath() {
  var inputBox = document.querySelector(".valueSelector.testRigorPath");
  var testRigorPathContainer = document.querySelector(
    ".selectorsRow.testRigorPath"
  );
  testRigorPathContainer.style.display = "";

  var testRigorPathChoice = document.querySelector(".choose.testRigorPath");
  if (!testRigorPathChoice.checked) {
    testRigorPathContainer.style.display = "none";
  }

  if (testRigorPathWithCount === undefined || testRigorPathWithCount[1] === 0) {
    testRigorPathContainer.style.display = "none";
  } else {
    inputBox.setAttribute("selector", testRigorPathWithCount[0]);
    testRigorPathWithoutCommand = testRigorPathWithCount[0];
    //testRigorPathWithCount[0] = addDriverCommand.className.includes('inactive')?testRigorPathWithCount[0]:addPreCommandInSelector(testRigorPathWithCount[0]);
    //testRigorPathWithCount[0] = testRigorPathWithCount[0].includes("By.xpath")?testRigorPathWithCount[0].replace("By.xpath", "By.tagName"):testRigorPathWithCount[0].includes("By(xpath")?testRigorPathWithCount[0].replace("By(xpath", "By(tagName"):testRigorPathWithCount[0].includes("ByXPath")?testRigorPathWithCount[0].replace("ByXPath", "ByTagName"):testRigorPathWithCount[0].includes("XPath")?testRigorPathWithCount[0].replace("XPath", "TagName"):testRigorPathWithCount[0].includes("Xpath")?testRigorPathWithCount[0].replace("Xpath", "TagName"):testRigorPathWithCount[0].includes("XPATH")?testRigorPathWithCount[0].replace("XPATH", "TAGNAME"):testRigorPathWithCount[0].replace("xpath", "testRigorPath");
    inputBox.innerText = testRigorPathWithCount[0];
    var totalMatchingNode = testRigorPathWithCount[1];
    //no need to show cound for testRigor Path Count
    // var count = document.querySelector(".noOfMatch.testRigorPath");
    // count.textContent = totalMatchingNode;
    // count.style.backgroundColor = totalMatchingNode=="1"?"#0cb9a9":totalMatchingNode=="0"?"#ff0000":"#f78f06";
  }
  setElementContainerHeight();
  //set the width of matching node numbers
  setWidthOfSelectorHeader();
}

function generateLinkText() {
  // var linkText = browserType.devtools.inspectedWindow.eval('generateLinkText($0)', { useContentScriptContext: true }, function(result) {
  var inputBox = document.querySelector(".valueSelector.linkText");
  var linkTextContainer = document.querySelector(".selectorsRow.linkText");
  linkTextContainer.style.display = "";

  var linkTextChoice = document.querySelector(".choose.linkText");
  if (!linkTextChoice.checked) {
    linkTextContainer.style.display = "none";
  }

  if (linkTextWithCount === undefined || linkTextWithCount[1] === 0) {
    // result = "couldn't find unique linkText.";
    linkTextContainer.style.display = "none";
  } else {
    //linkTextHeight = 25;
    inputBox.setAttribute("selector", linkTextWithCount[0]);
    linkTextWithoutCommand = linkTextWithCount[0];
    // inputBox.setAttribute("title", result[0]);
    linkTextWithCount[0] = addDriverCommand.className.includes("inactive")
      ? linkTextWithCount[0]
      : addPreCommandInSelector(linkTextWithCount[0]);
    linkTextWithCount[0] = linkTextWithCount[0].includes("By.xpath")
      ? linkTextWithCount[0].replace("By.xpath", "By.linkText")
      : linkTextWithCount[0].includes("By(xpath")
      ? linkTextWithCount[0].replace("By(xpath", "By(linkText")
      : linkTextWithCount[0].includes("ByXPath")
      ? linkTextWithCount[0].replace("ByXPath", "ByLinkText")
      : linkTextWithCount[0].includes("XPath")
      ? linkTextWithCount[0].replace("XPath", "LinkText")
      : linkTextWithCount[0].includes("Xpath")
      ? linkTextWithCount[0].replace("Xpath", "LinkText")
      : linkTextWithCount[0].includes("XPATH")
      ? linkTextWithCount[0].replace("XPATH", "LINKTEXT")
      : linkTextWithCount[0].replace("xpath", "linkText");
    inputBox.innerText = linkTextWithCount[0];
    var totalMatchingNode = linkTextWithCount[1];
    var count = document.querySelector(".noOfMatch.linkText");
    count.textContent = totalMatchingNode;
    count.style.backgroundColor =
      totalMatchingNode == "1"
        ? "#0cb9a9"
        : totalMatchingNode == "0"
        ? "#ff0000"
        : "#f78f06";
  }
  // });
}

function generatePartialLinkText() {
  // var partialLinkText = browserType.devtools.inspectedWindow.eval('generatePartialLinkText($0)', { useContentScriptContext: true }, function(result) {
  var inputBox = document.querySelector(".valueSelector.partialLinkText");
  var partialLinkTextContainer = document.querySelector(
    ".selectorsRow.partialLinkText"
  );
  partialLinkTextContainer.style.display = "";

  var partialLinkTextChoice = document.querySelector(".choose.partialLinkText");
  if (!partialLinkTextChoice.checked) {
    partialLinkTextContainer.style.display = "none";
  }

  if (
    partialLinkTextWithCount === undefined ||
    partialLinkTextWithCount[1] === 0
  ) {
    // result = "couldn't find unique partialLinkText.";
    partialLinkTextContainer.style.display = "none";
  } else {
    // partialLinkTextHeight = 25;

    inputBox.setAttribute("selector", partialLinkTextWithCount[0]);
    partialLinkTextWithoutCommand = partialLinkTextWithCount[0];
    // inputBox.setAttribute("title", result[0]);
    partialLinkTextWithCount[0] = addDriverCommand.className.includes(
      "inactive"
    )
      ? partialLinkTextWithCount[0]
      : addPreCommandInSelector(partialLinkTextWithCount[0]);
    partialLinkTextWithCount[0] = partialLinkTextWithCount[0].includes(
      "By.xpath"
    )
      ? partialLinkTextWithCount[0].replace("By.xpath", "By.partialLinkText")
      : partialLinkTextWithCount[0].includes("By(xpath")
      ? partialLinkTextWithCount[0].replace("By(xpath", "By(partialLinkText")
      : partialLinkTextWithCount[0].includes("ByXPath")
      ? partialLinkTextWithCount[0].replace("ByXPath", "ByPartialLinkText")
      : partialLinkTextWithCount[0].includes("XPath")
      ? partialLinkTextWithCount[0].replace("XPath", "PartialLinkText")
      : partialLinkTextWithCount[0].includes("Xpath")
      ? partialLinkTextWithCount[0].replace("Xpath", "PartialLinkText")
      : partialLinkTextWithCount[0].includes("XPATH")
      ? partialLinkTextWithCount[0].replace("XPATH", "PARTIALLINKTEXT")
      : partialLinkTextWithCount[0].replace("xpath", "partialLinkText");
    inputBox.innerText = partialLinkTextWithCount[0];
    var totalMatchingNode = partialLinkTextWithCount[1];
    var count = document.querySelector(".noOfMatch.partialLinkText");
    count.textContent = totalMatchingNode;
    count.style.backgroundColor =
      totalMatchingNode == "1"
        ? "#0cb9a9"
        : totalMatchingNode == "0"
        ? "#ff0000"
        : "#f78f06";
  }
  // });
}

function updateGAEvents() {
  var idChecked = idAttr.checked ? "withid" : "withoutid";
  var classChecked = classAttr.checked ? "withclass" : "withoutclass";
  var nameChecked = nameAttr.checked ? "withname" : "withoutname";
  var placeholderChecked = placeholderAttr.checked;
  var textChecked = textCheckbox.checked;
}

// function generateSelectors() {

//     var idChecked = idAttr.checked?"withid":"withoutid";
//     var classChecked = classAttr.checked?"withclass":"withoutclass";
//     var nameChecked = nameAttr.checked?"withname":"withoutname";
//     var placeholderChecked = placeholderAttr.checked;
//     var textChecked = textCheckbox.checked;

//     chooseAttrs = [idChecked,classChecked,nameChecked];
//     var relXpathContainer = document.querySelector(".selectorsRow.relXpath");
//     var idContainer = document.querySelector(".selectorsRow.id");
//     var cssContainer = document.querySelector(".selectorsRow.cssSelector");
//     var classNameContainer = document.querySelector(".selectorsRow.className");
//     var nameContainer = document.querySelector(".selectorsRow.name");
//     var linkTextContainer = document.querySelector(".selectorsRow.linkText");
//     var partialLinkTextContainer = document.querySelector(".selectorsRow.partialLinkText");
//     var absXpathContainer = document.querySelector(".selectorsRow.absXpath");
//     var tagNameContainer = document.querySelector(".selectorsRow.tagName");

//     toggleElement = document.querySelector(".toggle-btn");
//     if(toggleElement.classList.contains("active")){

//         var inputBox = document.querySelector(".jsSelector");
//         var userSelectorValue = document.querySelector(".jsSelector").value;
//         var xpathOrCss = "xpath";
//         var CopyBtn = document.querySelector(".header-copy-btn");
//         inputBox.focus();
//         var editorTitle = document.querySelector(".editorTitle");
//         if(themeName==="dark"){
//             editorTitle.style.backgroundColor = "#e8b215";
//         }else{
//             editorTitle.style.backgroundColor = "#16bb94d1";
//         }

//         if(!multiSelectorRecordBtn.className.includes("red")){
//             relXpathContainer.style.display="";
//             idContainer.style.display="";
//             cssContainer.style.display="";
//             classNameContainer.style.display="";
//             nameContainer.style.display="";
//             linkTextContainer.style.display="";
//             partialLinkTextContainer.style.display="";
//             absXpathContainer.style.display="";
//             tagNameContainer.style.display="";
//         }

//         if(xpathOrCss.includes("xpath") || !xpathOrCss){
//             CopyBtn.setAttribute("title","click to copy selector value from box");

//             generateColoredRelXpath();
//             generateCss();

//             generateAbsXpath();
//             generateId();
//             generateClassName();
//             generateName();
//             generateLinkText();
//             generatePartialLinkText();
//             generateTagName();

//         }else if(xpathOrCss.includes("rel")){
//             relXpathContainer.style.display="";
//             idContainer.style.display="none";
//             cssContainer.style.display="none";
//             classNameContainer.style.display="none";
//             nameContainer.style.display="none";
//             linkTextContainer.style.display="none";
//             partialLinkTextContainer.style.display="none";
//             absXpathContainer.style.display="none";
//             tagNameContainer.style.display="none";
//             generateColoredRelXpath();
//         }else if(xpathOrCss.includes("abs")){
//             relXpathContainer.style.display="none";
//             idContainer.style.display="none";
//             cssContainer.style.display="none";
//             classNameContainer.style.display="none";
//             nameContainer.style.display="none";
//             linkTextContainer.style.display="none";
//             partialLinkTextContainer.style.display="none";
//             absXpathContainer.style.display="";
//             tagNameContainer.style.display="none";
//             generateAbsXpath();
//         }else if(xpathOrCss.includes("css")){
//             relXpathContainer.style.display="none";
//             idContainer.style.display="none";
//             cssContainer.style.display="";
//             classNameContainer.style.display="none";
//             nameContainer.style.display="none";
//             linkTextContainer.style.display="none";
//             partialLinkTextContainer.style.display="none";
//             absXpathContainer.style.display="none";
//             tagNameContainer.style.display="none";
//             generateCss();
//         }
//     }
// }

var chooseAttrs = [];
// var idCheckbox = document.querySelector(".id-xpath");
var idAttr = document.querySelector(".chooseAttr.id");
var classAttr = document.querySelector(".chooseAttr.class");
var nameAttr = document.querySelector(".chooseAttr.name");
var placeholderAttr = document.querySelector(".chooseAttr.placeholder");
var userAttrName = document.querySelector(".chooseAttr.user");
var textCheckbox = document.querySelector(".chooseAttr.textXpath");
var preCommandInput = document.querySelector(".driver-command");

userAttrName.addEventListener("keyup", function (event) {
  let key = event.which || event.keyCode;
  if (key === 13 && event.target.value === "what is my sh_id") {
    browserType.storage.local.set({ userAttrName: "" }, function () {});
    return;
  }
  var userAttr = userAttrName.value.trim();
  browserType.storage.local.set({ userAttrName: userAttr }, function () {});
});

browserType.storage.local.get(["userAttrName"], function (result) {
  userAttrName.value =
    result.userAttrName == undefined ? "" : result.userAttrName;
});

function chooseAttrsOption() {
  var userAttr = userAttrName.value.trim();
  // var idChecked = idCheckbox.checked?"withid":"withoutid";
  var idChecked = idAttr.checked ? "withid" : "withoutid";
  var classChecked = classAttr.checked ? "withclass" : "withoutclass";
  var nameChecked = nameAttr.checked ? "withname" : "withoutname";
  var placeholderChecked = placeholderAttr.checked
    ? "withplaceholder"
    : "withoutplaceholder";
  var textChecked = textCheckbox.checked ? "withtext" : "withouttext";

  chooseAttrs = [
    userAttr,
    idChecked,
    classChecked,
    nameChecked,
    placeholderChecked,
    textChecked,
  ];
}

function generateColoredRelXpath() {
  chooseAttrsOption();
  var totalMatchingNode = "";
  var xpathOrCss = "xpath";
  var relXpath = "";
  // var relXPath = browserType.devtools.inspectedWindow.eval('generateRelXpath($0, "'+chooseAttrs+'")', { useContentScriptContext: true }, function(result) {
  var inputBox = document.querySelector(".valueSelector.rel");
  var relXpathContainer = document.querySelector(".selectorsRow.relXpath");

  var relXpathChoice = document.querySelector(".choose.relXpath");
  if (!relXpathChoice.checked) {
    relXpathContainer.style.display = "none";
  }

  if (relXpathWithCount === undefined) {
    relXpath =
      "Element inside cross-origin iframe. Copy Selectors by right click on element or open iframe src url in new tab.";
    totalMatchingNode = "0";
  } else {
    relXpath = relXpathWithCount[0];
    totalMatchingNode = relXpathWithCount[1];
  }
  xpathWithoutCommand = relXpath;
  inputBox.setAttribute("selectors", relXpath);
  inputBox.setAttribute("relXpath", relXpath);
  // inputBox.setAttribute("title", relXpath);

  var preCommandValue = preCommandInput.value.trim();
  preCommandValue = preCommandValue.replace(/“/g, '"').replace(/”/g, '"');
  preCommandValue = preCommandValue.includes("cy.get")
    ? preCommandValue.replace("cy.get", "cy.xpath")
    : preCommandValue;
  var p1 = "";
  var p2 = "";
  if (
    !addDriverCommand.className.includes("inactive") &&
    relXpath !== undefined &&
    preCommandValue
  ) {
    var name = testRigorPathWithCount[0].replaceAll(`"`, ``);
    name = name ? name.slice(0, 30) : name;
    preCommandValue = preCommandValue.replace(
      /selectorname/i,
      toCamelCase(name)
    );

    if (preCommandValue.includes("xpathvalue")) {
      p1 = preCommandValue.split("xpathvalue")[0];
      p2 = preCommandValue.split("xpathvalue")[1];
    } else if (preCommandValue.includes("xpathValue")) {
      p1 = preCommandValue.split("xpathValue")[0];
      p2 = preCommandValue.split("xpathValue")[1];
    } else if (preCommandValue.includes("cssValue")) {
      p1 = preCommandValue.split("cssValue")[0];
      p2 = preCommandValue.split("cssValue")[1];
    } else if (preCommandValue.includes("cssvalue")) {
      p1 = preCommandValue.split("cssvalue")[0];
      p2 = preCommandValue.split("cssvalue")[1];
    } else if (preCommandValue.includes("cssSelectoValue")) {
      p1 = preCommandValue.split("cssSelectoValue")[0];
      p2 = preCommandValue.split("cssSelectoValue")[1];
    } else if (preCommandValue.includes("cssselectovalue")) {
      p1 = preCommandValue.split("cssselectovalue")[0];
      p2 = preCommandValue.split("cssselectovalue")[1];
    } else {
      p1 = preCommandValue.split(`"`)[0] + '"';
      p2 = '"' + preCommandValue.split(`"`)[2];
      // p2 = '"'+p2temp.split(`"`)[1];
    }
  }

  inputBox.innerHTML = "";
  var v0 = "//";

  var p1Tag = createElement("span", "p1-label");
  p1Tag.innerText = p1;
  inputBox.appendChild(p1Tag);

  var v0Tag = createElement("span", "v0-label");
  v0Tag.innerText = v0;
  inputBox.appendChild(v0Tag);

  var slash = "";
  var splitXpath = "";
  if (relXpath.slice(2).includes("//")) {
    splitXpath = relXpath.split("//");
    slash = "//";
  } else if (relXpath.slice(2).includes("/")) {
    splitXpath = relXpath.slice(1).split("/");
    slash = "/";
  } else {
    splitXpath = relXpath.split("//");
  }

  if (!relXpath.includes("[")) {
    inputBox.removeChild(v0Tag);
    var absTag = createElement("span", "abs-label");
    absTag.innerText = relXpath;
    inputBox.appendChild(absTag);
  } else {
    for (var i = 1; i < splitXpath.length; i++) {
      var v1 = "";
      if (!splitXpath[i].includes("[")) {
        if (i === 1) {
          v1 = splitXpath[i];
        } else {
          v1 = slash + splitXpath[i];
        }
        var v1Tag = createElement("span", "v1-label");
        v1Tag.innerText = v1;
        inputBox.appendChild(v1Tag);
      } else {
        if (i === 1) {
          v1 = splitXpath[i].split("[")[0] + "[";
        } else {
          v1 = slash + splitXpath[i].split("[")[0] + "[";
        }
        var v1Tag = createElement("span", "v1-label");
        v1Tag.innerText = v1;
        inputBox.appendChild(v1Tag);

        if (
          !splitXpath[i].split("[")[1].includes("'") ||
          splitXpath[i].split("'").length > 3
        ) {
          var v8Tag = createElement("span", "v4-label");
          // var v8 = splitXpath[i].split("[")[1];
          var v8 = splitXpath[i].substr(splitXpath[i].indexOf("[") + 1);
          v8Tag.innerText = v8;
          inputBox.appendChild(v8Tag);
        } else {
          var v2 = splitXpath[i].split("[")[1].split("'")[0] + "'";

          var v3 = splitXpath[i].split("[")[1].split("'")[1];

          var v4 = "'" + splitXpath[i].split("[")[1].split("'")[2];

          if (!v3) {
            v3 = splitXpath[i].split("'")[1].split("'")[0];
            v4 = "'" + splitXpath[i].split("'")[2];
          }

          var v2Tag = createElement("span", "v2-label");
          v2Tag.innerText = v2.includes(undefined) ? "" : v2;
          inputBox.appendChild(v2Tag);

          var v3Tag = createElement("span", "v3-label");
          v3Tag.innerText = v3.includes(undefined) ? "" : v3;
          inputBox.appendChild(v3Tag);

          var v4Tag = createElement("span", "v4-label");
          v4Tag.innerText = v4.includes(undefined) ? "" : v4;
          inputBox.appendChild(v4Tag);

          if (splitXpath[i].split("['").length > 2) {
            if ("[" + splitXpath[i].split("[")[2].split("'")[0].length > 1) {
              var v5 = "[" + splitXpath[i].split("[")[2].split("'")[0] + "'";
              var v6 = splitXpath[i].split("[")[2].split("'")[1];
              var v7 = "'" + splitXpath[i].split("[")[2].split("'")[2];

              var v5Tag = createElement("span", "v2-label");
              v5Tag.innerText = v5.includes(undefined) ? "" : v5;
              inputBox.appendChild(v5Tag);

              var v6Tag = createElement("span", "v3-label");
              v6Tag.innerText = v6.includes(undefined) ? "" : v6;
              inputBox.appendChild(v6Tag);

              var v7Tag = createElement("span", "v4-label");
              v7Tag.innerText = v7.includes(undefined) ? "" : v7;
              inputBox.appendChild(v7Tag);
            } else {
              var v5 = "[" + splitXpath[i].split("[")[2].split("'")[0];
              var v5Tag = createElement("span", "v2-label");
              v5Tag.innerText = v5.includes(undefined) ? "" : v5;
              inputBox.appendChild(v5Tag);
            }
          }
        }
      }
    }
  }
  var p2Tag = createElement("span", "p2-label");
  p2Tag.innerText = p2;
  inputBox.appendChild(p2Tag);
  document.querySelector(".noOfMatch.relXpath").textContent = totalMatchingNode;

  document.querySelector(".noOfMatch.relXpath").style.backgroundColor =
    totalMatchingNode == "1"
      ? "#0cb9a9"
      : totalMatchingNode == "0"
      ? "#ff0000"
      : "#f78f06";

  var alertTitle = "";
  var warningIcon = document.querySelector(".warningIcon");
  var alertToolTip = document.querySelector(".alert.toolTip");
  var matchingNodesContainer = document.querySelector(".noOfMatch.relXpath");
  warningIcon.style.display = "none";
  // matchingNodesContainer.style.marginLeft = "6px";
  if (relXpath) {
    if (relXpathWithCount[2] || relXpathWithCount[3]) {
      warningIcon.style.display = "";
      if (OS.includes("mac")) {
        warningIcon.parentElement.style.verticalAlign = "baseline";
      }
      // matchingNodesContainer.style.marginLeft = relXpathMatchingNodeLeft;
      if (relXpathWithCount[2] && relXpathWithCount[3]) {
        alertTitle =
          "id & class both look dynamic. \nUncheck the id & class checkbox to generate rel xpath\n without them if it is generated with them.";
      } else if (relXpathWithCount[2]) {
        alertTitle =
          relXpathWithCount[2] +
          " looks dynamic. Uncheck the " +
          relXpathWithCount[2] +
          "\n checkbox or delete the " +
          relXpathWithCount[2] +
          " attribute from attribute box to\n generate rel xpath without " +
          relXpathWithCount[2] +
          " if it is generated with " +
          relXpathWithCount[2] +
          ".";
      } else {
        warningIcon.style.display = "none";
        warningIcon.parentElement.style.verticalAlign = "text-bottom";
      }
      alertToolTip.innerText = alertTitle;
    }
  }
  if (
    relXpath.toLowerCase().includes("this element is inside") &&
    relXpath.toLowerCase().includes("shadow dom")
  ) {
    insideShadowDom = true;
    //selectElements("css", false);
  } else {
    //selectElements(xpathOrCss, false);
    insideShadowDom = false;
  }
  if (xpathOrCss.includes("rel")) {
    setElementContainerHeight();
    // document.querySelector(".noOfMatch.relXpath").parentElement.style.width = "26px";
  }
  //});
}

var highlightWrongXpath = function () {
  var inputBox = document.querySelector(".selectors-input");
  inputBox.className += " wrongXpath";
};

var removeWrongXpath = function () {
  try {
    var inputBox = document.querySelector(".selectors-input.wrongXpath");
    inputBox.classList.remove("wrongXpath");
    document.querySelector(".jsTotalMatchCount").textContent = "";
    var errorInfo = document.querySelector(".errorInfo");
    let fixSelectorBtn = document.querySelector("#fix-selector");
    var cheetSheetLink = document.querySelector(".cheetSheetLink");
    errorInfo.textContent = "";
    errorInfo.className += " hideMatchCountMsg";
    fixSelectorBtn.className = "hideMatchCountMsg fix-selector-success";
    fixSelectorBtn.children[1].innerText = "Fix Selector";
    cheetSheetLink.className += " hideMatchCountMsg";
    document.querySelector(".jsTotalMatchCount").style.padding =
      "0px 0px 0px 0px";
  } catch (err) {}
};

var checkWrongXpath = function () {
  var inputBox = document.querySelector(".jsSelector");
  var xpathValue = inputBox.value;
  var totalCountElem = document.querySelector(".jsTotalMatchCount");
  var errorInfo = document.querySelector(".errorInfo");
  var cheetSheetLink = document.querySelector(".errorInfo");
  let fixSelectorBtn = document.querySelector("#fix-selector");
  var xpathOrCss = "";
  if (
    !insideShadowDom &&
    (!xpathValue ||
      xpathValue.charAt(0).includes("/") ||
      xpathValue.substr(0, 2).includes("./") ||
      xpathValue.charAt(0).includes("(") ||
      xpathValue === ".")
  ) {
    xpathOrCss = "XPath";
  } else {
    xpathOrCss = "CSS";
  }
  if (!xpathValue) {
    totalCountElem.className += " hideMatchCountMsg";
    errorInfo.className += " hideMatchCountMsg";
    fixSelectorBtn.className = "hideMatchCountMsg fix-selector-success";
    fixSelectorBtn.children[1].innerText = "Fix Selector";
    cheetSheetLink.className += " hideMatchCountMsg";
    selectElements(xpathOrCss, false);
    clearElements();
  }
  if (inputBox.getAttribute("class").includes("wrongXpath")) {
    removeWrongXpath();
  }

  if (xpathValue) {
    try {
      if(isSidePanelView){
        getActiveTabId().then(tabId => {
            postSafeMessage({
                name: "check-invalid-selector",
                xpathValue,
                tabId
            })
        })
      }else{
        browserType.devtools.inspectedWindow.eval(
          "checkInvalidSelector(`" + xpathValue + "`)",
          { useContentScriptContext: true },
          function (result) {
            if (result) {
              highlightWrongXpath();
            }
          }
        );
      }
      // if(xpathOrCss.includes("XPath")){
      //     elements = document.evaluate(xpathValue, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      // }else if(xpathOrCss==="CSS"){
      //     elements = document.querySelectorAll(xpathValue);
      // }
    } catch (err) {
      if (
        xpathValue.slice(0, 9).includes("document.") ||
        xpathValue.slice(0, 2).includes("$(")
      ) {
      } else {
        highlightWrongXpath();
      }
    }
  }
};

var clearElements = function () {
  var listElements = document.querySelector("#selectorsHubEleContainer");
  var countElement = document.querySelector(".jsTotalMatchCount");
  var errorInfo = document.querySelector(".errorInfo");
  var cheetSheetLink = document.querySelector(".cheetSheetLink");
  var inputBoxValue = document.querySelector(".jsSelector").value;
  countElement.innerHTML = "";
  errorInfo.innerHTML = "";
  countElement.style.padding = "0px 0px 0px 0px";
  toggleElement = document.querySelector(".toggle-btn");
  if (
    bothListOfTextAndAttr.length >= 0 ||
    toggleElement.classList.contains("inactive")
  ) {
    listElements.innerHTML = "";
  }
};
if(!isSidePanelView){
  browserType.devtools.panels.elements.onSelectionChanged.addListener(
    function () {
      if (!multiSelectorRecord.className.includes("red")) {
        generateSelectors();
      }
      setElementContainerHeight();
    }
  );
}

function changeBackground(event) {
  var color = event.target.value;
  document.body.style.background = color;
}

// document.querySelector(".theme-color").addEventListener("change",changeBackground);

var createElement = function (elementName, classList) {
  var element = document.createElement(elementName);

  if (classList) {
    element.setAttribute("class", classList);
  }

  return element;
};

var elementRegEx = /(?:^(<.+?>)(.+)(<\/.+?>)$)|(?:^(<.+?>)$)/;

var getOpenCloseTag = function (element) {
  var matches = elementRegEx.exec(element.outerHTML);
  var openTag = "",
    closeTag = "";
  if (matches) {
    openTag = matches[1] ? matches[1] : matches[0];
    closeTag = matches[3] ? matches[3] : "";
  }
  return {
    openTag: openTag,
    closeTag: closeTag,
  };
};

var getTextNodeWrapper = function (textNode) {
  /* get wrapper node for a text node */
  var wrapper = createElement("div", "child level-padding");
  wrapper.innerText = textNode.textContent;
  return wrapper;
};

var getWrapperNode = function (element, classList) {
  var openCloseTag = getOpenCloseTag(element);

  if (element.nodeType === Node.TEXT_NODE) {
    /* text node, just wrap in a div and return */
    return getTextNodeWrapper(element);
  }

  if (
    element.childNodes &&
    element.childNodes.length === 0 &&
    !element.textContent
  ) {
    /* reached a leaf node */
    classList = "leaf-node level-padding";
  }

  /* add open tag */
  var wrapper = createElement("div", classList);
  var openTagText = createElement("span", "open-tag-label");
  openTagText.innerText = openCloseTag.openTag;
  wrapper.appendChild(openTagText);

  /* get children tags */
  if (
    (element.childNodes && element.childNodes.length > 0) ||
    element.textContent
  ) {
    /* element has children, recursively parse them */
    childElements = convertToTreeStructure(
      element,
      "child level-padding closed"
    );
    wrapper.appendChild(childElements);
  }

  /* add close tag */
  var closeTagText = createElement("span", "close-tag-label");
  closeTagText.innerText = openCloseTag.closeTag;
  wrapper.appendChild(closeTagText);
  return wrapper;
};

var convertToTreeStructure = function (node, classList) {
  var element, openTag;
  var childElements, wrapper;
  if (!node.childElementCount) {
    /* reached a text node */
    classList = "text-node level-padding";
    wrapper = createElement("div", classList);
    wrapper.innerText = node.textContent;
    return wrapper;
  }

  if (node.childNodes.length > 1) {
    /* loop & recurse through all children */
    var children = node.childNodes;
    var parentWrapper = createElement("div", classList + " children-cont");
    for (var i = 0; i < children.length; i++) {
      element = children[i];
      wrapper = getWrapperNode(element, "child closed");
      parentWrapper.appendChild(wrapper);
    }
    return parentWrapper;
  } else {
    /* element has only one child */
    element = node.childNodes[0];
    wrapper = getWrapperNode(element, classList);
    return wrapper;
  }
};

var onClickHandler = function (event) {
  event.preventDefault();
  event.stopPropagation();
  var target = event.target;
  var idName = target.id;
  if (!idName.includes("selectorsHubEleContainer")) {
    if (document.querySelector(".selectedNode")) {
      if (themeName === "dark") {
        document.querySelector(".selectedNode").style.backgroundColor =
          "#2f2d2d8c";
      } else {
        document.querySelector(".selectedNode").style.backgroundColor = "white";
      }
      document.querySelector(".selectedNode").classList.remove("selectedNode");
    }
    target.classList.add("selectedNode");
    target.style.backgroundColor = "#9e9e9e5c";
  }
  var classes = target.className;

  if (
    !classes.includes("open-tag-label") &&
    !classes.includes("close-tag-label") &&
    classes.length != 0 &&
    !idName.includes("selectorsHubEleContainer")
  ) {
    if (classes) {
      if (classes.indexOf("open") !== -1) {
        target.classList.remove("open");
        target.classList.add("closed");
      } else {
        target.classList.add("open");
        target.classList.remove("closed");
      }
    } else {
      target.classList.add("open");
    }
  }
};

var addClickHandlers = function () {
  var parentElement = document.querySelector("#selectorsHubEleContainer");
  parentElement.addEventListener("click", onClickHandler);
};

// selectorInput.addEventListener('dblclick', function (e) {
//     copyBoxValueToClipboard();
//     showCopied();
// });

var clickToCopyBoxValue = function () {
  var copyText = document.querySelector(".header-copy-btn");
  copyText.addEventListener("click", copyBoxValueToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyBoxValueToClipboard = function () {
  var text = document.querySelector(".selectors-input.jsSelector");
  text.select();
  document.execCommand("Copy");
};

var clickToCopyRelXpath = function () {
  var copyText = document.querySelector(".relXpathCopyBtn");
  copyText.addEventListener("click", copyRelXpathToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copyRelXpathToClipboard = function () {
  copyToClipboard(".valueSelector.rel");
};

var clickToCopyIframeXpath = function () {
  var copyText = document.querySelector(".iframeCopyBtn");
  copyText.addEventListener("click", copyIframeXpathToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copyIframeXpathToClipboard = function () {
  copyToClipboard(".valueSelector.iframeXpath");
};

var clickToCopySuggestedXpath = function () {
  var copyText = document.querySelector(".suggestedCopyBtn");
  copyText.addEventListener("click", copySuggestedXpathToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copySuggestedXpathToClipboard = function () {
  copyToClipboard(".valueSelector.suggestedXpath");
};

var clickToCopyIndexXpath = function () {
  var copyText = document.querySelector(".indexXpathCopyBtn");
  copyText.addEventListener("click", copyIndexXpathToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copyIndexXpathToClipboard = function () {
  copyToClipboard(".valueSelector.indexXpath");
};

var clickToCopyId = function () {
  var copyText = document.querySelector(".idCopyBtn");
  copyText.addEventListener("click", copyIdToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copyIdToClipboard = function () {
  copyToClipboard(".valueSelector.id");
};

var clickToCopyClassName = function () {
  var copyText = document.querySelector(".classNameCopyBtn");

  copyText.addEventListener("click", copyClassNameToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copyClassNameToClipboard = function () {
  copyToClipboard(".valueSelector.className");
};

var clickToCopyName = function () {
  var copyText = document.querySelector(".nameCopyBtn");
  copyText.addEventListener("click", copyNameToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copyNameToClipboard = function () {
  copyToClipboard(".valueSelector.name");
};

var clickToCopyTagName = function () {
  var copyText = document.querySelector(".tagNameCopyBtn");
  copyText.addEventListener("click", copyTagNameToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copyTagNameToClipboard = function () {
  copyToClipboard(".valueSelector.tagName");
};

var clickToCopyTestRigorPath = function () {
  var copyText = document.querySelector(".testRigorPathCopyBtn");
  copyText.addEventListener("click", copyTestRigorPathToClipboard);
  copyText.addEventListener("click", showCopied);
};

var copyTestRigorPathToClipboard = function () {
  copyToClipboard(".valueSelector.testRigorPath");
};

var clickToCopyAbsXpath = function () {
  var copyText = document.querySelector(".absCopyBtn");
  copyText.addEventListener("click", copyAbsXpathToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyAbsXpathToClipboard = function () {
  copyToClipboard(".valueSelector.abs");
};

var clickToCopyCss = function () {
  var copyText = document.querySelector(".cssCopyBtn");
  copyText.addEventListener("click", copyCssToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyCssToClipboard = function () {
  copyToClipboard(".valueSelector.css");
};

var clickToCopyJQuery = function () {
  var copyText = document.querySelector(".jQueryCopyBtn");

  copyText.addEventListener("click", copyJQueryToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyJQueryToClipboard = function () {
  copyToClipboard(".valueSelector.jQuery");
};

var clickToCopyJsPath = function () {
  var copyText = document.querySelector(".jsPathCopyBtn");

  copyText.addEventListener("click", copyJsPathToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyJsPathToClipboard = function () {
  copyToClipboard(".valueSelector.jsPath");
};

var clickToCopyLinkText = function () {
  var copyText = document.querySelector(".linkTextCopyBtn");
  copyText.addEventListener("click", copyLinkTextToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyLinkTextToClipboard = function () {
  copyToClipboard(".valueSelector.linkText");
};

var clickToCopyPartialLinkText = function () {
  var copyText = document.querySelector(".partialLinkTextCopyBtn");
  copyText.addEventListener("click", copyPartialLinkTextToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyPartialLinkTextToClipboard = function () {
  copyToClipboard(".valueSelector.partialLinkText");
};

var clickToCopyAxesXpath = function () {
  var copyText = document.querySelector(".axesXpathCopyBtn");
  copyText.addEventListener("click", copyAxesXpathToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyAxesXpathToClipboard = function () {
  copyToClipboard(".axesXpath.axesXpathEditBtn");
};

var clickToCopyLastAxesXpath = function () {
  var copyText = document.querySelector(".lastAxesXpathCopyBtn");
  copyText.addEventListener("click", copyLastAxesXpathToClipboard);
  copyText.addEventListener("click", showCopied);
};
var copyLastAxesXpathToClipboard = function () {
  copyToClipboard(".lastAxesXpath.lastAxesXpathEditBtn");
};

var nestedCodeCopyBtn = document.querySelector(
  ".copy-btn.box.nestedCodeCopyBtn"
);

nestedCodeCopyBtn.addEventListener("click", function () {
  trackEvent("copy nested code");
  if (nestedCodeCopyBtn.classList.contains("notPatron")) {
    patronModal.style.display = "block";
  }

  if (!nestedCodeCopyBtn.classList.contains("notPatron")) {
    copyNestedCodeToClipboard();
    showCopied();
  }
});

// var clickToCopyNestedCode = function() {

//     if(nestedCodeCopyBtn.classList.contains("notPatron")){
//         patronModal.style.display = "block";
//     }

//     if(!nestedCodeCopyBtn.classList.contains("notPatron")){
//         copyText.addEventListener("click", copyNestedCodeToClipboard);
//         copyText.addEventListener("click", showCopied);
//     }
// };

var copyNestedCodeToClipboard = function () {
  copyToClipboard("#nestedCode");
};

function addPreCommandInSelector(selectorsValue) {
  var preCommandValue = preCommandInput.value.trim();
  preCommandValue = preCommandValue.replace(/“/g, '"').replace(/”/g, '"');

  var finalValue = "";
  if (
    preCommandValue.includes("xpathvalue") ||
    preCommandValue.includes("xpathValue")
  ) {
    finalValue = preCommandValue.includes("xpathvalue")
      ? preCommandValue.replace("xpathvalue", selectorsValue)
      : preCommandValue.replace("xpathValue", selectorsValue);
  } else if (preCommandValue) {
    // var tempV1 = preCommandValue.split(`"`)[1];
    // var v1 = tempV1.split(`"`)[0];

    // if(v1){
    //     finalValue = preCommandValue.replace(v1, selectorsValue);
    // }else{
    finalValue =
      preCommandValue.split(`"`)[0] +
      '"' +
      selectorsValue +
      '"' +
      preCommandValue.split(`"`)[2];
    //}
  } else {
    finalValue = selectorsValue;
  }

  if (finalValue && finalValue.toLowerCase().includes("selectorname")) {
    var name = testRigorPathWithCount[0].replaceAll(`"`, ``);
    name = name ? name.slice(0, 30) : name;
    finalValue = finalValue.replace(/selectorname/i, toCamelCase(name));
  }
  return finalValue;
}

preCommandInput.addEventListener("keyup", onUpdateCommand);

function onUpdateCommand(event) {
  trackEvent("Entered driver command");
  var preCommandInpt = preCommandInput.value.trim();
  preCommandInpt = preCommandInpt.replace(/“/g, '"').replace(/”/g, '"');
  browserType.storage.local.set(
    { preCommandValue: preCommandInpt },
    function () {}
  );
  if (preCommandInpt && !preCommandInpt.toLowerCase().includes("xpathvalue")) {
    preCommandInput.classList.add("wrongXpath");
    // document.querySelector('.commandTip').style.visibility = "visible";
    addDriverCommand.classList.add("inactive");
    addDriverCommand.classList.remove("active");
  } else if (
    !preCommandInpt ||
    preCommandInpt.toLowerCase().includes("xpathvalue")
  ) {
    preCommandInput.classList.remove("wrongXpath");
    // document.querySelector('.commandTip').style.visibility = "hidden";
    addDriverCommand.classList.add("active");
    addDriverCommand.classList.remove("inactive");
  }
}

browserType.storage.local.get(["preCommandValue"], function (result) {
  preCommandInput.value =
    result.preCommandValue == undefined
      ? 'driver.findElement(By.xpath("xpathvalue"))'
      : result.preCommandValue;
});

function copyToClipboard(elementSelectorToCopy) {
  trackEvent("Copy " + elementSelectorToCopy);
  var text = document.querySelector(elementSelectorToCopy);

  let textarea = document.createElement("textarea");
  textarea.id = "t";
  // Optional step to make less noise on the page, if any!
  textarea.style.height = 0;
  // Now append it to your page somewhere, I chose <body>
  document.body.appendChild(textarea);
  // Give our textarea a value of whatever inside the div of id=containerid
  textarea.value = text.innerText == "" ? text.textContent : text.innerText;

  // Now copy whatever inside the textarea to clipboard
  let selector = document.querySelector("#t");
  selector.select();
  document.execCommand("copy");
  // Remove the textarea
  document.body.removeChild(textarea);
}

function copyAllRowsToClipboard(allRows) {
  let textarea = document.createElement("textarea");
  textarea.id = "t";
  // Optional step to make less noise on the page, if any!
  textarea.style.height = 0;
  // Now append it to your page somewhere, I chose <body>
  document.body.appendChild(textarea);
  // Give our textarea a value of whatever inside the div of id=containerid
  // var allRows = document.querySelectorAll(".xpath.selectorValue");

  if (multiSelectorRecord.className.includes("grey")) {
    for (var i = 1; i < allRows.length; i++) {
      let value =
        allRows[i].innerText.split(" ").length > 1
          ? allRows[i].innerText.split(" ").slice(1).join("")
          : allRows[i].innerText;
      textarea.value = textarea.value + "\n" + (value.length > 3 ? value : "");
    }
  } else {
    for (var i = 1; i < allRows.length; i++) {
      textarea.value = textarea.value + "\n" + allRows[i].innerText;
    }
  }

  let selector = document.querySelector("#t");
  selector.select();
  document.execCommand("copy");
  // Remove the textarea
  document.body.removeChild(textarea);
}

var clickToEditIframeXpath = function () {
  var editText = document.querySelector(".iframeEditBtn");
  editText.addEventListener("click", editIframeXpath);
};
var editIframeXpath = function () {
  editSelector(".valueSelector.iframeXpath");
};

var clickToEditSuggestedXpath = function () {
  var editText = document.querySelector(".suggestedEditBtn");
  editText.addEventListener("click", editSuggestedXpath);
};
var editSuggestedXpath = function () {
  editSelector(".valueSelector.suggestedXpath");
};

var clickToEditRelXpath = function () {
  var editText = document.querySelector(".relXpathEditBtn");
  editText.addEventListener("click", editRelXpath);
};
var editRelXpath = function () {
  editSelector(".valueSelector.rel");
};

var clickToEditIndexXpath = function () {
  var editText = document.querySelector(".indexXpathEditBtn");
  editText.addEventListener("click", editIndexXpath);
};
var editIndexXpath = function () {
  editSelector(".valueSelector.indexXpath");
};

var clickToEditId = function () {
  var editText = document.querySelector(".idEditBtn");
  editText.addEventListener("click", editId);
};
var editId = function () {
  editSelector(".valueSelector.id");
};

var clickToEditName = function () {
  var editText = document.querySelector(".nameEditBtn");
  editText.addEventListener("click", editName);
};
var editName = function () {
  editSelector(".valueSelector.name");
};

var clickToEditClassName = function () {
  var editText = document.querySelector(".classNameEditBtn");
  editText.addEventListener("click", editClassName);
};
var editClassName = function () {
  editSelector(".valueSelector.className");
};

var clickToEditAbsXpath = function () {
  var editText = document.querySelector(".absEditBtn");
  editText.addEventListener("click", editAbsXpath);
};
var editAbsXpath = function () {
  editSelector(".valueSelector.abs");
};

var clickToEditCss = function () {
  var editText = document.querySelector(".cssEditBtn");
  editText.addEventListener("click", editCss);
};
var editCss = function () {
  editSelector(".valueSelector.css");
};

var clickToEditJQuery = function () {
  var editText = document.querySelector(".jQueryEditBtn");
  editText.addEventListener("click", editJQuery);
};
var editJQuery = function () {
  editSelector(".valueSelector.jQuery");
};

var clickToEditJsPath = function () {
  var editText = document.querySelector(".jsPathEditBtn");
  editText.addEventListener("click", editJsPath);
};
var editJsPath = function () {
  editSelector(".valueSelector.jsPath");
};

var clickToEditLinkText = function () {
  var editText = document.querySelector(".linkTextEditBtn");
  editText.addEventListener("click", editLinkText);
};
var editLinkText = function () {
  editSelector(".valueSelector.linkText");
};

var clickToEditPartialLinkText = function () {
  var editText = document.querySelector(".partialLinkTextEditBtn");
  editText.addEventListener("click", editPartialLinkText);
};
var editPartialLinkText = function () {
  editSelector(".valueSelector.partialLinkText");
};

var clickToEditTagName = function () {
  var editText = document.querySelector(".tagNameEditBtn");
  editText.addEventListener("click", editTagName);
};
var editTagName = function () {
  editSelector(".valueSelector.tagName");
};

var clickToEditTestRigorPath = function () {
  var editText = document.querySelector(".testRigorPathEditBtn");
  editText.addEventListener("click", editTestRigorPath);
};
var editTestRigorPath = function () {
  editSelector(".valueSelector.TestRigorPath");
};

var clickToEditAxesXpath = function () {
  var editText = document.querySelector(".axesXpathEditBtn");
  editText.addEventListener("click", editAxesXpath);
};
var editAxesXpath = function () {
  editSelector(".axesXpath.axesXpathEditBtn");
};

var clickToEditLastAxesXpath = function () {
  var editText = document.querySelector(".lastAxesXpathEditBtn");
  editText.addEventListener("click", editLastAxesXpath);
};
var editLastAxesXpath = function () {
  editSelector(".lastAxesXpath.lastAxesXpathEditBtn");
};

var editSelector = function (selectorToEdit) {
  trackEvent("Edit " + selectorToEdit);
  var selectorValue = document.querySelector(selectorToEdit).innerText;
  var inputBox = document.querySelector(".jsSelector");
  inputBox.value = selectorValue;
  inputBox.focus();
  // document.execCommand("selectAll");
  // document.execCommand("insertText", false, selectorValue);
};

function buttonMouseHover(ele, imgSrc) {
  // ele.style.boxShadow= "0 2px 2px 0 black";
  ele.style.outline = "0.01em solid #73bde2f2";
  ele.style.backgroundImage = "url('../icons/" + imgSrc + "')";
}
function buttonMouseOut(ele, imgSrc) {
  if (themeName === "dark") {
    imgSrc = imgSrc.replace("grey", "orange");
  }
  ele.style.boxShadow = "";
  ele.style.outline = "";
  ele.style.backgroundImage = "url('../icons/" + imgSrc + "')";
}

function selectorContainerMouseHover(ele) {
  if (themeName === "dark") {
    ele.style.backgroundColor = "#6f6868";
  } else {
    ele.style.backgroundColor = "#e3e8ea";
  }
}
function selectorContainerMouseOut(ele) {
  ele.style.backgroundColor = "";
}

// var newFeatureBanner = document.querySelector("#newFeatureBanner");
//   newFeatureBanner.addEventListener("mouseover", function() {
//   this.stop();
// });

// newFeatureBanner.addEventListener("mouseout", function() {
//   this.start();
// });

// // enable this to remove the review request msg
// setTimeout(function(){ document.querySelector(".reviewRequest").style.display="none";
//   document.querySelector("#selectorsHubEleContainer").style.height = 'calc(100% - 60px)';
// }, 15000);

var buttons = document.querySelectorAll("button");
toggleElement.addEventListener("click", function () {
  trackEvent("Right Toggle");
  // if(toggleElement.classList.contains("notPatron")){
  //     patronModal.style.display = "block";
  // }

  // if(!toggleElement.classList.contains("notPatron")){
  toggleAction();
  generateSelectors();
  // }
});

function toggleAction() {
  var infoPlaceholder = document.querySelector(".infoPlaceholder div");
  var infoPlaceholderParent = document.querySelector(".infoPlaceholder");
  var shubGenerator = document.querySelector(".shub-generator");
  var configOptions = document.querySelector(".configOptions");
  var selectorsHubEleContainer = document.querySelector(
    ".selectorsHubEleContainer"
  );
  var nestedCode = document.querySelector("#nestedCode");
  var nestedBlock = document.querySelector("#nestedBlock");
  if (toggleElement.classList.contains("inactive")) {
    infoPlaceholder.style.display = "none";
    infoPlaceholderParent.style.display = "none";
    browserType.storage.local.set({ toggleElement: "active" }, function () {});
    toggleElement.classList.remove("inactive");
    toggleElement.classList.add("active");
    // for(var i=0; i<buttons.length; i++){
    //     buttons[i].disabled = false;
    // }
    shubGenerator.style.display = "block";
    configOptions.style.visibility = "visible";
  } else {
    infoPlaceholder.style.display = "block";
    infoPlaceholderParent.style.display = "block";
    browserType.storage.local.set(
      { toggleElement: "inactive" },
      function () {}
    );
    toggleElement.classList.remove("active");
    toggleElement.classList.add("inactive");
    // for(var i=0; i<buttons.length; i++){
    //     buttons[i].disabled = true;
    // }
    shubGenerator.style.display = "none";
    configOptions.style.visibility = "hidden";
    nestedBlock.style.display = "none";
    nestedCode.textContent = "";
    clearElements();
  }
  var toggleBtnToolTip = document.querySelector(".toggle.toolTip");
  if (toggleElement.classList.contains("inactive")) {
    toggleBtnToolTip.textContent = "Turn on to get auto generated selectors.";
    var xpathOrCss = "xpath";
    var onChange = false;

    var xpath = [xpathOrCss, "", onChange];
    if(isSidePanelView){
      getActiveTabId().then(tabId => {
        postSafeMessage({
          name: "highlight-element",
          tabId,
          xpath: xpath,
        });
      })
    }else{
      postSafeMessage({
        name: "highlight-element",
        tabId: browserType.devtools.inspectedWindow.tabId,
        xpath: xpath,
      });
    }
  } else {
    //multiSelectorContainer.style.display="none";
    toggleBtnToolTip.textContent = "Turn off auto generated selectors.";
  }
}

browserType.storage.local.get(["classChecked"], function (result) {
  classAttr.checked =
    result.classChecked == undefined ? true : result.classChecked;
});
browserType.storage.local.get(["nameChecked"], function (result) {
  nameAttr.checked =
    result.nameChecked == undefined ? true : result.nameChecked;
});
browserType.storage.local.get(["placeholderChecked"], function (result) {
  placeholderAttr.checked =
    result.placeholderChecked == undefined ? true : result.placeholderChecked;
});
browserType.storage.local.get(["idChecked"], function (result) {
  idAttr.checked = result.idChecked == undefined ? true : result.idChecked;
});
// browserType.storage.local.get(['idCheckboxChecked'], function(result){
//     idCheckbox.checked=result.idCheckboxChecked==undefined?true:result.idCheckboxChecked;
// });
browserType.storage.local.get(["textCheckboxChecked"], function (result) {
  textCheckbox.checked =
    result.textCheckboxChecked == undefined ? true : result.textCheckboxChecked;
});

textCheckbox.addEventListener("click", function () {
  trackEvent("text checkbox");
  var textCheckboxChecked = textCheckbox.checked;
  browserType.storage.local.set(
    { textCheckboxChecked: textCheckboxChecked },
    function () {}
  );
  if (axesBtn.classList.contains("inactive")) {
    generateSelectors(null, true);
    generateSuggestedXpath();
    updateGAEvents();
  }
});

idAttr.addEventListener("click", function () {
  trackEvent("Id attr checkbox");
  var idChecked = idAttr.checked;
  browserType.storage.local.set({ idChecked: idChecked }, function () {});
  if (axesBtn.classList.contains("inactive")) {
    generateSelectors(null, true);
    generateSuggestedXpath();
    updateGAEvents();
  }
});

classAttr.addEventListener("click", function () {
  trackEvent("class checkbox");
  var classChecked = classAttr.checked;
  browserType.storage.local.set({ classChecked: classChecked }, function () {});
  if (axesBtn.classList.contains("inactive")) {
    generateSelectors(null, true);
    generateSuggestedXpath();
    updateGAEvents();
  }
});

nameAttr.addEventListener("click", function () {
  trackEvent("name checkbox");
  var nameChecked = nameAttr.checked;
  browserType.storage.local.set({ nameChecked: nameChecked }, function () {});
  if (axesBtn.classList.contains("inactive")) {
    generateSelectors(null, true);
    generateSuggestedXpath();
    updateGAEvents();
  }
});

placeholderAttr.addEventListener("click", function () {
  trackEvent("Placeholder checkbox");
  var placeholderChecked = placeholderAttr.checked;
  browserType.storage.local.set(
    { placeholderChecked: placeholderChecked },
    function () {}
  );
  if (axesBtn.classList.contains("inactive")) {
    generateSelectors(null, true);
    generateSuggestedXpath();
    updateGAEvents();
  }
});

function generateSuggestedXpath() {
  var xpathOrCss = "xpath";
  var userSelectorValue = document.querySelector(".jsSelector").value;
  if (userSelectorValue) {
    selectElements(xpathOrCss, true);
  }
}

function updateCPSteps(allSteps) {
  deleteAllRow();
  allSteps
    ? allSteps.forEach((stps) => {
        insRow(stps);
      })
    : CPsteps.forEach((stps) => {
        insRow(stps);
      });
}

function updateColumnsColor(colr) {
  var cols = document
    .querySelector("#multiSelectorRow")
    .getElementsByTagName("th");
  var textColor = themeName == "dark" ? "#ff9800" : "black";
  for (var i = 0; i < cols.length; i++) {
    cols[i].style.backgroundColor = colr;
    cols[i].style.color = textColor;
  }
}

var multiSelectorRecord = document.querySelector(".multiSelectorRecordBtn");
var multiSelectorRecordBtn = isSidePanelView ? document.querySelector(".gen-auto") : document.querySelector(".multiSelectorRecordBtn");
var selectorsGenerator = document.querySelector(".selectorsGenerator");
var selectorsHubEleContainer = document.querySelector(
  "#selectorsHubEleContainer"
);
var multiSelectorContainer = document.querySelector("#multiSelectorContainer");
var multiSelectorRow = document.querySelector("#multiSelectorRow");
var copyAll = document.querySelector(".copyAll");
var deleteAll = document.querySelector(".deleteAll");
var insertRow = false;

var xpathWithoutCommand = "";
var cssSelectorWithoutCommand = "";
var idWithoutCommand = "";
var nameWithoutCommand = "";
var classNameWithoutCommand = "";
var linkTextWithoutCommand = "";
var partialLinkTextWithoutCommand = "";
var tagNameWithoutCommand = "";

multiSelectorRecordBtn.addEventListener("click", function () {
  trackEvent("generate automation code");
  deActivateAllButtons(multiSelectorRecord);

  //axesXpathGenerator.style.display = "none";
  //uiConfig.style.display = "none";
  deleteAllRow();
  document.querySelector(".selectorName-header").style.display = "table-cell";
  if(isSidePanelView) document.querySelector(".row-action").style.display = "none";
  selectorHeader.innerText = "Selectors";
  // tablePlaceholder.textContent = 'No selector recorded yet. \r\n Please inspect elements or click on DOM nodes to record selectors.';
  tablePlaceholder.textContent =
    "1. Inspect elements or click on DOM nodes one by one to record xpaths for many. \r\n2. Turn on the driver command to generate xpath with command. \r\n3. Set the attribute to generate xpath with required attribute. \r\n4. Click on Copy All button present in header to copy all xpaths. \r\n5. Click on export icon to download the recorded data.";
  tutorialVideoLink.setAttribute("href", "http://bit.ly/SH_Code");
  tutorialTooltip.textContent = "Watch Tutorial.";
  resetSmart.textContent = "click for smart maintenance.";
  smartFix.classList.remove("defaultsmartFix");
  openSelectorModal.style.display = "none";
  importButton.style.display = "none";
  //multiSelectorRow.style.backgroundColor = "#b8dab1";
  copyAll.style.left = "45px";
  deleteAll.style.left = "75px";
  // updateColumnsColor("#b8dab1");
  var headerColor = themeName == "dark" ? "#174440" : "#969290";
  updateColumnsColor(headerColor);

  var xpathOrCss = "xpath";
  var captureTooltip = document.querySelector(".capture.toolTip");
  var configOptions = document.querySelector(".configOptions");
  var nestedBlock = document.querySelector("#nestedBlock");
  // var footer = document.querySelector(".footer");

  if (multiSelectorRecord.className.includes("grey")) {
    multiSelectorRecord.classList.add("red");
    multiSelectorRecord.classList.remove("grey");
    //multiSelectorRecordBtn.style.backgroundImage= "url('../icons/capture_red.svg')";
    captureTooltip.textContent =
      "click to stop recording and go back to home page.";
    configOptions.style.marginTop = "5px";
    // footer.style.display = "none";
    //patronRequest.style.display = "none";
  } else {
    setElementContainerHeight();
    multiSelectorRecord.classList.add("grey");
    multiSelectorRecord.classList.remove("red");
    //multiSelectorRecordBtn.style.backgroundImage= "url('../icons/capture_"+iconColor+".svg')";
    captureTooltip.textContent =
      "Click to generate Locators Page & Multiple Selectors.";

    //configOptions.style.marginTop = "-122px";
    // footer.style.display = "block";
    // patronRequest.style.display = "block";
  }

  selectElements(xpathOrCss, false);

  if (
    multiSelectorRecord.className.includes("red") &&
    toggleElement.classList.contains("active")
  ) {
    // document.querySelector(".userFormLink").style.display="none";
    selectorsGenerator.style.display = "none";
    try {
      selectorsHubEleContainer.style.display = "none";
    } catch (err) {}
    multiSelectorContainer.style.display = "block";
    if(!isSidePanelView){
      browserType.devtools.panels.elements.onSelectionChanged.addListener(
        function () {
          if (
            multiSelectorRecord.className.includes("red") &&
            toggleElement.classList.contains("active")
          ) {
            nestedBlock.style.display = "none";
            insertRow = true;
            var onChange = false;
  
            chooseAttrsOption();
  
            var selector = "";
            var tempSelector = "";
            var selectorName = "";
            var cssSelector = "";
            var id = "";
            var name = "";
            var className = "";
            var linkText = "";
            var partialLinkText = "";
            var tagName = "";
            var cssSelector1 = "";
            generateSelectors();
            setTimeout(function () {
              //tempSelector = relXpathWithCount[0];
              if (
                addDriverCommand.className.includes("inactive") ||
                !preCommandInput.value.trim()
              ) {
                selector = xpathWithoutCommand;
                cssSelector1 = cssSelectorWithoutCommand;
              } else {
                selector = addPreCommandInSelector(xpathWithoutCommand);
                selector = selector.includes("cy.get")
                  ? selector.replace("cy.get", "cy.xpath")
                  : selector;
                cssSelector1 = addPreCommandInSelector(cssSelectorWithoutCommand);
                cssSelector1 = cssSelector1.includes("By.xpath")
                  ? cssSelector1.replace("By.xpath", "By.cssSelector")
                  : cssSelector1.includes("By(xpath")
                  ? cssSelector1.replace("By(xpath", "By(cssSelector")
                  : cssSelector1.includes("ByXPath")
                  ? cssSelector1.replace("ByXPath", "ByCssSelector")
                  : cssSelector1.includes("cy.xpath")
                  ? cssSelector1.replace("cy.xpath", "cy.get")
                  : cssSelector1.replace("cy.Xpath", "cy.get");
              }
              try {
                cssSelector = cssSelectorWithCount[0];
              } catch (err) {}
              try {
                id = idWithCount[0];
              } catch (err) {}
              try {
                name = nameWithCount[0];
              } catch (err) {}
              try {
                className = classNameWithCount[0];
              } catch (err) {}
              try {
                linkText = linkTextWithCount[0];
              } catch (err) {}
              try {
                partialLinkText = partialLinkTextWithCount[0];
              } catch (err) {}
              try {
                tagName = tagNameWithCount[0];
              } catch (err) {}
  
              selectorName = label ? label.slice(0, 30) : label;
              if (
                insertRow &&
                multiSelectorRecord.className.includes("red") &&
                toggleElement.classList.contains("active") &&
                selector !== undefined
              ) {
                var tempCPstepsWithOutCmd = [];
                tempCPstepsWithOutCmd.push({
                  selectorName,
                  selector,
                  cssSelector1,
                  idWithoutCommand,
                  nameWithoutCommand,
                  classNameWithoutCommand,
                  linkTextWithoutCommand,
                  partialLinkTextWithoutCommand,
                  tagNameWithoutCommand,
                });
                CPstepsWithOutCmd.push({
                  selectorName,
                  selector: xpathWithoutCommand,
                  cssSelector1: cssSelectorWithoutCommand,
                  idWithoutCommand,
                  nameWithoutCommand,
                  classNameWithoutCommand,
                  linkTextWithoutCommand,
                  partialLinkTextWithoutCommand,
                  tagNameWithoutCommand,
                });
                CPsteps.push({
                  selectorName,
                  selector,
                  cssSelector1,
                  id,
                  name,
                  className,
                  linkText,
                  partialLinkText,
                  tagName,
                });
                insRow(tempCPstepsWithOutCmd[0]);
              }
              cssSelectorWithoutCommand = "";
              idWithoutCommand = "";
              nameWithoutCommand = "";
              classNameWithoutCommand = "";
              linkTextWithoutCommand = "";
              partialLinkTextWithoutCommand = "";
              tagNameWithoutCommand = "";
            }, 100);
            // var selectorValue = browserType.devtools.inspectedWindow.eval('generateRelXpath($0, "'+chooseAttrs+'")', { useContentScriptContext: true }, function(result) {
  
            //     if(result!==undefined){
            //         xpath = ["xpath", result[0], onChange];
            //         connectBackgroundPage.postMessage({
            //             name: "highlight-element",
            //             tabId: browserType.devtools.inspectedWindow.tabId,
            //             xpath: xpath
            //         });
            //     }
            //     tempSelector = result[0];
            //     if(addDriverCommand.className.includes('inactive') || !preCommandInput.value.trim()){
            //         selector = result[0];
            //     }else {
            //         selector = addPreCommandInSelector(result[0]);
            //     }
            // });
  
            // var labelName = browserType.devtools.inspectedWindow.eval('createSelectorName($0)', { useContentScriptContext: true }, function(result) {
            //     var inputBox = document.querySelector(".labelName");
            //     if(result===undefined){
            //         result = "This element might be pseudo element/comment/inside iframe from different src. Currently selectorsHub doesn't support for them.";
            //     }
            //     // label = result;
            //     label = result?result.slice(0, 30):selector;
            //     if(insertRow && multiSelectorRecordBtn.className.includes("red") && toggleElement.classList.contains("active") && selector!==undefined){
            //         CPstepsWithOutCmd.push({ label, selector: tempSelector });
            //         CPsteps.push({ label, selector });
            //         insRow(label, selector);
            //     }
            // });
          }
        }
      );
    }

    updateCPSteps();
  } else {
    multiSelectorContainer.style.display = "none";
    var xpathOrCss = "xpath";
    selectorsGenerator.style.display = "block";
    selectorsHubEleContainer.style.display = "block";

    patronRequest.style.display = "flex";

    if (nestedBlockOn == "yes") {
      nestedBlock.style.display = "block";
    }
    setElementContainerHeight();
  }

  if (driverCommandBox.style.display === "none") {
    document.querySelector("#selectorHeader").textContent = "XPath";
  } else {
    document.querySelector("#selectorHeader").textContent = "Command";
  }

  var allHeaders = document.querySelectorAll(".selector-header");
  for (var i = 0; i < allHeaders.length - 1; i++) {
    allHeaders[i + 1].style.display = "table-cell";
  }
});

var smartFix = document.getElementById("smartFix");
var smartFixBtn = isSidePanelView ? document.querySelector(".verify-sel") : smartFix;
var selectorHeader = document.getElementById("selectorHeader");
var tablePlaceholder = document.querySelector(".tablePlaceholder");
var resetSmart = document.querySelector(".resetSmart");
var tutorialVideoLink = document.querySelector(".tutorialVideoLink");
var tutorialTooltip = document.querySelector(".codeTutorial.tooltip");

smartFixBtn.addEventListener("click", smartFixScreen, true);
trackEvent("verify multiple Xpath");
function smartFixScreen(e) {
  deActivateAllButtons(smartFix);

  axesXpathGenerator.style.display = "none";
  uiConfig.style.display = "none";

  deleteAllRow();
  if (!multiSelectorRecord.className.includes("grey")) {
    multiSelectorRecord.click();
  }
  var multiSelectorContainer = document.querySelector(
    "#multiSelectorContainer"
  );
  var selectorsGenerator = document.querySelector(".selectorsGenerator");
  var selectorsHubEleContainer = document.querySelector(
    "#selectorsHubEleContainer"
  );
  var labelHeader = document.querySelector(".selectorName-header");
  var nestedBlock = document.querySelector("#nestedBlock");

  selectorsGenerator.style.display = "none";
  selectorsHubEleContainer.style.display = "none";
  multiSelectorContainer.style.display = "block";
  labelHeader.style.display = "none";
  selectorHeader.innerText = "XPath";
  // tablePlaceholder.innerText = 'Paste all the xpath or upload the xpath xls file to verify all xpath in single shot';
  tablePlaceholder.innerText = smartFixPlaceholder;
  openSelectorModal.style.display = "";
  importButton.style.display = "";
  multiSelectorRow.style.backgroundColor = "#ffdca0";
  copyAll.style.left = "20px";
  deleteAll.style.left = "60px";
  var headerColor = themeName == "dark" ? "#4b4c4c" : "#ffdca0";
  updateColumnsColor(headerColor);
  tutorialVideoLink.setAttribute("href", "https://youtu.be/7-KobWo_J5I");
  tutorialTooltip.textContent = "Smart Maintenance Tutorial";

  if (smartFix.classList.contains("defaultsmartFix")) {
    selectorsGenerator.style.display = "block";
    selectorsHubEleContainer.style.display = "block";
    document.querySelector("#multiSelectorContainer").style.display = "none";
    resetSmart.textContent =
      "XPath Healing: Click to verify all the XPaths of script.";
    smartFix.classList.remove("defaultsmartFix");
    if (nestedBlockOn == "yes") {
      nestedBlock.style.display = "block";
    }

    patronRequest.style.display = "flex";
  } else {
    smartFix.classList.add("defaultsmartFix");
    // resetSmart.textContent = "click to go back to home page";
    // this.style.backgroundImage = 'url(maintenance_blue.svg)';
    appendRows(SMsteps, true);
  }

  if(isSidePanelView) document.querySelector(".row-action").style.display = "table-cell";

  var allHeaders = document.querySelectorAll(".selector-header");
  for (var i = 0; i < allHeaders.length - 1; i++) {
    allHeaders[i + 1].style.display = "none";
  }
}

// function addRow(){
//     var selector = "";
//     if(addDriverCommand.className.includes('inactive') || !preCommandInput.value.trim()){
//         selector = relXpathWithCount[0];
//     }else{
//         selector = addPreCommandInSelector(relXpathWithCount[0]);
//     }
//     var inputBox = document.querySelector(".labelName");
//     if(insertRow && multiSelectorRecordBtn.className.includes("red") && toggleElement.classList.contains("active") && selector!==undefined){
//         insRow(label, selector);
//     }
// }

function insRow(stps) {
  var x = document.querySelector("#recordedSelectorTable tbody");
  var new_row = x.rows[0].cloneNode(true);
  new_row.style.display = "";
  var len = x.rows.length;

  var inp1 = new_row.cells[1];
  inp1.id += len;
  inp1.innerHTML = stps.selectorName;

  inp1.addEventListener("input", function (e) {
    if (e.data) {
      this.classList.remove("removeOutline");
    } else {
      this.classList.add("removeOutline");
    }
  });

  for (var i = 2; i < 10; i++) {
    var inp = new_row.cells[i];
    inp.id += len;
    inp.addEventListener("input", function (e) {
      if (e.data) {
        if (addDriverCommand.classList.contains("inactive")) {
          var rowIndex = this.parentNode.rowIndex;
          CPstepsWithOutCmd[rowIndex - i].selector = this.innerText;
          CPsteps[rowIndex - i].selector = this.innerText;
          this.classList.remove("removeOutline");
        }
      } else {
        this.classList.add("removeOutline");
      }
    });

    try {
      var finalSelector =
        i == 2
          ? stps.selector
          : i == 3
          ? stps.cssSelector1
          : i == 4
          ? stps.idWithoutCommand
          : i == 5
          ? stps.nameWithoutCommand
          : i == 6
          ? stps.classNameWithoutCommand
          : i == 7
          ? stps.linkTextWithoutCommand
          : i == 8
          ? stps.partialLinkTextWithoutCommand
          : stps.tagNameWithoutCommand;
      if (
        finalSelector &&
        finalSelector.toLowerCase().includes("selectorname")
      ) {
        finalSelector = finalSelector.replace(
          /selectorname/i,
          toCamelCase(stps.selectorName)
        );
      }
      inp.textContent = finalSelector;
      inp.setAttribute("title", finalSelector);
    } catch (err) {
      inp.textContent = "";
    }
  }

  x.appendChild(new_row);
  insertRow = false;

  updateTotalRowsCount();
}

function toCamelCase(s) {
  return s
    .replace(/_/g, " ")
    .replace(/\s(.)/g, function ($1) {
      return $1.toUpperCase();
    })
    .replace(/\s/g, "")
    .replace(/^(.)/, function ($1) {
      return $1.toLowerCase();
    });
}

document
  .querySelector("#recordedSelectorTable")
  .addEventListener("click", function (ev) {
    var rowIndex = ev.target.parentNode.parentNode.rowIndex;
    if (ev.target.id.includes("delButton")) {
      deleteRow(rowIndex);
    } else if (ev.target.id === "row-copy-btn") {
      var selectorId =
        ev.target.parentNode.parentNode.querySelector(".selectorValue").id;
      copyToClipboard("#" + selectorId);
      showCopied();
    } else if (ev.target.id === "row-edit-btn") {
      let selectorValue =
        ev.target.parentNode.parentNode.querySelector(
          ".selectorValue"
        ).innerText;
      let inputBox = document.querySelector(".jsSelector");
      inputBox.focus();
      document.execCommand("selectAll");
      document.execCommand("insertText", false, selectorValue);
    } else if (ev.target.id === "row-edit-btn-SM") {
      let selectorValue =
        ev.target.parentNode.parentNode.querySelector(
          ".selectorValue"
        ).innerText;
      let val =
        selectorValue.split(" ").length > 1
          ? selectorValue.split(" ").slice(1).join("")
          : selectorValue;
      let inputBox = document.querySelector(".jsSelector");
      inputBox.focus();
      document.execCommand("selectAll");
      document.execCommand("insertText", false, val);
    } else if (ev.target.id === "row-copy-btn-SM") {
      var selectorId =
        ev.target.parentNode.parentNode.querySelector(".selectorValue").id;
      copyToClipboardSM("#" + selectorId);
      showCopied();
    }
  });

function copyToClipboardSM(elementSelectorToCopy) {
  var text = document.querySelector(elementSelectorToCopy);

  let textarea = document.createElement("textarea");
  textarea.id = "t";
  // Optional step to make less noise on the page, if any!
  textarea.style.height = 0;
  // Now append it to your page somewhere, I chose <body>
  document.body.appendChild(textarea);
  // Give our textarea a value of whatever inside the div of id=containerid
  textarea.value =
    text.innerText.split(" ").length > 1
      ? text.innerText.split(" ").slice(1).join("")
      : text.innerText;

  // Now copy whatever inside the textarea to clipboard
  let selector = document.querySelector("#t");
  selector.select();
  document.execCommand("copy");
  // Remove the textarea
  document.body.removeChild(textarea);
}

function rowAction(id) {
  var rowButton = document.querySelectorAll("#" + id);
  var totalRows = rowButton.length;

  for (var i = 0; i < totalRows; i++) {
    rowButton[i].addEventListener("click", function () {
      if (id.includes("delButton")) {
        deleteRow(this);
        return;
      } else if (id.includes("copy")) {
      } else if (id.includes("edit")) {
      }
    });
  }
}

function deleteRow(rowIndex) {
  document.getElementById("recordedSelectorTable").deleteRow(rowIndex);
  updateTotalRowsCount();

  if (smartFix.classList.contains("defaultsmartFix")) {
    SMstepsWithOutCmd.splice(rowIndex - 2, 1);
    SMsteps.splice(rowIndex - 2, 1);
    appendRows(SMsteps, true);
  }

  if (multiSelectorRecord.className.includes("red")) {
    CPstepsWithOutCmd.splice(rowIndex - 2, 1);
    CPsteps.splice(rowIndex - 2, 1);
  }
}

function deleteAllRow() {
  var allRows = document.querySelectorAll("#recordedSelectorTable tr");
  for (var i = 2; i < allRows.length; i++) {
    document.getElementById("recordedSelectorTable").deleteRow(2);
  }
  document.querySelector(".tablePlaceholder").style.display = "";
  updateTotalRowsCount();
}

var copyAllBtnXPath = document.querySelector(".copyAllBtn.xpath");
var copyAllBtnCssSelector = document.querySelector(".copyAllBtn.cssSelector");

copyAllBtnXPath.addEventListener("click", function () {
  trackEvent("copy all xpaths");
  var allRows = document.querySelectorAll(".xpath.selectorValue");

  if (copyAllBtnXPath.classList.contains("notPatron")) {
    patronModal.style.display = "block";
  }

  if (!copyAllBtnXPath.classList.contains("notPatron")) {
    copyAllRowsToClipboard(allRows);
    showCopied();
  }
});

copyAllBtnCssSelector.addEventListener("click", function () {
  trackEvent("copy all css selectors");
  var allRows = document.querySelectorAll(".cssSelector.selectorValue");

  if (copyAllBtnCssSelector.classList.contains("notPatron")) {
    patronModal.style.display = "block";
  }

  if (!copyAllBtnCssSelector.classList.contains("notPatron")) {
    copyAllRowsToClipboard(allRows);
    showCopied();
  }
});

var deleteAllBtn = document.querySelector(".deleteAllBtn");

deleteAllBtn.addEventListener("click", function () {
  trackEvent("Delete All btn");
  deleteAllRow();

  if (smartFix.classList.contains("defaultsmartFix")) {
    SMstepsWithOutCmd = [];
    SMsteps = [];
  }

  if (multiSelectorRecord.className.includes("red")) {
    CPsteps = [];
    CPstepsWithOutCmd = [];
  }
});

function showXpathValueAlertMsg(msg) {
  let showWarn = document.querySelector("#xpathValueAlertMsg");
  showWarn.innerText = msg;
  showWarn.className = "show";
  setTimeout(function () {
    showWarn.className = showWarn.className.replace("show", "");
  }, 2000);
}

var exportButton = document.querySelector(".exportButton");

exportButton.addEventListener("click", function () {
  trackEvent("Click on Export btn");
  if (document.getElementById("tableBody").rows.length > 1) {
    exportSelectors("recordedSelectorTable", "SelectorsHub");
  } else {
    showXpathValueAlertMsg("No data to save");
  }
});

function openFileUploadModal() {
  browserType.storage.local.get(["preCommandValue"], async function (result) {
    customCommand.value =
      (await result.preCommandValue) == undefined
        ? 'driver.findElement(By.xpath("xpathvalue"))'
        : result.preCommandValue;
  });
  submitBtn.textContent = "Next";
  document.getElementById("enterNewTitle").style.display = "none";
  document.getElementById("addNewTitle").textContent = "Upload XPath file";
  document.getElementById("imgupload").style.display = "none";
  // document.getElementById('addNewTitleLabel').textContent = "Please enter steps values.";

  var modal = document.getElementById("addNewModal");
  modal.style.display = "block";
  document.getElementById("enterNewTitle").focus();

  // to clear input value
  document.getElementById("enterNewTitle").value = "";

  checkXpathInputCommand();
}

function checkXpathInputCommand() {
  setTimeout(() => {
    if (!customCommand.value.toLowerCase().includes("xpathvalue")) {
      customCommand.classList.add("wrongXpath");
      customCommand.style.backgroundColor = "#FF6347";
    } else if (customCommand.value.toLowerCase().includes("xpathvalue")) {
      customCommand.classList.remove("wrongXpath");
      customCommand.style.backgroundColor = "#FFF";
    }
  }, 100);
}

var fileToRead = document.getElementById("imgupload");

fileToRead.addEventListener(
  "change",
  function (evt) {
    var selectedFile = evt.target.files[0];
    var reader = new FileReader();
    var command = document.getElementById("customCommand").value.trim();
    var toggle = document.getElementById("inputToggle");
    reader.onload = function (event) {
      var data = event.target.result;
      var workbook = XLSX.read(data, {
        type: "binary",
      });
      workbook.SheetNames.forEach(function (sheetName) {
        var XL_row_object = XLSX.utils.sheet_to_row_object_array(
          workbook.Sheets[sheetName]
        );
        document.querySelector(".selectorName-header").style.display = "none";
        if (toggle.classList.contains("active")) {
          let filterd = [...XL_row_object];
          SMsteps = filterd.map((stp) => {
            let data = stp["Label"];
            let xpath = stp["XPath"] || stp["Command"];
            let generatedXpath = extractXpath(xpath, command);
            return {
              Step: data,
              XPath: generatedXpath,
            };
          });
          SMstepsWithOutCmd = [...SMsteps];
          appendRows(SMsteps, true);
        } else {
          SMsteps = [...XL_row_object];
          SMstepsWithOutCmd = SMsteps.map((stp) => {
            let data = stp["Label"];
            let xpath = stp["XPath"] || stp["Command"];
            return {
              Step: data,
              XPath: xpath,
            };
          });
          appendRows(SMstepsWithOutCmd, true);
        }
        // var json_object = JSON.stringify(XL_row_object);

        // document.getElementById("jsonObject").innerHTML = json_object;
      });
    };

    reader.onerror = function (event) {
      console.error("File could not be read! Code " + event.target.error.code);
    };

    reader.readAsBinaryString(selectedFile);
    fileToRead.value = "";
  },
  false
);

function nodesColor(no) {
  switch (no) {
    case 0:
      return "nodesCountZero";
    case 1:
      return "nodesCountOne";
    default:
      return "nodesCountDef";
  }
}

function appendRows(arr, bool) {
  deleteAllRow();
  try {
    arr.forEach(async (row, ind) => {
      var rowCount = document.getElementById("tableBody").rows.length;
      var commandActive = document.getElementById('inputToggle').classList.contains('active');
      tableBody.innerHTML += `
                <tr>
                    <td id='s-no'></td>
                    <td style="display:${
                      bool ? "none" : ""
                    }" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" id="labelData${rowCount}" class="label editableContent">
                        ${row[Object.keys(row)[0]] || ""}
                    </td>
                    <td autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" contenteditable="true" id="selectorData${rowCount}" class="xpath selectorValue editableContent">
                        <span class='nodesCount' id="occurrence${rowCount}">0</span>
                        ${row["XPath"] || ""}
                    </td>
                    <td id="actionBtn">
                        <button id="row-copy-btn-SM" title="click to copy relative XPath"></button>
                        <button id="row-edit-btn-SM" title="click to edit relative XPath"></button>
                        <button id="delButton"></button>
                    </td>
                </tr>
            `;

      let message = {
        xpath: SMstepsWithOutCmd[ind]["XPath"] || "",
        id: `occurrence${rowCount}`,
      };
      message = JSON.stringify(message);

      if(isSidePanelView){
        getActiveTabId().then(tabId => {
            postSafeMessage({
                name: "calculate-elements",
                data: message,
                commandActive,
                tabId,
            });
        })
      }else{
        await browserType.devtools.inspectedWindow.eval(
          "calculateElements(`" + message + "`)",
          { useContentScriptContext: true },
          function (result) {
            appendElementsCount(result);
          }
        );
      }
      // await connectBackgroundPage.postMessage({
      //     name: "calcElements",
      //     tabId: browserType.devtools.inspectedWindow.tabId,

      //     data: { xpath: SMstepsWithOutCmd[ind]['XPath'] || '', id: `occurrence${rowCount}` }
      // });
      addChangeHandler(`occurrence${rowCount}`);
    });

    updateTotalRowsCount();
  } catch (err) {
    console.warn(err, "Error");
  }
}

function addChangeHandler(id) {
  let ele = document.getElementById(id);
  ele.parentNode.addEventListener("input", function (e) {
    if (e.data) {
      if (addDriverCommand.classList.contains("inactive")) {
        var rowIndex = this.parentNode.rowIndex;
        var txt = this.innerText.slice(this.innerText.indexOf(" ") + 1);
        SMstepsWithOutCmd[rowIndex - 2].XPath = txt;
        SMsteps[rowIndex - 2].XPath = txt;
        ele.parentElement.classList.remove("removeOutline");
      }
    } else {
      ele.parentElement.classList.add("removeOutline");
    }
  });
}

// var headTr = document.getElementById('multiSelectorRow');
function updateNodesCount(bool, nodeVals, labelVal) {
  try {
    var nodes = document.querySelectorAll(".nodesCount");
    if (bool) {
      for (let i = 0; i < nodes.length; i++) {
        nodes[i].innerHTML = "";
      }
    } else {
      for (let i = 0; i < nodes.length; i++) {
        nodes[i].innerHTML = nodeVals[i];
      }
    }
  } catch (err) {
    console.warn(err, "ERR");
  }
}

function downloadFile(
  labelVals,
  nodeVals,
  xpathVals,
  cssSelectorVals,
  idVals,
  nameVals,
  classVals,
  linkTextVals,
  partialLinkTextVals,
  tagNameVals
) {
  var header = [];
  var data = [];
  var isWindowsOS = window.navigator.userAgent.includes("Windows");

  xpathVals.forEach((xpath, ind) => {
    if (smartFix.classList.contains("defaultsmartFix")) {
      header = [["XPath", "Occurrence"]];
      data.push([xpath, nodeVals[ind]]);
    } else {
      if (preCommandInput.style.display === "none") {
        header = [
          [
            "Label",
            "XPath",
            "cssSelector",
            "id",
            "name",
            "class",
            "linkText",
            "partialLinkText",
            "tagName",
          ],
        ];
      } else {
        header = [
          [
            "Label",
            "Command",
            "cssSelector",
            "id",
            "name",
            "class",
            "linkText",
            "partialLinkText",
            "tagName",
          ],
        ];
      }
      data.push([
        labelVals[ind],
        xpath,
        cssSelectorVals[ind],
        idVals[ind],
        nameVals[ind],
        classVals[ind],
        linkTextVals[ind],
        partialLinkTextVals[ind],
        tagNameVals[ind],
      ]);
    }
  });
  var testCase = header.concat(data);
  var csv = "";

  testCase.forEach(function (row) {
    if (smartFix.classList.contains("defaultsmartFix")) {
      row = [`${row[0]}`.trim(), `${row[1]}`];
    } else {
      row = [
        `${row[0]}`.trim(),
        `${row[1]}`,
        `${row[2]}`,
        `${row[3]}`,
        `${row[4]}`,
        `${row[5]}`,
        `${row[6]}`,
        `${row[7]}`,
        `${row[8]}`,
      ];
    }

    csv += isWindowsOS ? row.join(",") : row.join("\t");
    csv += "\n";
  });

  var a = window.document.createElement("a");
  a.href = window.URL.createObjectURL(
    new Blob([csv], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;",
    })
  );

  // connectBackgroundPage.postMessage({
  //   name: "url",
  //   tabId: browserType.devtools.inspectedWindow.tabId,
  // });

  var timeStamp = getFormattedTime();

  setTimeout(function () {
    if (isWindowsOS) {
      a.download = pageDomainName + `-` + timeStamp + `.csv`;
    } else {
      a.download = pageDomainName + `-` + timeStamp + `.xls`;
    }
    // Append anchor to body.
    document.body.appendChild(a);
    a.click();

    // Remove anchor from body
    document.body.removeChild(a);

    a = null;
  }, 100);
}

var exportSelectors = function (table, name) {
  let XPaths = document.querySelectorAll(".xpath.selectorValue");

  let nodesCounts = document.querySelectorAll(".nodesCount");
  let labels = document.querySelectorAll(".label");
  let cssSelectors = document.querySelectorAll(".cssSelector.selectorValue");
  let ids = document.querySelectorAll(".id.selectorValue");
  let names = document.querySelectorAll(".name.selectorValue");
  let classes = document.querySelectorAll(".class.selectorValue");
  let linkTexts = document.querySelectorAll(".linkText.selectorValue");
  let partialLinkTexts = document.querySelectorAll(
    ".partialLinkText.selectorValue"
  );
  let tagNames = document.querySelectorAll(".tagName.selectorValue");

  let labelVal = [];
  let nodeVals = [];
  let xpathVals = [];
  let cssSelectorVals = [];
  let idVals = [];
  let nameVals = [];
  let classVals = [];
  let linkTextVals = [];
  let partialLinkTextVals = [];
  let tagNameVals = [];

  for (let i = 1; i < labels.length; i++) {
    labelVal.push(labels[i].textContent.trim());
  }
  for (let i = 0; i < nodesCounts.length; i++) {
    nodeVals.push(nodesCounts[i].textContent);
  }

  updateNodesCount(true, nodeVals, labelVal);

  for (let i = 1; i < XPaths.length; i++) {
    xpathVals.push(XPaths[i].textContent);
    if (!smartFix.classList.contains("defaultsmartFix")) {
      cssSelectorVals.push(cssSelectors[i].textContent);
      idVals.push(ids[i].textContent);
      nameVals.push(names[i].textContent);
      classVals.push(classes[i].textContent);
      linkTextVals.push(linkTexts[i].textContent);
      partialLinkTextVals.push(partialLinkTexts[i].textContent);
      tagNameVals.push(tagNames[i].textContent);
    }
  }

  downloadFile(
    labelVal,
    nodeVals,
    xpathVals,
    cssSelectorVals,
    idVals,
    nameVals,
    classVals,
    linkTextVals,
    partialLinkTextVals,
    tagNameVals
  );

  updateNodesCount(false, nodeVals, labelVal);
};

function updateSMSteps() {
  SMsteps = SMstepsWithOutCmd.map((stp) => {
    return {
      Step: stp.Step,
      XPath: preCommandInput.value.trim().replace(/xpathvalue/i, stp.XPath),
    };
  });

  appendRows(SMsteps, true);
}

function updateselectorsHubSteps() {
  var cmdValue = preCommandInput.value;
  var preCommandForXpath = cmdValue.includes("cy.get")
    ? cmdValue.replace("cy.get", "cy.xpath")
    : cmdValue;
  var preCommandForCss = cmdValue.includes("By.xpath")
    ? cmdValue.replace("By.xpath", "By.cssSelector")
    : cmdValue.includes("By(xpath")
    ? cmdValue.replace("By(xpath", "By(cssSelector")
    : cmdValue.includes("ByXPath")
    ? cmdValue.replace("ByXPath", "ByCssSelector")
    : cmdValue.includes("cy.xpath")
    ? cmdValue.replace("cy.xpath", "cy.get")
    : cmdValue.replace("cy.Xpath", "cy.get");
  CPsteps = CPstepsWithOutCmd.map((stp) => {
    return {
      selectorName: stp.selectorName,
      selector: preCommandForXpath
        ? preCommandForXpath.trim().replace(/xpathvalue/i, stp.selector)
        : stp.selector,
      cssSelector1: preCommandForCss
        ? preCommandForCss.trim().replace(/xpathvalue/i, stp.cssSelector1)
        : stp.cssSelector1,
      idWithoutCommand: stp.idWithoutCommand,
      nameWithoutCommand: stp.nameWithoutCommand,
      classNameWithoutCommand: stp.classNameWithoutCommand,
      linkTextWithoutCommand: stp.linkTextWithoutCommand,
      PartialLinkTextWithoutCommand: stp.PartialLinkTextWithoutCommand,
      tagNameWithoutCommand: stp.tagNameWithoutCommand,
    };
  });

  updateCPSteps(CPsteps);
}

var driverCommandBox = document.querySelector(".driver-command-box");
var addDriverCommand = document.querySelector(".addDriverCommand");
var addDriverCommandBtn = isSidePanelView ? document.querySelector(".drive-cmd") : document.querySelector(".addDriverCommand")
var totalCount = document.querySelector(".total-match-count");

addDriverCommandBtn.addEventListener("click", async function () {
  trackEvent("set driver command");

  var cmdValue = preCommandInput.value;
  var preCommandForXpath = cmdValue.includes("cy.get")
    ? cmdValue.replace("cy.get", "cy.xpath")
    : cmdValue;
  var preCommandForCss = cmdValue.includes("By.xpath")
    ? cmdValue.replace("By.xpath", "By.cssSelector")
    : cmdValue.includes("By(xpath")
    ? cmdValue.replace("By(xpath", "By(cssSelector")
    : cmdValue.includes("ByXPath")
    ? cmdValue.replace("ByXPath", "ByCssSelector")
    : cmdValue.includes("cy.xpath")
    ? cmdValue.replace("cy.xpath", "cy.get")
    : cmdValue.replace("cy.Xpath", "cy.get");

  if (driverCommandBox.style.display === "none") {
    browserType.storage.local.set(
      { driverCommandBox: "active" },
      function () {}
    );

    document.querySelector("#selectorHeader").textContent = "Command";

    addDriverCommand.classList.remove("inactive");
    addDriverCommand.classList.add("active");
    // if (preCommandInput.value.toLowerCase().includes("xpathvalue")) {
    // }
    // addDriverCommand.style.backgroundImage =
    //   "url(../icons/addDriverCommand_blue.svg)";
    driverCommandBox.style.display = "block";

    if (preCommandInput.value.toLowerCase().includes("xpathvalue")) {
      if (smartFix.classList.contains("defaultsmartFix")) {
        let inputCmd = preCommandInput.value.split('"')[0];
        if (
          SMsteps[0] &&
          !SMsteps[0].XPath.includes(inputCmd) &&
          !SMsteps[0].XPath.toLowerCase().includes(inputCmd)
        ) {
          SMsteps = SMsteps.map((stp) => {
            return {
              Step: stp.Step,
              XPath: preCommandInput.value
                .trim()
                .replace(/xpathvalue/i, stp.XPath),
            };
          });

          appendRows(SMsteps, true);
        }
      } else if (multiSelectorRecord.classList.contains("red")) {
        let inputCmd = preCommandInput.value.split('"')[0];
        if (
          CPstepsWithOutCmd[0] &&
          !CPstepsWithOutCmd[0].selector.includes(inputCmd)
        ) {
          CPsteps = CPstepsWithOutCmd.map((stp) => {
            return {
              selectorName: stp.selectorName,
              selector: preCommandForXpath
                .trim()
                .replace(/xpathvalue/i, stp.selector),
              // cssSelectorWithoutCommand: stp.cssSelectorWithoutCommand,
              cssSelector1: preCommandForCss
                .trim()
                .replace(/xpathvalue/i, stp.cssSelector1),
              idWithoutCommand: stp.idWithoutCommand,
              nameWithoutCommand: stp.nameWithoutCommand,
              classNameWithoutCommand: stp.classNameWithoutCommand,
              linkTextWithoutCommand: stp.linkTextWithoutCommand,
              PartialLinkTextWithoutCommand: stp.PartialLinkTextWithoutCommand,
              tagNameWithoutCommand: stp.tagNameWithoutCommand,
            };
          });

          updateCPSteps(CPsteps);
        }
      }

      if (
        selectorsGenerator.offsetParent &&
        preCommandInput.value.toLowerCase().includes("xpathvalue")
      ) {
        removeAttrCommands(true);
      }
    }
    if (
      preCommandInput.value &&
      !preCommandInput.value.toLowerCase().includes("xpathvalue")
    ) {
      preCommandInput.classList.add("wrongXpath");
      // document.querySelector('.commandTip').style.visibility = "visible";
    }
  } else {
    browserType.storage.local.set(
      { driverCommandBox: "inactive" },
      function () {}
    );
    document.querySelector("#selectorHeader").textContent = "XPath";
    addDriverCommand.classList.remove("active");
    addDriverCommand.classList.add("inactive");
    addDriverCommand.style.backgroundImage =
      "url('../icons/addDriverCommand_" + iconColor + ".svg')";
    driverCommandBox.style.display = "none";

    if (preCommandInput.value.toLowerCase().includes("xpathvalue")) {
      if (smartFix.classList.contains("defaultsmartFix")) {
        let allXpaths = SMsteps.map((stp) => stp.XPath);
        let extractCommands = await extractAllCommands(
          preCommandInput.value.trim(),
          allXpaths.join("")
        );
        SMsteps = SMsteps.map((stp, ind) => {
          return {
            selectorName: stp.selectorName,
            XPath: extractCommands[ind][1],
          };
        });

        appendRows(SMsteps, true);
      } else if (multiSelectorRecord.classList.contains("red")) {
        // let allXpaths = CPsteps.map(stp => stp.selector);
        // let extractCommands = await extractAllCommands(preCommandInput.value.trim(), allXpaths.join(''));
        CPsteps = CPstepsWithOutCmd.map((stp, ind) => {
          return {
            selectorName: stp.selectorName,
            selector: stp.selector,
            cssSelector1: stp.cssSelector1,
            idWithoutCommand: stp.idWithoutCommand,
            nameWithoutCommand: stp.nameWithoutCommand,
            classNameWithoutCommand: stp.classNameWithoutCommand,
            linkTextWithoutCommand: stp.linkTextWithoutCommand,
            PartialLinkTextWithoutCommand: stp.PartialLinkTextWithoutCommand,
            tagNameWithoutCommand: stp.tagNameWithoutCommand,
          };
        });
        updateCPSteps(CPsteps);
      }
      if (selectorsGenerator.offsetParent) {
        removeAttrCommands(false);
      }
    }

    // document.querySelector('.commandTip').style.visibility = "hidden";
  }

  setImageAdsContainerHeight();
});

browserType.storage.local.get(["driverCommandBox"], function (result) {
  if (result.driverCommandBox == "active") {
    driverCommandBox.style.display = "block";
    addDriverCommand.classList.remove("inactive");
    addDriverCommand.classList.add("active");
  }
});

async function removeAttrCommands(bool) {
  let elements = document.querySelectorAll(".valueSelector");
  let relElement = document.querySelector(".rel");

  if (bool) {
    for (let i = 0; i < elements.length; i++) {
      if (
        elements[i].offsetParent &&
        !elements[i].classList.contains("rel") &&
        !elements[i].classList.contains("jsPath") &&
        !elements[i].classList.contains("testRigorPath")
      ) {
        let eleCommand = elements[i].dataset.command;
        let inputValue = preCommandInput.value.trim();
        inputValue = inputValue.includes("cy.xpath")
          ? inputValue.replace("cy.xpath", "cy.get")
          : inputValue;
        if (
          inputValue.toLowerCase().indexOf("xpath") !==
          inputValue.toLowerCase().lastIndexOf("xpath")
        ) {
          // if(preCommandInput.value.toLowerCase().indexOf('xpath') !== preCommandInput.value.toLowerCase().lastIndexOf('xpath')){
          inputValue = inputValue.trim().replace("xpath", eleCommand);
        }
        if (
          !elements[i].textContent.includes(
            inputValue
              .replace(/”|“/g, '"')
              .replace("xpath", elements[i].dataset.command)
              .replace(/”|“/g, '"')
              .split('"')[0]
          )
        ) {
          elements[i].textContent = inputValue.replace(
            /xpathvalue/i,
            elements[i].textContent
          );
          if (eleCommand.includes("xpath") || eleCommand.includes("index")) {
            //here index used for indexxpath
            elements[i].textContent = elements[i].textContent.replace(
              "cy.get",
              "cy.xpath"
            );
            elements[i].textContent = elements[i].textContent.replace(
              "indexXpath",
              "xpath"
            );
          }
        }
      }
    }
    if (relElement.offsetParent) {
      let startInd = preCommandInput.value
        .toLowerCase()
        .trim()
        .indexOf("xpathvalue");
      let diff = preCommandInput.value.trim().length - startInd;
      let first = preCommandInput.value.trim().slice(0, startInd);
      let second = preCommandInput.value.trim().slice(-diff + 10);
      first = first.includes("cy.get")
        ? first.replace("cy.get", "cy.xpath")
        : first;

      document.querySelector(".p1-label").textContent = first;
      document.querySelector(".p2-label").textContent = second;
    }
  } else {
    for (let i = 0; i < elements.length; i++) {
      if (
        elements[i].offsetParent &&
        !elements[i].classList.contains("rel") &&
        !elements[i].classList.contains("jsPath")
      ) {
        let val = elements[i].textContent;
        val = val.includes("cy.xpath")
          ? val.replace("cy.xpath", "cy.get")
          : val;
        let eleCommand = elements[i].dataset.command;
        eleCommand = eleCommand.includes("cy.xpath")
          ? eleCommand.replace("cy.xpath", "cy.get")
          : eleCommand;
        eleCommand = eleCommand.includes("indexXpath")
          ? eleCommand.replace("indexXpath", "xpath")
          : eleCommand;
        let inputValue = preCommandInput.value.trim();
        inputValue = inputValue.includes("cy.xpath")
          ? inputValue.replace("cy.xpath", "cy.get")
          : inputValue;
        if (
          inputValue.toLowerCase().indexOf("xpath") !==
          inputValue.toLowerCase().lastIndexOf("xpath")
        ) {
          inputValue = inputValue.trim().replace(/xpath/i, eleCommand);
        }
        let command = await extractAllCommands(
          inputValue.replace(/”|“/g, '"'),
          val.replace(/”|“/g, '"')
        );
        if (command[0]) {
          elements[i].textContent = command[0][1];
        }
      }
    }

    if (relElement.offsetParent) {
      document.querySelector(".p1-label").textContent = "";
      document.querySelector(".p2-label").textContent = "";
    }
  }
}

var settingBtn = document.querySelector(".setting_btn");
var attributeFilter = document.querySelector(".attributeFilter");

// settingBtn.addEventListener("click", function() {
//   attributeFilter.classList.toggle("show");
//   if(attributeFilter.classList.contains("show")){
//     settingBtn.style.backgroundImage= "url('setting_blue.svg')";
//     attributeFilter.style.display="block";
//   }else{
//     attributeFilter.style.display="none";
//     settingBtn.style.backgroundImage= "url('setting_"+iconColor+".svg')";
//   }
//   setElementContainerHeight();
//   var h = document.querySelector('body').clientHeight;

//   if(attributeFilter.style.display.includes("block")){
//     document.querySelector('#multiSelectorContainer').style.height = "calc(100% - 91px)";
//   }else{
//     document.querySelector('#multiSelectorContainer').style.height = "calc(100% - 66px)";
//   }

// });

function updateTotalRowsCount() {
  var selectorsCount = document.querySelector(".selectorsCount");
  var totalRows =
    document.querySelectorAll("#recordedSelectorTable tr").length - 2;

  if (totalRows > 0) {
    document.querySelector(".tablePlaceholder").style.display = "none";
  } else {
    document.querySelector(".tablePlaceholder").style.display = "";
  }
  selectorsCount.innerText = "(" + totalRows + ")";
}
window.addEventListener(
  "click",
  function (e) {
    setElementContainerHeight();
    setWidthOfSelectorHeader();
    var allCells = document.querySelectorAll("td");
    for (var i = 0; i < allCells.length; i++) {
      allCells[i].scrollLeft = 0;
    }

    if (
      !event.target.className.includes("edit") &&
      !event.target.className.includes("savedSelectorRow") &&
      savedSelectors.style.display == "block"
    ) {
      savedSelectors.style.display = "none";
    }

    if (event.target == patronModal) {
      patronModal.style.display = "none";
    }

    var savedCommand = document.querySelector(".savedCommand");
    var cmdBox = document.querySelector(".driver-command");
    if (savedCommand.style.display == "block" && event.target != cmdBox) {
      savedCommand.style.display = "none";
    }
  },
  true
);

// window.onclick = function(event) {

//     setElementContainerHeight();
//     setWidthOfSelectorHeader();
//     var allCells = document.querySelectorAll("td");
//     for(var i=0; i<allCells.length; i++){
//         allCells[i].scrollLeft=0;
//     }

//     if(!event.target.className.includes("edit") && !event.target.className.includes("savedSelectorRow") && savedSelectors.style.display=="block"){
//         savedSelectors.style.display = "none";
//     }

//     if (event.target == patronModal) {
//         patronModal.style.display = "none";
//     }

//     var savedCommand = document.querySelector(".savedCommand");
//     var cmdBox = document.querySelector(".driver-command");
//     if(savedCommand.style.display == "block" && event.target != cmdBox){
//         savedCommand.style.display = "none";
//     }
// }

// setTimeout(function(){ document.querySelector(".userFormLink").style.display="none";
// }, 20000);

// setTimeout(function(){ document.querySelector(".version").style.display="inline";
// }, 20000);

let upgradeContainer = document.querySelector("#upgrade-popup");
let upgradeConfirmBtn = document.querySelector("#upgrade-confirm");
let upgradeCancelBtn = document.querySelector("#upgrade-cancel");
let uiBlockAdsSettings;

upgradeConfirmBtn.addEventListener("click", () => {
  upgradeContainer.classList.add("hideElement");
});
upgradeCancelBtn.addEventListener("click", () => {
  upgradeContainer.classList.add("hideElement");
});

fetch(`${API_URL}settings/ui_block_ads`)
  .then((res) => res.json())
  .then((data) => {
    uiBlockAdsSettings = data.filter((s) => s.extension === "sh")[0];
  });

function showCopied(event) {
  if (uiBlockAdsSettings.active === 1) {
    browserType.storage.local.get(["save_count"], (data) => {
      if (data.save_count === undefined || data.save_count === null)
        return browserType.storage.local.set({ save_count: 0 });
      // if user click save 5 times then show popup
      if (data.save_count >= uiBlockAdsSettings.nb_actions - 1) {
        // display popup
        upgradeContainer.classList.remove("hideElement");
        upgradeContainer.querySelector(".upgrade__popup__message").innerText =
          uiBlockAdsSettings.message;
        upgradeContainer.querySelector("#upgrade-confirm").href =
          uiBlockAdsSettings.link;
        // reset counter
        browserType.storage.local.set({ save_count: 0 });
      } else {
        browserType.storage.local.set({ save_count: data.save_count + 1 });
      }
    });
  } else {
    browserType.storage.local.set({ save_count: 0 });
  }

  var top = "";
  var elementClass = event.target.className;
  var copyToolTip = document.querySelector(".copyToolTip");
  copyToolTip.textContent = elementClass.includes("editorContent")
    ? "Selector value is copied."
    : elementClass.includes("iframe")
    ? "iframe XPath is copied"
    : elementClass.includes("suggested")
    ? "SH suggested selector is copied"
    : elementClass.includes("rel")
    ? "Rel XPath is copied"
    : elementClass.includes("id")
    ? "id is copied"
    : elementClass.includes("name")
    ? "name is copied"
    : elementClass.includes("tagName")
    ? "tagName is copied"
    : elementClass.includes("class")
    ? "className is copied"
    : elementClass.includes("abs")
    ? "Abs XPath is copied"
    : elementClass.includes("css")
    ? "copied cssSelector"
    : elementClass.includes("linkText")
    ? "copied linkText"
    : elementClass.includes("partialLinkText")
    ? "copied partialLinkText"
    : elementClass.includes("plus-btn")
    ? "Value is saved here."
    : elementClass.includes("domContentCopyBtn")
    ? "Value copied in the clipboard."
    : "copied selector's value";

    let sg = document.querySelector(".shub-generator");
  if (event.target.id.includes("row-copy-btn")) {
    copyToolTip.style.right = "62px";
    top = event.target.parentNode.offsetTop + 87;
  } else if (event.target.className.includes("copyAllBtn")) {
    copyToolTip.style.left = "216px";
    //top =  "130px";
    top = "113px";
    copyToolTip.style.marginLeft = "82px";
  } else if (event.target.className.includes("nestedCodeCopyBtn")) {
    copyToolTip.textContent = "Code is copied.";
    top = "205px";
  } else {
    top = event.target.offsetTop + 1;
    top = top;
    copyToolTip.style.left = "24px";
  }

  copyToolTip.classList.add("show");
  copyToolTip.style.top = event.clientY;
  copyToolTip.style.left = event.clientX;
  setTimeout(function () {
    copyToolTip.classList.remove("show");
    copyToolTip.style.left = "";
    copyToolTip.style.right = "";
  }, 800);
}

// record.addEventListener("click", function () {
//   if (openedRecorder) {
//     if(isSidePanelView){
//       getActiveTabId().then(tabId => {
//           postSafeMessage({
//               name: 'active',
//               tabId,
//               index: null
//           });    
//       })
//     }else{
//       postSafeMessage({
//         name: "active",
//         tabId: browserType.devtools.inspectedWindow.tabId,
//         index: null,
//       });
//     }

//     return;
//   }
//   this.classList.add("redBlink");
//   if(isSidePanelView){
//     getActiveTabId().then(tabId => {
//         postSafeMessage({
//             name: 'openStudio',
//             tabId,
//             index: null
//         });
//       })
//     }else{
//       postSafeMessage({
//         name: "openStudio",
//         tabId: browserType.devtools.inspectedWindow.tabId,
//         index: null,
//       });
//     }
// });



var resetConfig = document.querySelector(".reset-btn");
var resetConfigBtn = isSidePanelView ? document.querySelector(".reset-btn-c") : resetConfig;

resetConfigBtn.addEventListener("click", function () {
  trackEvent("reset settings");
  deActivateAllButtons();
  var selectorsGenerator = document.querySelector(".selectorsGenerator");
  var listElements = document.querySelector("#selectorsHubEleContainer");
  selectorsGenerator.style.display = "block";
  listElements.style.display = "block";

  idAttr.checked = true;
  classAttr.checked = true;
  nameAttr.checked = true;
  placeholderAttr.checked = true;
  userAttrName.value = "";
  textCheckbox.checked = true;
  preCommandInput.value = "";
  //onUpdateCommand();

  attributeFilter.style.display = "none";

  attrFilterIcon.classList.add("inactive");
  attrFilterIcon.classList.remove("active");

  quotes.classList.remove("active");
  quotes.classList.add("inactive");

  autosuggestToggleElement.classList.remove("inactive");
  autosuggestToggleElement.classList.add("active");

  addDriverCommand.classList.remove("active");
  addDriverCommand.classList.add("inactive");

  driverCommandBox.style.display = "none";

  expandBtn.classList.remove("active");
  expandBtn.classList.add("inactive");
  browserType.storage.local.set({ expandBtn: "inactive" }, function () {});
  var selectorBlock = document.querySelector(".selectorsGenerator");
  selectorBlock.style.maxHeight = "125px";
  expandBtnToolTip.textContent =
    "Click to expand selectors block to see all generated selectors.";

  browserType.storage.local.set({ classChecked: true }, function () {});
  browserType.storage.local.set({ nameChecked: true }, function () {});
  browserType.storage.local.set({ placeholderChecked: true }, function () {});
  browserType.storage.local.set({ idChecked: true }, function () {});
  browserType.storage.local.set({ textCheckboxChecked: true }, function () {});
  browserType.storage.local.set(
    { userAttrName: userAttrName.value.trim() },
    function () {}
  );

  browserType.storage.local.set(
    { preCommandValue: preCommandInput.value },
    function () {}
  );
  browserType.storage.local.set({ toggleElement: "active" }, function () {});
  browserType.storage.local.set({ attributeFilter: "inactive" }, function () {});

  browserType.storage.local.set({ quotesBtn: "inactive" }, function () {});
  browserType.storage.local.set(
    { autosuggestToggleElement: "active" },
    function () {}
  );
  browserType.storage.local.set({ toggleElement: "active" }, function () {});
  browserType.storage.local.set({ driverCommandBox: "inactive" });

  //reset ui confix to default
  cssSelectorChoice.checked = true;
  relXpathChoice.checked = true;
  suggestedXpathChoice.checked = true;
  indexXpathChoice.checked = true;
  idChoice.checked = true;
  nameChoice.checked = true;
  classNameChoice.checked = true;
  jQueryChoice.checked = true;
  jsPathChoice.checked = true;
  linkTextChoice.checked = true;
  partialLinkTextChoice.checked = true;
  absXpathChoice.checked = true;
  tagNameChoice.checked = true;
  autoSuggestToggleChoice.checked = true;
  autoGenerateToggleChoice.checked = true;
  caseInsensitiveBtnChoice.checked = true;
  systemInfoChoice.checked = true;

  browserType.storage.local.set({ cssSelectorChoice: "yes" }, function () {});
  browserType.storage.local.set({ relXpathChoice: "yes" }, function () {});
  browserType.storage.local.set(
    { suggestedXpathChoice: "yes" },
    function () {}
  );
  browserType.storage.local.set({ indexXpathChoice: "yes" }, function () {});
  browserType.storage.local.set({ idChoice: "yes" }, function () {});
  browserType.storage.local.set({ nameChoice: "yes" }, function () {});
  browserType.storage.local.set({ classNameChoice: "yes" }, function () {});
  browserType.storage.local.set({ jQueryChoice: "yes" }, function () {});
  browserType.storage.local.set({ jsPathChoice: "yes" }, function () {});
  browserType.storage.local.set({ linkTextChoice: "yes" }, function () {});
  browserType.storage.local.set(
    { partialLinkTextChoice: "yes" },
    function () {}
  );
  browserType.storage.local.set({ absXpathChoice: "yes" }, function () {});
  browserType.storage.local.set({ tagNameChoice: "yes" }, function () {});
  browserType.storage.local.set(
    { autoSuggestToggleChoice: "yes" },
    function () {}
  );
  browserType.storage.local.set(
    { autoGenerateToggleChoice: "yes" },
    function () {}
  );
  browserType.storage.local.set(
    { caseInsensitiveBtnChoice: "yes" },
    function () {}
  );
  browserType.storage.local.set({ systemInfoChoice: "no" }, function () {});

  var autoSuggestToggleContainer = document.querySelector("#autosuggestToggle");
  autoSuggestToggleContainer.style.visibility = "visible";

  var autoGenerateToggleContainer = document.querySelector(".toggle-btn");
  autoGenerateToggleContainer.style.visibility = "visible";

  var ignoreCaseBtnContainer = document.querySelector(".ignoreCaseBtn");
  ignoreCaseBtnContainer.style.visibility = "visible";

  var allSelectorsRows = document.querySelectorAll(".selectorsRow");
  for (var i = 2; i < allSelectorsRows.length; i++) {
    allSelectorsRows[i].style.display = "block";
  }

  debugTimeBox.value = 5;
  browserType.storage.local.set({ debugTime: 5 }, function () {});

  patronRequest.style.display = "flex";
  systemInfoContainer.style.display = "block";
  patronRequest.style.bottom = "11px";
});

function setWidthOfSelectorHeader() {
  setTimeout(function () {
    var temp = 1;
    var allMatchingNodeNumber = document.querySelectorAll(".noOfMatch");
    for (var i = 0; i < allMatchingNodeNumber.length; i++) {
      temp =
        allMatchingNodeNumber[i].textContent.length > temp
          ? allMatchingNodeNumber[i].textContent.length
          : temp;
    }
    for (var i = 0; i < allMatchingNodeNumber.length; i++) {
      document.querySelectorAll(".noOfMatch")[i].style.width =
        temp === 3
          ? "35px"
          : temp === 4
          ? "41px"
          : temp === 5
          ? "47px"
          : "26px";
      document.querySelectorAll(".typeOfLocator")[i].style.width =
        temp === 2
          ? "77px"
          : temp === 3
          ? "76px"
          : temp === 4
          ? "69px"
          : temp === 5
          ? "62px"
          : "90px";
    }
  }, 150);
}

var openSelectorModal = document.querySelector(".openSelectorModal");
var importButton = document.querySelector(".importButton");
var closeIcon = document.getElementById("modalClose");
var cancelBtn = document.getElementById("modal-cancel");
var submitBtn = document.getElementById("btn-submit");
var commandValidation = document.getElementById("commandValidation");
var customCommand = document.getElementById("customCommand");
var changeIconButton = document.getElementById("changeIconButton");

openSelectorModal.addEventListener("click", openDataUploadModal);

importButton.addEventListener("click", function () {
  openUploadModal = true;
  openFileUploadModal();
  // document.querySelector('#imgupload').click();
});

function openDataUploadModal() {
  trackEvent("Click to paste all xpath");
  browserType.storage.local.get(["preCommandValue"], function (result) {
    customCommand.value =
      result.preCommandValue == undefined
        ? 'driver.findElement(By.xpath("xpathvalue"))'
        : result.preCommandValue;
  });
  submitBtn.textContent = "Submit";
  openUploadModal = false;

  document.getElementById("enterNewTitle").style.display = "block";
  document.getElementById("imgupload").style.display = "none";

  document.getElementById("addNewTitle").textContent =
    "Paste whole selectors page or script";
  // document.getElementById('addNewTitleLabel').textContent = "Please enter steps values.";
  document.getElementById("btn-submit").classList.add("submit-case");
  document.getElementById("btn-submit").classList.remove("submit-case");

  var modal = document.getElementById("addNewModal");
  modal.style.display = "block";
  document.getElementById("enterNewTitle").focus();

  // to clear input value
  document.getElementById("enterNewTitle").value = "";

  checkXpathInputCommand();
}

function closeAddNewModal() {
  var modal = document.getElementById("addNewModal");
  modal.style.display = "none";
  // var showtext = document.getElementById('textcuation')
  // showtext.style.display = 'none';
}

closeIcon.addEventListener(
  "click",
  function () {
    closeAddNewModal();
    // var showtext = document.getElementById('textcuation')
    // showtext.style.display = 'none';
  },
  false
);

cancelBtn.addEventListener(
  "click",
  function () {
    closeAddNewModal();
  },
  false
);

function extractXpath(xpath, command) {
  if (command) {
    var startInd = command.toLowerCase().indexOf("xpathvalue");
    if (startInd < 0) {
      return null;
    }
    var diff = command.length - startInd;
    return xpath.slice(startInd, -diff + 10);
  }
  return xpath;
}

function escapeRegExp(text) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  // text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')
}

function findMatches(regex, str, matches = []) {
  const res = regex.exec(str);
  res && matches.push(res) && findMatches(regex, str, matches);
  return matches;
}

function extractAllCommands(command, str) {
  try {
    return new Promise((res, rej) => {
      if (command) {
        var startInd = command.toLowerCase().indexOf("xpathvalue");
        var diff = command.length - startInd;
        var first = escapeRegExp(command.slice(0, startInd));
        var second = escapeRegExp(command.slice(-diff + 10));
        let re = new RegExp(first + "(.*?)" + second, "gi");

        // Usage
        const matches = findMatches(re, str);
        res(matches);
      }
    });
  } catch (err) {
    rej(err);
  }
}
customCommand.addEventListener("keyup", clearInputField, false);
submitBtn.addEventListener("click", showXpaths, false);

function clearInputField(e) {
  commandValidation.style.display = "none";
  browserType.storage.local.set(
    { preCommandValue: e.target.value },
    function () {}
  );
  if (!this.value.toLowerCase().includes("xpathvalue")) {
    commandValidation.style.display = "inline-block";
    this.classList.add("wrongXpath");
    this.style.backgroundColor = "#FF6347";
  } else if (this.value.toLowerCase().includes("xpathvalue")) {
    commandValidation.style.display = "none";
    this.classList.remove("wrongXpath");
    this.style.backgroundColor = "#FFF";
  }
}

async function showXpaths() {
  if (!multiSelectorRecord.className.includes("grey")) {
    smartFixScreen();
  }

  if (
    document.getElementById("inputToggle").classList.contains("active") &&
    !document
      .getElementById("customCommand")
      .value.toLowerCase()
      .includes("xpathvalue")
  ) {
    commandValidation.style.display = "inline-block";
    return;
  }

  if (
    document.getElementById("enterNewTitle").offsetParent &&
    !document.getElementById("enterNewTitle").value.length
  ) {
    return;
  }

  if (
    !document.getElementById("customCommand").value.trim() &&
    document.getElementById("inputToggle").classList.contains("active")
  )
    return;

  if (openUploadModal) {
    document.querySelector("#imgupload").click();
  } else {
    let allXpaths = document
      .getElementById("enterNewTitle")
      .value.replace(/”|“/g, '"');
    let customCommand = document
      .getElementById("customCommand")
      .value.trim()
      .replace(/”|“/g, '"');
    let bool = document.getElementById("inputToggle");
    if (bool.classList.contains("inactive")) {
      let splitLabels = allXpaths
        .trim()
        .split(/\r?\n/)
        .filter((labl) => labl !== "");
      SMsteps = splitLabels.map((xpath) => {
        return {
          Step: "-",
          XPath: xpath,
        };
      });

      document.querySelector(".selectorName-header").style.display = "none";
      selectorHeader.innerText = "XPath";
      tablePlaceholder.innerText = smartFixPlaceholder;
      resetSmart.textContent = "click to go back to default view";
      tutorialVideoLink.setAttribute("href", "https://bit.ly/smartmain");
      tutorialTooltip.textContent = "Smart Maintenance Tutorial";

      SMstepsWithOutCmd = [...SMsteps];
      appendRows(SMsteps, true);
    } else {
      let extractCommands = await extractAllCommands(customCommand, allXpaths);
      if (extractCommands) {
        let xpathArr = allXpaths.trim().split(/\r?\n/);
        // var patt = new RegExp(customCommand, 'g');
        // let splitLabels = bool ? allLabels.trim().split(/\r?\n/).filter(labl => labl !== '') : [];
        SMsteps = extractCommands.map((xpath) => {
          let generatedXpath = xpath[1];
          return {
            Step: "-",
            XPath: generatedXpath,
          };
        });

        document.querySelector(".selectorName-header").style.display = "none";
        selectorHeader.innerText = "XPath";
        tablePlaceholder.innerText = smartFixPlaceholder;
        resetSmart.textContent = "click to go back to default view";
        tutorialVideoLink.setAttribute("href", "https://bit.ly/smartmain");
        tutorialTooltip.textContent = "Smart Maintenance Tutorial";

        SMstepsWithOutCmd = [...SMsteps];
        appendRows(SMsteps, true);
      }
    }
    allXpaths.value = "";
  }
  closeAddNewModal();
}

//this is for smart maintenance
var inputToggle = document.getElementById("inputToggle");

inputToggle.addEventListener("click", function () {
  if (this.classList.contains("active")) {
    this.classList.remove("active");
    this.classList.add("inactive");
    document.getElementById("customCommand").style.display = "none";
    commandValidation.style.display = "none";
  } else {
    this.classList.remove("inactive");
    this.classList.add("active");
    document.getElementById("customCommand").style.display = "block";
  }
});

var indexFlag = false;

function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  var autosuggestToggleElement = document.querySelector(
    ".autosuggest-toggle-btn"
  );

  inp.addEventListener("input", function (e) {
    savedSelectors.style.display = "none";
    if (autosuggestToggleElement.classList.contains("active")) {
      listOfTextAndAttr = [];
      var a,
        b,
        c,
        i,
        xpathOrCss,
        val = this.value;
      var listOfTextAndAttr = [];

      if (
        val.charAt(0).includes("/") ||
        val.charAt(0).includes("(") ||
        val.substr(0, 2).includes("./")
      ) {
        listOfTextAndAttr = bothListOfTextAndAttr[1]; //this has attr only for xpath
        if (bothListOfTextAndAttr[3]) {
          if (!indexFlag) {
            listOfTextAndAttr.push(
              bothListOfTextAndAttr[3].split("-sanjayXpathIndex-")[0] +
                bothListOfTextAndAttr[3].split("-sanjayXpathIndex-")[1]
            ); //xpath with position
            indexFlag = true;
          } else {
            listOfTextAndAttr[listOfTextAndAttr.length - 1] =
              bothListOfTextAndAttr[3].split("-sanjayXpathIndex-")[0] +
              bothListOfTextAndAttr[3].split("-sanjayXpathIndex-")[1];
          }
        }
        xpathOrCss = "xpath";
      } else {
        listOfTextAndAttr = bothListOfTextAndAttr[2]; //this has attr only for css
        xpathOrCss = "css";
      }
      // var infoPlaceholder = document.querySelector(".infoPlaceholder div");
      // if(!listOfTextAndAttr){
      //     infoPlaceholder.style.color = "red";
      //     infoPlaceholder.style.marginLeft = "60px";
      //     // infoPlaceholder.style.marginTop = "10px";
      //     infoPlaceholder.innerHTML = "Ooops.....Looks like you are missing something.\n\n1. Close DevTools & open website in the new tab.\n2. There should be a url like <a  target='_blank' href='https://www.google.com/'>google.com</a> in the address bar.\n3. Neither Element should be inside different src iframe nor inside shadow-root (closed).\n4. For more details please checkout <a  target='_blank' href='https://www.selectorshub.com/faq/'>FAQs here.</a>\n5. If issue still persist, pls email me at <a href='mailto:selectorshub@gmail.com'>selectorshub@gmail.com</a>"

      //     return;
      // }else{
      //     infoPlaceholder.style.display = "none";
      // }

      var cursorPointer = 0;
      cursorPointer = e.target.selectionStart;
      cursorPointer = cursorPointer > 2 ? cursorPointer : 2;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) {
        return false;
      }
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      if(isSidePanelView){
        a.style =
          "position: absolute; background-color: #e0e0e0; width: 96%; max-height: 350px; overflow-y: auto; z-index: 5";
        }else{
        a.style =
          "position: absolute; background-color: #e0e0e0; width: 76%; max-height: 200px; overflow-y: auto; z-index: 5";
      }
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      var matchedAttr = "";

      for (i = 0; i < listOfTextAndAttr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        // if (listOfTextAndAttr[i].substr(0,2)==val.substr(0,val.length-1).substr(val.length-3) || listOfTextAndAttr[i].substr(0,3)==val.substr(0,val.length-1).substr(val.length-4) || listOfTextAndAttr[i].substr(0,4)==val.substr(0,val.length-1).substr(val.length-5) || listOfTextAndAttr[i].substr(0,2)==val.substr(val.length-2) || listOfTextAndAttr[i].substr(0,3)==val.substr(val.length-3) || listOfTextAndAttr[i].substr(0,4)==val.substr(val.length-4)) {
        if (
          ((val.slice(cursorPointer - 2, cursorPointer - 1) == "." ||
            val.slice(cursorPointer - 2, cursorPointer - 1) == "#") &&
            listOfTextAndAttr[i]
              .split("-sanjayMatchingNode-")[1]
              .substr(0, 1) ==
              val.slice(cursorPointer - 2, cursorPointer - 1)) ||
          (val.slice(cursorPointer - 1, cursorPointer) == "." &&
            listOfTextAndAttr[i]
              .split("-sanjayMatchingNode-")[1]
              .substr(0, 1) == val.slice(cursorPointer - 1, cursorPointer)) ||
          (val.slice(cursorPointer - 1, cursorPointer) == "#" &&
            listOfTextAndAttr[i]
              .split("-sanjayMatchingNode-")[1]
              .substr(0, 1) == val.slice(cursorPointer - 1, cursorPointer)) ||
          (val.slice(cursorPointer - 1, cursorPointer) == "[" &&
            listOfTextAndAttr[i]
              .split("-sanjayMatchingNode-")[1]
              .substr(0, 1) == val.slice(cursorPointer - 1, cursorPointer)) ||
          (val.slice(cursorPointer - 1, cursorPointer) == ":" &&
            listOfTextAndAttr[i]
              .split("-sanjayMatchingNode-")[1]
              .substr(0, 1) == val.slice(cursorPointer - 1, cursorPointer)) ||
          (val.slice(cursorPointer - 1, cursorPointer) == "@" &&
            listOfTextAndAttr[i]
              .split("-sanjayMatchingNode-")[1]
              .substr(0, 1) == val.slice(cursorPointer - 1, cursorPointer)) ||
          listOfTextAndAttr[i].split("-sanjayMatchingNode-")[1].substr(0, 2) ==
            val.slice(cursorPointer - 2, cursorPointer) ||
          listOfTextAndAttr[i].split("-sanjayMatchingNode-")[1].substr(0, 3) ==
            val.slice(cursorPointer - 3, cursorPointer) ||
          listOfTextAndAttr[i].split("-sanjayMatchingNode-")[1].substr(0, 4) ==
            val.slice(cursorPointer - 4, cursorPointer) ||
          listOfTextAndAttr[i].split("-sanjayMatchingNode-")[1].substr(0, 5) ==
            val.slice(cursorPointer - 5, cursorPointer)
        ) {
          /*create a DIV element for each matching element:*/

          matchedAttr = listOfTextAndAttr[i].split("-sanjayMatchingNode-")[1];

          b = document.createElement("DIV");
          b.style =
            "color: black; white-space: nowrap; text-overflow: ellipsis; width: 97.5%; overflow: hidden;-o-text-overflow: ellipsis;-ms-text-overflow: ellipsis;-moz-binding: url('ellipsis.xml#ellipsis');";
          if (isFirefox) {
            b.style.padding = "5px";
          }
          var matchinNode = listOfTextAndAttr[i].split(
            "-sanjayMatchingNode-"
          )[0]
            ? listOfTextAndAttr[i].split("-sanjayMatchingNode-")[0]
            : "";
          var attribute = listOfTextAndAttr[i].split("-sanjayMatchingNode-")[1];

          b.setAttribute("id", "auto" + xpathOrCss);
          b.setAttribute("value", attribute);
          b.setAttribute("title", "");

          if (matchinNode) {
            var matchingClass =
              matchinNode == "0"
                ? "node0"
                : matchinNode == "1"
                ? "node1"
                : matchinNode == "abc"
                ? "nodeHide"
                : "node2";
            var osClass = OS.includes("mac")
              ? "suggestedMatchingNode"
              : "suggestedMatchingNodeWindows";
            matchingClass = osClass + " " + matchingClass;
            b.innerHTML =
              "<span title='matching node' class='" +
              matchingClass +
              "'>" +
              matchinNode +
              "</span>";
          }
          b.innerHTML +=
            "<strong>" + attribute.substr(0, val.length) + "</strong>";
          b.innerHTML += attribute.substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += `<input type="hidden" value="` + attribute + `">`;
          /*execute a function when someone clicks on the item value (DIV element):*/

          b.addEventListener("click", function (e) {
            if (
              attribute != this.getAttribute("value") &&
              attribute.charAt(0) == "[" &&
              this.getAttribute("value").charAt(0) != "["
            ) {
              this.setAttribute("value", "[" + this.getAttribute("value"));
            }
            /*insert the value for the autocomplete text field:*/
            // inp.value = (inp.value.substr(0, inp.value.match(matchedAttr.substr(0, 2)).index) + this.innerText).replace("////","//");
            var caret = (
              inp.value
                .substr(0, cursorPointer)
                .substr(
                  0,
                  inp.value
                    .substr(0, cursorPointer)
                    .lastIndexOf(matchedAttr.substr(0, 1))
                ) + this.getAttribute("value")
            ).length;

            if (matchedAttr.substr(0, 2) == "(/") {
              inp.value = this.getAttribute("value");
            } else if (cursorPointer == 2 && matchedAttr.substr(0, 1) == "/") {
              var tempExisting =
                inp.value.substr(cursorPointer - 1) == "/"
                  ? ""
                  : inp.value.substr(cursorPointer - 1);
              inp.value =
                inp.value
                  .substr(0, cursorPointer)
                  .substr(
                    0,
                    inp.value
                      .substr(0, cursorPointer)
                      .lastIndexOf(matchedAttr.substr(0, 1))
                  ) +
                this.getAttribute("value") +
                tempExisting;
            } else {
              inp.value =
                inp.value
                  .substr(0, cursorPointer)
                  .substr(
                    0,
                    inp.value
                      .substr(0, cursorPointer)
                      .lastIndexOf(matchedAttr.substr(0, 1))
                  ) +
                this.getAttribute("value") +
                inp.value.substr(cursorPointer);
            }
            inp.value = inp.value.includes("...")
              ? replaceAll(inp.value, "...", "..")
              : inp.value; //replaceAll .. to .

            var noOfOpenSquareBracket = inp.value.match(/\[/g)
              ? inp.value.match(/\[/g).length
              : 0;
            var noOfCloseSquareBracket = inp.value.match(/\]/g)
              ? inp.value.match(/\]/g).length
              : 0;

            if (noOfOpenSquareBracket != noOfCloseSquareBracket) {
              inp.value = inp.value.includes("[[")
                ? replaceAll(inp.value, "[[", "[")
                : inp.value;
              inp.value = inp.value.includes("]]")
                ? replaceAll(inp.value, "]]", "]")
                : inp.value;
            }

            inp.value = inp.value.includes("////")
              ? replaceAll(inp.value, "////", "//")
              : inp.value;
            inp.value = inp.value.includes("///")
              ? replaceAll(inp.value, "///", "//")
              : inp.value;

            inp.value = inp.value.includes("+ +")
              ? replaceAll(inp.value, "+ +", "+")
              : inp.value;
            inp.value = inp.value.includes("++")
              ? replaceAll(inp.value, "++", "+")
              : inp.value;

            if (
              matchedAttr.substr(0, 2) == "(/" ||
              matchedAttr.substr(0, 2) == "]/"
            ) {
              caret = caret;
            } else {
              caret =
                inp.value.charAt(cursorPointer - 1) == "/" ? caret - 1 : caret;
            }

            setCaretPosition(inp, caret);
            checkWrongXpath();
            // showTotalCount = true;
            // selectElements("xpath", true);
            /*close the list of autocompleted values,
                  (or any other open lists of autocompleted values:*/
            closeAllLists();
          });
          var errorMsg = document
            .querySelector(".jsTotalMatchCount")
            .innerText.toLowerCase();
          if (!errorMsg.includes("invalid")) {
            a.appendChild(b);
          }
          //return;
        } else {
          //closeAllLists();
        }
      }
    }
    //})
  });

  function setCaretPosition(ctrl, pos) {
    // Modern browsers
    if (ctrl.setSelectionRange) {
      ctrl.focus();
      ctrl.setSelectionRange(pos, pos);

      // IE8 and below
    } else if (ctrl.createTextRange) {
      var range = ctrl.createTextRange();
      range.collapse(true);
      range.moveEnd("character", pos);
      range.moveStart("character", pos);
      range.select();
    }
  }

  /*execute a function presses a key on the keyboard:*/
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function (e) {
    var x = document.getElementById(this.id + "autocomplete-list");
    if (x) x = x.getElementsByTagName("div");
    if (e.keyCode == 40) {
      /*If the arrow DOWN key is pressed,
      increase the currentFocus variable:*/
      currentFocus++;
      /*and and make the current item more visible:*/
      addActive(x, "down");
    } else if (e.keyCode == 38) {
      //up
      /*If the arrow UP key is pressed,
      decrease the currentFocus variable:*/
      currentFocus--;
      /*and and make the current item more visible:*/
      addActive(x, "up");
    } else if (e.keyCode == 13) {
      /*If the ENTER key is pressed, prevent the form from being submitted,*/
      e.preventDefault();
      if (currentFocus > -1) {
        /*and simulate a click on the "active" item:*/
        if (x) x[currentFocus].click();
      }
      closeAllLists(e);
    }
  });

  function addActive(x, direction) {
    /*a function to classify an item as "active":*/
    let el = document.querySelector(".autocomplete-items");

    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    let condition = false;
    if (currentFocus >= x.length){
       currentFocus = 0;
       el.scroll({top: 0});
       condition = true;
    }
    if (currentFocus < 0){
      currentFocus = x.length - 1;
      el.scroll({top: el.scrollHeight});
      condition = true;
      }
    /*add class "autocomplete-active":*/
    try {
      x[currentFocus].classList.add("autocomplete-active");
      if(currentFocus > 0 && !condition){
        el.scroll({
          top: direction === "down" ? 29 + el.scrollTop : el.scrollTop - 29,
        });
      }
    } catch (err) {
      console.log(err);
    }
  }

  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }

  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
        x[i].parentNode.removeChild(x[i]);
      }
    }
  }
  /*execute a function when someone clicks in the document:*/
  document.addEventListener("click", function (e) {
    closeAllLists(e.target);
  });
}

/*An array containing all the attributes:*/
listOfTextAndAttr = ["@id", "@class", "@text", "@placeholder", "@name"];

/*initiate the autocomplete function on the "myInput" element, and pass along the attributes array as possible autocomplete values:*/
autocomplete(
  document.querySelector(".selectors-input.jsSelector"),
  listOfTextAndAttr
);

var evalString =
  "try{var ele =document.querySelector('*[xpathtest]');ele.removeAttribute('xpathtest');}catch(err){};$0.setAttribute('xpathtest','1');";

var relXpathWithCount = "";
var indexXpathWithCount = "";
var absXpathWithCount = "";
var cssSelectorWithCount = "";
var linkTextWithCount = "";
var partialLinkTextWithCount = "";
var idWithCount = "";
var classNameWithCount = "";
var nameWithCount = "";
var tagNameWithCount = "";
var label = "";
var testRigorPathWithCount = "";
var domContentCopyBtn = document.querySelector(".domContentCopyBtn");
var ignoreCaseBtn = document.querySelector(".ignoreCaseBtn");

function generateSelectors(callback, isCodeBtnAction) {
  infoPlaceholderParent.style.display = "none";
  ignoreCaseBtn.classList.remove("active");
  var xpathOrCss = document.querySelector(".editorTitle").value;

  var parentElement = document.querySelector(".parentElement");
  var childElement = document.querySelector(".childElement");
  var parentOrChild = "";
  if (axesBtn.classList.contains("active")) {
    if (parentElement.classList.contains("active")) {
      var axesXpathBox = document.querySelector(".axesXpath.axesXpathEditBtn");
      var axesCount = document.querySelector(".noOfAxesXpathMatch");
      if (axesXpathBox.innerText) {
        assignLastAxesXpath();
        axesXpathBox.innerText = "";
        axesCount.innerText = "0";
        axesCount.style.backgroundColor = "#f29a00a8";
      }

      parentOrChild = "parentElement";
      parentElement.classList.remove("active");
      parentElement.classList.add("inactive");
      childElement.classList.add("active");
      childElement.classList.remove("inactive");
      if(isSidePanelView){
        getActiveTabId().then(tabId => {
            postSafeMessage({
                name: "assign-parent-element",
                tabId
            })
        })
      }else{
        browserType.devtools.inspectedWindow.eval(
          "assignParentElement($0)",
          { useContentScriptContext: true });
      }
    } else if (childElement.classList.contains("active")) {
      parentOrChild = "childElement";
      childElement.classList.remove("active");
      childElement.classList.add("inactive");
      parentElement.classList.add("active");
      parentElement.classList.remove("inactive");
      if(isSidePanelView){
        getActiveTabId().then(tabId => {
            postSafeMessage({
                name: "create-axes-xpath-for-element",
                tabId
            })
        })
      }else{
        browserType.devtools.inspectedWindow.eval(
          "createAxesXpathForElement($0)",
          { useContentScriptContext: true },
          function (result) {
            if (result) {
              assignAxesXpath(result);
            }
          }
        );
      }
    }
  }

  chooseAttrsOption();
  toggleElement = document.querySelector(".toggle-btn");
  var hubMode = toggleElement.classList.contains("inactive")
    ? "onlyEditor"
    : "generatorAndEditor";
  if (
    toggleElement.classList.contains("active") &&
    multiSelectorRecord.className.includes("red")
  ) {
    hubMode = "generatorAndEditorRecording";
  }
  var elementInfoContainer = document.querySelector(".elementInfo");
  // if (isFirefox) {
  //   browserType.devtools.inspectedWindow.eval(evalString);
  //   elementInfoContainer.style.display = "none";
  //   domContentCopyBtn.style.display = "none";
  //   connectBackgroundPage.postMessage({
  //     name: hubMode,
  //     chooseAttrs: chooseAttrs,
  //     parentOrChild: parentOrChild,
  //     tabId: browserType.devtools.inspectedWindow.tabId,
  //   });
  // }
  if(isSidePanelView){
    getActiveTabId().then(tabId => {
        postSafeMessage({
            name: "prepare-list-of-attr-text",
            isCodeBtnAction,
            tabId
         })
         
         postSafeMessage({
             name: "element-type-and-info",
             shadowRootStatus: "none",
             isCodeBtnAction,
             tabId
         })
         
         if(hubMode.includes("generatorAndEditor")){
            //  let pwSelectorChoice = document.querySelector(".choose.pwSelector");
            //  let options = {
            //      pwSelector: pwSelectorChoice.checked
            //  }
             
             generatorCallback = callback ? callback : () => {};
             postSafeMessage({
                 name: "on-inspect-element-click",
                 isCodeBtnAction,
                 chooseAttrs,
                 hubMode,
                 shadowRootStatus: "none",
                 tabId,
             });
            //  if(callback) callback();
         }
    })
}else {
    browserType.devtools.inspectedWindow.eval(
      "prepareListOfAttrText($0)",
      { useContentScriptContext: true },
      function (result) {
        //elementInfoContainer.style.display="none";
        domContentCopyBtn.style.display = "none";
        bothListOfTextAndAttr = [];
        if (result) {
          bothListOfTextAndAttr = result;
        }
      }
    );
    browserType.devtools.inspectedWindow.eval(
      "elementTypeAndInfo($0)",
      { useContentScriptContext: true },
      function (result) {
        elementInfoContainer.style.display = "none";
        try {
          if (result.elementType) {
            setElementType(result.elementType);
          }
          if (result.elementInfo) {
            setElementAlertInfo(result.elementInfo);
          }
        } catch (err) {}
      }
    );
    if (hubMode.includes("generatorAndEditor")) {
      var a = browserType.devtools.inspectedWindow.eval(
        'onInspectElementClick($0, "' + chooseAttrs + '", "' + hubMode + '")',
        { useContentScriptContext: true },
        function (result) {
          assignSelectorsValue(result);
        }
      );
    }
  }
  saveCaseSensitiveSelectors();
  // setTimeout(function(){
  //     setConfigMargin();
  // }, 100);
}

if (isFirefox) {
  browserType.devtools.inspectedWindow.eval(evalString);
}

function replaceAll(str, a, b) {
  return str.split(a).join(b);
}

var attributeFilter = document.querySelector(".attributeFilter");
var attrFilterIcon = document.querySelector(".attrFilterBtn");
let attrFilterBtn = isSidePanelView ? document.querySelector(".set-attr") : document.querySelector(".attrFilterBtn");

attrFilterBtn.addEventListener("click", function (event) {
  trackEvent("click set attribute button");
  if (attributeFilter.style.display === "none") {
    browserType.storage.local.set(
      { attributeFilter: "active" },
      function () {}
    );
    attributeFilter.style.display = "flex";
    attrFilterIcon.classList.remove("inactive");
    attrFilterIcon.classList.add("active");
  } else {
    browserType.storage.local.set(
      { attributeFilter: "inactive" },
      function () {}
    );
    attributeFilter.style.display = "none";
    attrFilterIcon.classList.remove("active");
    attrFilterIcon.classList.add("inactive");
  }

  setImageAdsContainerHeight();
});

browserType.storage.local.get(["attributeFilter"], function (result) {
  if (result.attributeFilter == "inactive" || result.attributeFilter == undefined) {
    attributeFilter.style.display = "none";
    attrFilterIcon.classList.remove("active");
    attrFilterIcon.classList.add("inactive");
  }

  setImageAdsContainerHeight();
});

let setImageAdsContainerHeight = () => {
  if(isSidePanelView){
    let imageAdsContainer = document.querySelector("#image-ads");
    let offerAdsContainer = document.querySelector("#offer-countdown-ads");
    let attrFilterContainer = document.querySelector(".attributeFilter");
    let drvCmdContainer = document.querySelector(".driver-command-box");
  
    let height = 360;
  
    if(attrFilterBtn.children[0].classList.contains("active")) height += attrFilterContainer.clientHeight;
    if(addDriverCommandBtn.children[0].classList.contains("active")) height += drvCmdContainer.clientHeight;
    height += offerAdsContainer.clientHeight;
    
    imageAdsContainer.style.height = `calc(100% - ${height}px)`;
  }
}


setTimeout(function () {
  browserType.storage.local.get(["toggleElement"], function (result) {
    //var classList=result.toggleElement==undefined?"active":result.toggleElement;
    var shubGenerator = document.querySelector(".shub-generator");
    var configOptions = document.querySelector(".configOptions");
    if (result.toggleElement == "inactive") {
      toggleElement.setAttribute("data-before", "Off");
      toggleElement.classList.remove("active");
      toggleElement.classList.add("inactive");
      shubGenerator.style.display = "none";
      configOptions.style.visibility = "hidden";
      clearElements();
      var listElements = document.querySelector("#selectorsHubEleContainer");
      listElements.innerHTML = "";
      setElementContainerHeight();
    } else if (result.toggleElement == "active") {
      toggleElement.setAttribute("data-before", "On");
      toggleElement.classList.remove("inactive");
      toggleElement.classList.add("active");
      toggleState();
      setElementContainerHeight();
      generateSelectors();
    } else {
      // countdown();
      toggleState();
      document.querySelector(".infoPlaceholder div").style.display = "none";
      document.querySelector(".infoPlaceholder").style.display = "none";
    }

    var toggleBtnToolTip = document.querySelector(".toggle.toolTip");
    if (toggleElement.classList.contains("inactive")) {
      toggleBtnToolTip.textContent = "Turn on to get auto generated selectors.";
    } else {
      toggleBtnToolTip.textContent = "Turn off auto generated selectors.";
    }
  });
}, 90);

var patronCloseButton = document.querySelector(".closeIcon");
var patronRequest = document.querySelector(".patronRequest");
var patronRequestLink = document.querySelector(".patronRequest a");

var patronModal = document.querySelector(".patronModal");
var patronModalClose = document.querySelector(".patronClose");

patronCloseButton.addEventListener("click", function (event) {
  patronModal.style.display = "block";
  //patronRequest.style.display = "none";
  //browserType.storage.local.set({'patronRequest':"hide"}, function(){});
});

patronModalClose.addEventListener("click", function (event) {
  patronModal.style.display = "none";
  //browserType.storage.local.set({'patronModal':"hide"}, function(){});
});

var workEmailLink = document.querySelector(".workEmailLink");
workEmailLink.addEventListener("click", function (event) {
  patronModal.style.display = "none";
  browserType.storage.local.set({ patronModalEmail: "hide" }, function () {});
});

setTimeout(function () {
  browserType.storage.local.get(["patronModalEmail"], function (result) {
    if (result.patronModalEmail == "hide") {
      patronModal.style.display = "none";
    } else {
      //patronModal.style.display = "block";
      //browserType.storage.local.set({'patronModal':"hide"}, function(){});
    }
  });
}, 5000);

var reviewModalClose = document.querySelector(".reviewClose");
var reviewModal = document.querySelector(".reviewModal");
reviewModalClose.addEventListener("click", function (event) {
  reviewModal.style.display = "none";
  browserType.storage.local.set({ reviewModal: "hide" }, function () {});
});

var modalReviewLink2 = document.querySelector(".modalReviewLink2");
modalReviewLink2.addEventListener("click", function (event) {
  reviewModal.style.display = "none";
  browserType.storage.local.set({ reviewModal: "hide" }, function () {});
});

setTimeout(function () {
  browserType.storage.local.get(["reviewModal"], function (result) {
    if (result.reviewModal == "hide") {
      reviewModal.style.display = "none";
    } else {
      // reviewModal.style.display = "block";
    }
  });
}, 300000);

setTimeout(function () {
  reviewModal.style.display = "none";
}, 330000);

var tweetModalClose = document.querySelector(".tweetClose");
var tweetModal = document.querySelector(".tweetModal");
tweetModalClose.addEventListener("click", function (event) {
  tweetModal.style.display = "none";
  browserType.storage.local.set({ tweetModal1: "hide" }, function () {});
});

var tweetLink2 = document.querySelector(".tweetLink2");
tweetLink2.addEventListener("click", function (event) {
  tweetModal.style.display = "none";
  browserType.storage.local.set({ tweetModal1: "hide" }, function () {});
});

setTimeout(function () {
  browserType.storage.local.get(["tweetModal1"], function (result) {
    if (result.tweetModal1 == "hide") {
      tweetModal.style.display = "none";
    } else {
      // tweetModal.style.display = "block";
    }
  });
}, 120000);

setTimeout(function () {
  tweetModal.style.display = "none";
}, 150000);

var instructionModalClose = document.querySelector(".instructionClose");
var instructionModal = document.querySelector(".instructionModal");
instructionModalClose.addEventListener("click", function (event) {
  instructionModal.style.display = "none";
  browserType.storage.local.set({ instructionModal2: "hide" }, function () {});
});

var instructionLink2 = document.querySelector(".instructionLink2");
instructionLink2.addEventListener("click", function (event) {
  instructionModal.style.display = "none";
  browserType.storage.local.set({ instructionModal3: "hide" }, function () {});
});

setTimeout(function () {
  browserType.storage.local.get(["instructionModal3"], function (result) {
    if (result.instructionModal3 == "hide") {
      instructionModal.style.display = "none";
    } else {
      instructionModal.style.display = "block";
    }
  });
}, 30000);

setTimeout(function () {
  instructionModal.style.display = "none";
  browserType.storage.local.set({ instructionModal3: "hide" }, function () {});
}, 50000);
// window.onclick = function(event) {
//   if (event.target == patronModal) {
//     patronModal.style.display = "none";
//   }
// }
/*
setTimeout(function(){ 
    // patronCloseButton.addEventListener("click", function(event) {
    //     patronRequest.style.display = "none";
    //     browserType.storage.local.set({'ratingRequest':"hide"}, function(){});
    // });

    // patronRequestLink.addEventListener("click", function(event) {
    //     patronRequest.style.display = "none";
    //     browserType.storage.local.set({'ratingRequest':"hide"}, function(){});
    // });
    // var patronBannerRequest = "";
    browserType.storage.local.get(['patronRequest'], function(result){
        if(result.patronRequest=="hide"){
            //patronRequest.style.display = "none";
        }
    
        // if(multiSelectorRecordBtn.className.includes("grey") && !result.patronRequest.includes("hide")){
        //     patronRequest.style.display = "block";
        // }
    });
}, 15000);
*/
// var footerBanner = document.querySelector(".footer");
function hideFooter() {
  //patronRequest.style.display = "none";
  // footerBanner.style.display = "none";
  countdownBtn.style.display = "none";
  browserType.storage.local.set({ patronRequest: "hide" }, function () {});
}

browserType.storage.local.get(["patronRequest"], function (result) {
  if (result.patronRequest == "hide") {
    //patronRequest.style.display = "none";
    // footerBanner.style.display = "none";
    countdownBtn.style.display = "none";
    toggleElement.classList.remove("notPatron");
    plusBtn.classList.remove("notPatron");
    copyAllBtnXPath.classList.remove("notPatron");
    copyAllBtnCssSelector.classList.remove("notPatron");
    nestedCodeCopyBtn.classList.remove("notPatron");
  }
});

var debug = document.querySelector(".debugBtn");
var debugBtn = isSidePanelView ? document.querySelector(".debugBtn-c") : document.querySelector(".debugBtn");
debugBtn.addEventListener("click", function () {
  trackEvent("turn on debugger");
  debug.classList.remove("inactive");
  debug.classList.add("active");
  var debuggerTime = document.querySelector(".choose.debugTime").value; //milisecond
  debuggerTime = debuggerTime * 1000;
  //browserType.devtools.inspectedWindow.eval("setTimeout(()=>{debugger;}, "+debuggerTime+");");
  if(isSidePanelView){
    getActiveTabId().then(tabId => {
        postSafeMessage({
            name: "turn-on-debugger", 
            debuggerTime,
            tabId
        });
    })
  }else{
    browserType.devtools.inspectedWindow.eval(
      "turnOnDebugger(`" + debuggerTime + "`)",
      { useContentScriptContext: true });
  }
  // connectBackgroundPage.postMessage({
  //     name: "debuggerOn",
  //     debuggerTime: debuggerTime,
  //     tabId: browserType.devtools.inspectedWindow.tabId
  // });

  setTimeout(function () {
    debug.classList.remove("active");
    debug.classList.add("inactive");
  }, 15000);
  // browserType.devtools.inspectedWindow.eval("debugger;");
});

var defaultXpath,
  defaultCss,
  userSelector = "";
ignoreCaseBtn.addEventListener("click", function () {
  trackEvent("click make selectors sensitive");
  generateIgnoreCaseSelectors();
});

function generateIgnoreCaseSelectors() {
  var searchBox = document.querySelector(".selectors-input.jsSelector");
  var xpath = document.querySelector(".box.valueSelector.rel.relXpathEditBtn");
  var css = document.querySelector(".box.valueSelector.css.cssEditBtn");

  if (ignoreCaseBtn.classList.contains("active")) {
    ignoreCaseBtn.classList.remove("active");
    searchBox.value = userSelector;
    css.textContent = defaultCss;
    relXpathWithCount[0] = defaultXpath;
    generateColoredRelXpath();
  } else {
    ignoreCaseBtn.classList.add("active");

    saveCaseSensitiveSelectors();
    if (searchBox.value) {
      if (searchBox.value.charAt(0) != "/" && !searchBox.value.includes("i]")) {
        searchBox.value = ignoreCaseInCss(searchBox.value);
      } else if (
        searchBox.value.charAt(0) == "/" &&
        !searchBox.value.includes("translate(")
      ) {
        searchBox.value = ignoreCaseInXPath(searchBox.value);
      }
    }

    if (xpath.textContent && !xpath.textContent.includes("translate(")) {
      relXpathWithCount[0] = ignoreCaseInXPath(xpath.textContent);
      generateColoredRelXpath();
    }

    if (css.textContent && !css.textContent.includes(" i]")) {
      css.textContent = ignoreCaseInCss(css.textContent);
    }
  }
}

function saveCaseSensitiveSelectors() {
  var searchBox = document.querySelector(".selectors-input.jsSelector");
  var xpath = document.querySelector(".box.valueSelector.rel.relXpathEditBtn");
  var css = document.querySelector(".box.valueSelector.css.cssEditBtn");

  userSelector = searchBox.value;
  defaultXpath = xpath.textContent;
  defaultCss = css.textContent;
}

function ignoreCaseInXPath(xpath) {
  var caseValue =
    "translate(textAttribute, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz')";

  var textAttrValue = xpath.split("[")[1].includes(",")
    ? xpath.split("[")[1].split(",")[1]
    : xpath.split("[")[1].split("=")[1];
  var ignoredXPath = xpath;
  try {
    xpath = xpath.replace(textAttrValue, textAttrValue.toLowerCase());

    var attrName = xpath.split("[")[1].includes(",")
      ? xpath.split("[")[1].split(",")[0]
      : xpath.split("[")[1].split("=")[0];

    var attrAlone = attrName.includes("contains")
      ? attrName.split("contains(")[1]
      : attrName.includes("starts-with")
      ? attrName.split("starts-with(")[1]
      : attrName;

    var finalValue = caseValue.replace("textAttribute", attrAlone);

    ignoredXPath = xpath.replace(attrAlone, finalValue);
  } catch (err) {}

  return ignoredXPath;
}

function ignoreCaseInCss(css) {
  css = css.replaceAll("]", " i]");
  return css;
}

function executeScript() {
  var a = document.querySelector(".jsSelector").value;
  try {
    if(isSidePanelView){
      getActiveTabId().then(tabId => {
          postSafeMessage({
              name: "execute-js",
              scriptValue: a,
              tabId
          })
      })
    }else{
      browserType.devtools.inspectedWindow.eval(
        "executeJs(" + a + ")",
        { useContentScriptContext: true },
        function (result) {
          if (result) {
            if (result.length > 0) {
              showAllMatchingNode(result);
            }
            showTotalResults(result);
          }
        }
      );
    }
  } catch (err) {
    console.log(err);
  }
}

var autosuggestToggleElement = document.querySelector(
  ".autosuggest-toggle-btn"
);
autosuggestToggleElement.addEventListener("click", function () {
  trackEvent("Left Toggle");
  autosuggestToggleAction();
});

function autosuggestToggleAction() {
  var autoSuggestToggleBtnToolTip = document.querySelector(
    ".autosuggest-toggle.toolTip"
  );

  if (autosuggestToggleElement.classList.contains("active")) {
    browserType.storage.local.set({ autosuggestToggleElement: "inactive" });
    autosuggestToggleElement.classList.remove("active");
    autosuggestToggleElement.classList.add("inactive");
    autoSuggestToggleBtnToolTip.textContent =
      "Turn on to get auto suggested functions while typing.";
  } else {
    browserType.storage.local.set({ autosuggestToggleElement: "active" });
    autosuggestToggleElement.classList.remove("inactive");
    autosuggestToggleElement.classList.add("active");
    autoSuggestToggleBtnToolTip.textContent =
      "Turn off auto suggestions while typing.";
  }
}

browserType.storage.local.get(["autosuggestToggleElement"], function (result) {
  if (result.autosuggestToggleElement == "inactive") {
    autosuggestToggleElement.classList.remove("active");
    autosuggestToggleElement.classList.add("inactive");
  }
});

var quotesBtnToolTip = document.querySelector(".quotes.toolTip");
quotesBtn.addEventListener("click", function (event) {
  trackEvent("generate selectors with double quote");
  if (quotes.classList.contains("inactive")) {
    browserType.storage.local.set({ quotesBtn: "active" }, function () {});
    quotes.classList.remove("inactive");
    quotes.classList.add("active");

    var xpath = document.querySelector(
      ".box.valueSelector.rel.relXpathEditBtn"
    );
    if (
      xpath.textContent &&
      xpath.textContent.includes(`'`) &&
      !xpath.textContent.includes(`"`)
    ) {
      xpath.textContent = xpath.textContent.replaceAll(`'`, `"`);
    }

    var css = document.querySelector(".box.valueSelector.css.cssEditBtn");
    if (
      css.textContent &&
      css.textContent.includes(`'`) &&
      !css.textContent.includes(`"`)
    ) {
      css.textContent = css.textContent.replaceAll(`'`, `"`);
    }
    quotesBtnToolTip.textContent =
      "Click to generate selectors with single quote.";
  } else {
    browserType.storage.local.set({ quotesBtn: "inactive" }, function () {});
    quotes.classList.remove("active");
    quotes.classList.add("inactive");

    var xpath = document.querySelector(
      ".box.valueSelector.rel.relXpathEditBtn"
    );
    if (
      xpath.textContent &&
      xpath.textContent.includes(`"`) &&
      !xpath.textContent.includes(`'`)
    ) {
      xpath.textContent = xpath.textContent.replaceAll(`"`, `'`);
    }

    var css = document.querySelector(".box.valueSelector.css.cssEditBtn");
    if (
      css.textContent &&
      css.textContent.includes(`"`) &&
      !css.textContent.includes(`'`)
    ) {
      css.textContent = css.textContent.replaceAll(`"`, `'`);
    }
    quotesBtnToolTip.textContent =
      "Click to generate selectors with double quote.";
  }
});

browserType.storage.local.get(["quotesBtn"], function (result) {
  if (result.quotesBtn == "active") {
    quotes.classList.remove("inactive");
    quotes.classList.add("active");
    quotesBtnToolTip.textContent =
      "Click to generate selectors with single quote.";
  }
});

var expandBtn = document.querySelector(".expand-btn");
var expandBtnToolTip = document.querySelector(".expand.toolTip");
expandBtn.addEventListener("click", function (event) {
  trackEvent("expand selectors block");
  if (expandBtn.classList.contains("inactive")) {
    browserType.storage.local.set({ expandBtn: "active" }, function () {});
    expandBtn.classList.remove("inactive");
    expandBtn.classList.add("active");

    var selectorBlock = document.querySelector(".selectorsGenerator");
    selectorBlock.style.height = "auto";
    //selectorBlock.style.minHeight = "125px";
    selectorBlock.style.maxHeight = "fit-content";

    expandBtnToolTip.textContent =
      "Click to set default view of selectors block.";
  } else {
    browserType.storage.local.set({ expandBtn: "inactive" }, function () {});
    expandBtn.classList.remove("active");
    expandBtn.classList.add("inactive");

    var selectorBlock = document.querySelector(".selectorsGenerator");
    selectorBlock.style.maxHeight = "125px";
    selectorBlock.style.height = "auto";
    expandBtnToolTip.textContent =
      "Click to expand selectors block to see all generated selectors.";
  }

  //setConfigMargin();
});

browserType.storage.local.get(["expandBtn"], function (result) {
  if (result.expandBtn == "active") {
    expandBtn.classList.remove("inactive");
    expandBtn.classList.add("active");
    expandBtnToolTip.textContent =
      "Click to set default view of selectors block.";

    var selectorBlock = document.querySelector(".selectorsGenerator");
    selectorBlock.style.height = "auto";
    selectorBlock.style.maxHeight = "fit-content";
  }
});

var plusBtn = document.querySelector(".plus-btn");
var plusBtnToolTip = document.querySelector(".plus.toolTip");
var savedSelectors = document.querySelector(".savedSelectors");
var selecotrsArray = [];

plusBtn.addEventListener("click", function (event) {
  trackEvent("click save selector ");
  var value = document.querySelector(".jsSelector").value;

  if (plusBtn.classList.contains("notPatron")) {
    patronModal.style.display = "block";
  }

  if (
    !plusBtn.classList.contains("notPatron") &&
    value &&
    !selecotrsArray.includes(value)
  ) {
    document.querySelector(".savedSelectorRow.delete span").innerText = "";
    deleteAllSaved.style.display = "inline-block";
    if (value && !selecotrsArray.includes(value)) {
      if (selecotrsArray.length >= 10) {
        selecotrsArray.shift();
        savedSelectors.removeChild(savedSelectors.childNodes[9]);
      }

      selecotrsArray.push(value);
      var dummyElement = createElement("li");
      dummyElement.setAttribute("class", "savedSelectorRow");
      dummyElement.setAttribute(
        "title",
        "Click to edit this value in selector box"
      );
      dummyElement.innerHTML = value;
      dummyElement.addEventListener("click", function (event) {
        document.querySelector(".jsSelector").value = dummyElement.innerHTML;
        savedSelectors.style.display = "none";
      });

      browserType.storage.local.set(
        { selecotrsArray: selecotrsArray },
        function () {}
      );

      savedSelectors.insertBefore(dummyElement, savedSelectors.firstChild);
      showCopied();
      //savedSelectors.appendChild(dummyElement);
    }
  }
});

browserType.storage.local.get(["selecotrsArray"], function (result) {
  if (result.selecotrsArray) {
    selecotrsArray = result.selecotrsArray;
    var count = selecotrsArray.length > 10 ? 10 : selecotrsArray.length;
    if (count > 0) {
      document.querySelector(".savedSelectorRow.delete span").innerText = "";
      deleteAllSaved.style.display = "inline-block";
    }
    for (var i = 0; i < count; i++) {
      var dummyElement = createElement("li");
      dummyElement.setAttribute("class", "savedSelectorRow");
      dummyElement.setAttribute(
        "title",
        "Click to edit this value in selector box"
      );
      dummyElement.innerHTML = selecotrsArray[i];
      dummyElement.addEventListener("click", function (event) {
        document.querySelector(".jsSelector").value = event.target.innerHTML;
        savedSelectors.style.display = "none";
      });
      savedSelectors.insertBefore(dummyElement, savedSelectors.firstChild);
    }
  }
});

var editorContent = document.querySelector(".editorContent");
editorContent.addEventListener("click", function (event) {
  trackEvent("see saved selectors");
  //var removeCookie = chrome.cookies.remove({ url:"https://selectorshub.com/",name:"selectorshub authentication"});
  /*
    removeCookie.then(()=>{
        alert("removed");
    },()=>{
        alert("error");
    })*/
  if (savedSelectors.style.display == "block") {
    savedSelectors.style.display = "none";
  } else if (savedSelectors.childElementCount > 0) {
    savedSelectors.style.display = "block";
  }
});

function setConfigMargin() {
  var selectorsBlockHeight = document.querySelector(
    ".selectorsGenerator"
  ).offsetHeight;
  var diff = selectorsBlockHeight - 125;
  if (diff > 20) {
    var top = 121 + diff;
    document.querySelector(".configOptions").style.marginTop = "-" + top + "px";
  } else {
    document.querySelector(".configOptions").style.marginTop = "-121px";
  }
}

var deleteAllSaved = document.querySelector(".deleteAllSaved");

deleteAllSaved.addEventListener("click", function () {
  selecotrsArray = [];
  browserType.storage.local.set(
    { selecotrsArray: selecotrsArray },
    function () {}
  );
  var allRowsContainer = document.querySelector(".savedSelectors");
  var allRows = document.querySelectorAll(".savedSelectorRow");
  for (var i = 0; i < allRows.length - 1; i++) {
    allRowsContainer.removeChild(allRowsContainer.firstChild);
  }
  document.querySelector(".savedSelectorRow.delete span").innerText =
    "No value is saved.";
  deleteAllSaved.style.display = "none";
});

function getFormattedTime() {
  var today = new Date();
  var y = today.getFullYear();
  // JavaScript months are 0-based.
  var m = today.getMonth() + 1;
  var d = today.getDate();
  var h = today.getHours();
  var mi = today.getMinutes();
  var s = today.getSeconds();
  return y + "-" + m + "-" + d + "-" + h + "-" + mi + "-" + s;
}

function toggleState() {
  var infoPlaceholder = document.querySelector(".infoPlaceholder div");
  var infoPlaceholderParent = document.querySelector(".infoPlaceholder");
  var shubGenerator = document.querySelector(".shub-generator");
  var configOptions = document.querySelector(".configOptions");
  var selectorsHubEleContainer = document.querySelector(
    ".selectorsHubEleContainer"
  );
  var nestedCode = document.querySelector("#nestedCode");
  var nestedBlock = document.querySelector("#nestedBlock");
  if (toggleElement.classList.contains("inactive")) {
    infoPlaceholder.style.display = "none";
    infoPlaceholderParent.style.display = "none";
    shubGenerator.style.display = "none";
    configOptions.style.visibility = "hidden";
    nestedBlock.style.display = "none";
    nestedCode.textContent = "";
    clearElements();
  } else {
    infoPlaceholder.style.display = "none";
    infoPlaceholderParent.style.display = "none";
    shubGenerator.style.display = "block";
    configOptions.style.visibility = "visible";
  }
  var toggleBtnToolTip = document.querySelector(".toggle.toolTip");
  if (toggleElement.classList.contains("inactive")) {
    toggleBtnToolTip.textContent = "Turn on to get auto generated selectors.";
  } else {
    toggleBtnToolTip.textContent = "Turn off auto generated selectors.";
  }
}

var footerCounter = document.querySelector(".footerCounter");
function countdown() {
  var seconds = 300;
  function tick() {
    var toggleCounter = document.querySelector(".toggle-btn");
    footerCounter = document.querySelector(".footerCounter");
    seconds--;
    toggleCounter.setAttribute(
      "data-before",
      "0:" + (seconds < 10 ? "0" : "") + String(seconds)
    );
    footerCounter.innerHTML =
      "0:" + (seconds < 10 ? "0" : "") + String(seconds);

    if (seconds > 0) {
      setTimeout(tick, 1000);
    } else {
      var shubGenerator = document.querySelector(".shub-generator");
      var configOptions = document.querySelector(".configOptions");
      toggleElement.classList.remove("active");
      toggleElement.classList.add("inactive");
      shubGenerator.style.display = "none";
      configOptions.style.visibility = "hidden";
      clearElements();
      var listElements = document.querySelector("#selectorsHubEleContainer");
      listElements.innerHTML = "";
      setElementContainerHeight();
      patronModal.style.display = "block";
      deActivateAllButtons();
    }
  }
  tick();
}

var axesBtn = document.querySelector(".axes-btn");
var axesXpathGenerator = document.querySelector(".axesXpathGenerator");
axesBtn.addEventListener("click", function () {
  trackEvent("click axes btn");
  deActivateAllButtons(axesBtn);

  var selectorsGenerator = document.querySelector(".selectorsGenerator");
  var listElements = document.querySelector("#selectorsHubEleContainer");
  var uiConfig = document.querySelector(".uiConfig");
  var nestedBlock = document.querySelector("#nestedBlock");
  var axesTooltip = document.querySelector(".axes.toolTip");

  if (axesBtn.classList.contains("inactive")) {
    axesBtn.classList.add("active");
    axesBtn.classList.remove("inactive");
    selectorsGenerator.style.display = "none";
    listElements.style.display = "none";
    setElementContainerHeight();
    axesXpathGenerator.style.display = "block";
    multiSelectorContainer.style.display = "none";
    uiConfig.style.display = "none";
    axesTooltip.textContent = "Click to reset and go back to home screen.";
  } else {
    selectorsGenerator.style.display = "block";
    listElements.style.display = "block";
    axesXpathGenerator.style.display = "none";
    axesBtn.classList.add("inactive");
    axesBtn.classList.remove("active");
    multiSelectorContainer.style.display = "none";
    if (nestedBlockOn == "yes") {
      nestedBlock.style.display = "block";
    }
    axesTooltip.textContent = "Click to generate Axes based XPath.";
    patronRequest.style.display = "flex";
  }

  var parentElement = document.querySelector(".parentElement");
  var childElement = document.querySelector(".childElement");
  parentElement.classList.remove("inactive");
  parentElement.classList.add("active");
  childElement.classList.add("inactive");
  childElement.classList.remove("active");
});

function assignAxesXpath(axesXpathWithCount) {
  var axesXpathBox = document.querySelector(".axesXpath.axesXpathEditBtn");
  var count = document.querySelector(".noOfAxesXpathMatch");

  axesXpathWithCount[0] = addDriverCommand.className.includes("inactive")
    ? axesXpathWithCount[0]
    : addPreCommandInSelector(axesXpathWithCount[0]);

  axesXpathBox.innerText = axesXpathWithCount[0];
  count.style.backgroundColor =
    axesXpathWithCount[1] == "1"
      ? "#0cb9a9"
      : axesXpathWithCount[1] == "0"
      ? "#ff0000"
      : "#f78f06";
  count.innerText = axesXpathWithCount[1];
}

function assignLastAxesXpath() {
  var axesXpathBox = document.querySelector(".axesXpath.axesXpathEditBtn");
  var axesCount = document.querySelector(".noOfAxesXpathMatch");

  var lastAxesXpathBox = document.querySelector(
    ".lastAxesXpath.lastAxesXpathEditBtn"
  );
  var lastAxesXpathCount = document.querySelector(".noOfLastAxesXpathMatch");
  lastAxesXpathBox.innerText = axesXpathBox.innerText;
  lastAxesXpathCount.style.backgroundColor =
    axesCount.innerText == "1"
      ? "#0cb9a9"
      : axesCount.innerText == "0"
      ? "#ff0000"
      : "#f78f06";
  lastAxesXpathCount.innerText = axesCount.innerText;
}

var uiSetting = document.querySelector(".uiSetting-btn");
var uiSettingBtn = isSidePanelView ? document.querySelector(".uiSetting-btn-c")  : uiSetting;
var uiConfig = document.querySelector(".uiConfig");
uiSettingBtn.addEventListener("click", function () {
  trackEvent("customize UI");
  deActivateAllButtons(uiSetting);

  let imageAdsContainer = document.querySelector("#image-ads");

  var nestedBlock = document.querySelector("#nestedBlock");
  var selectorsGenerator = document.querySelector(".selectorsGenerator");
  var listElements = document.querySelector("#selectorsHubEleContainer");
  var uiSettingToolTip = document.querySelector(".uiSetting.toolTip");

  if (uiSetting.classList.contains("inactive")) {
    uiSetting.classList.add("active");
    uiSetting.classList.remove("inactive");
    selectorsGenerator.style.display = "none";
    listElements.style.display = "none";
    uiConfig.style.display = "block";
    multiSelectorContainer.style.display = "none";
    axesXpathGenerator.style.display = "none";
    if(isSidePanelView) imageAdsContainer.classList.add("hideElement");
    setElementContainerHeight();
    // uiSettingToolTip.textContent = "Click to go back to home screen.";
  } else {
    selectorsGenerator.style.display = "block";
    listElements.style.display = "block";
    uiConfig.style.display = "none";
    uiSetting.classList.add("inactive");
    uiSetting.classList.remove("active");
    multiSelectorContainer.style.display = "none";
    if (nestedBlockOn == "yes") {
      nestedBlock.style.display = "block";
    }
    if(isSidePanelView) imageAdsContainer.classList.remove("hideElement");
    setElementContainerHeight();
    uiSettingToolTip.textContent = "Click to customize UI.";
    patronRequest.style.display = "flex";
  }
});

var cssSelectorChoice = document.querySelector(".choose.cssSelector");
cssSelectorChoice.addEventListener("click", function () {
  var cssContainer = document.querySelector(".selectorsRow.cssSelector");
  if (cssSelectorChoice.checked) {
    cssContainer.style.display = "block";
    browserType.storage.local.set({ cssSelectorChoice: "yes" }, function () {});
  } else {
    cssContainer.style.display = "none";
    browserType.storage.local.set({ cssSelectorChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["cssSelectorChoice"], function (result) {
  if (result.cssSelectorChoice == "no") {
    cssSelectorChoice.checked = false;
  }
});

var relXpathChoice = document.querySelector(".choose.relXpath");
relXpathChoice.addEventListener("click", function () {
  var relXpathContainer = document.querySelector(".selectorsRow.relXpath");
  if (relXpathChoice.checked) {
    relXpathContainer.style.display = "block";
    browserType.storage.local.set({ relXpathChoice: "yes" }, function () {});
  } else {
    relXpathContainer.style.display = "none";
    browserType.storage.local.set({ relXpathChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["relXpathChoice"], function (result) {
  if (result.relXpathChoice == "no") {
    relXpathChoice.checked = false;
  }
});

var testRigorPathChoice = document.querySelector(".choose.testRigorPath");
testRigorPathChoice.addEventListener("click", function () {
  var testRigorPathContainer = document.querySelector(
    ".selectorsRow.testRigorPath"
  );
  if (testRigorPathChoice.checked) {
    testRigorPathContainer.style.display = "block";
    browserType.storage.local.set(
      { testRigorPathChoice: "yes" },
      function () {}
    );
  } else {
    testRigorPathContainer.style.display = "none";
    browserType.storage.local.set(
      { testRigorPathChoice: "no" },
      function () {}
    );
  }
});

browserType.storage.local.get(["testRigorPathChoice"], function (result) {
  if (result.testRigorPathChoice == "no") {
    testRigorPathChoice.checked = false;
  }
});

var suggestedXpathChoice = document.querySelector(".choose.suggestedXpath");
suggestedXpathChoice.addEventListener("click", function () {
  var suggestedXpathContainer = document.querySelector(
    ".selectorsRow.suggestedXpath"
  );
  if (suggestedXpathChoice.checked) {
    suggestedXpathContainer.style.display = "block";
    browserType.storage.local.set(
      { suggestedXpathChoice: "yes" },
      function () {}
    );
  } else {
    suggestedXpathContainer.style.display = "none";
    browserType.storage.local.set(
      { suggestedXpathChoice: "no" },
      function () {}
    );
  }
});

browserType.storage.local.get(["suggestedXpathChoice"], function (result) {
  if (result.suggestedXpathChoice == "no") {
    suggestedXpathChoice.checked = false;
  }
});

var indexXpathChoice = document.querySelector(".choose.indexXpath");
indexXpathChoice.addEventListener("click", function () {
  var indexXpathContainer = document.querySelector(".selectorsRow.indexXpath");
  if (indexXpathChoice.checked) {
    indexXpathContainer.style.display = "block";
    browserType.storage.local.set({ indexXpathChoice: "yes" }, function () {});
  } else {
    indexXpathContainer.style.display = "none";
    browserType.storage.local.set({ indexXpathChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["indexXpathChoice"], function (result) {
  if (result.indexXpathChoice == "no") {
    indexXpathChoice.checked = false;
  }
});

var idChoice = document.querySelector(".choose.id");
idChoice.addEventListener("click", function () {
  var idContainer = document.querySelector(".selectorsRow.id");
  if (idChoice.checked) {
    idContainer.style.display = "block";
    browserType.storage.local.set({ idChoice: "yes" }, function () {});
  } else {
    idContainer.style.display = "none";
    browserType.storage.local.set({ idChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["idChoice"], function (result) {
  if (result.idChoice == "no") {
    idChoice.checked = false;
  }
});

var nameChoice = document.querySelector(".choose.name");
nameChoice.addEventListener("click", function () {
  var nameContainer = document.querySelector(".selectorsRow.name");
  if (nameChoice.checked) {
    nameContainer.style.display = "block";
    browserType.storage.local.set({ nameChoice: "yes" }, function () {});
  } else {
    nameContainer.style.display = "none";
    browserType.storage.local.set({ nameChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["nameChoice"], function (result) {
  if (result.nameChoice == "no") {
    nameChoice.checked = false;
  }
});

var classNameChoice = document.querySelector(".choose.className");
classNameChoice.addEventListener("click", function () {
  var classNameContainer = document.querySelector(".selectorsRow.className");
  if (classNameChoice.checked) {
    classNameContainer.style.display = "block";
    browserType.storage.local.set({ classNameChoice: "yes" }, function () {});
  } else {
    classNameContainer.style.display = "none";
    browserType.storage.local.set({ classNameChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["classNameChoice"], function (result) {
  if (result.classNameChoice == "no") {
    classNameChoice.checked = false;
  }
});

var jQueryChoice = document.querySelector(".choose.jQuery");
jQueryChoice.addEventListener("click", function () {
  var jQueryContainer = document.querySelector(".selectorsRow.jQuery");
  if (jQueryChoice.checked) {
    jQueryContainer.style.display = "block";
    browserType.storage.local.set({ jQueryChoice: "yes" }, function () {});
  } else {
    jQueryContainer.style.display = "none";
    browserType.storage.local.set({ jQueryChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["jQueryChoice"], function (result) {
  if (result.jQueryChoice == "no") {
    jQueryChoice.checked = false;
  }
});

var jsPathChoice = document.querySelector(".choose.jsPath");
jsPathChoice.addEventListener("click", function () {
  var jsPathContainer = document.querySelector(".selectorsRow.jsPath");
  if (jsPathChoice.checked) {
    jsPathContainer.style.display = "block";
    browserType.storage.local.set({ jsPathChoice: "yes" }, function () {});
  } else {
    jsPathContainer.style.display = "none";
    browserType.storage.local.set({ jsPathChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["jsPathChoice"], function (result) {
  if (result.jsPathChoice == "no") {
    jsPathChoice.checked = false;
  }
});

var linkTextChoice = document.querySelector(".choose.linkText");
linkTextChoice.addEventListener("click", function () {
  var linkTextContainer = document.querySelector(".selectorsRow.linkText");
  if (linkTextChoice.checked) {
    linkTextContainer.style.display = "block";
    browserType.storage.local.set({ linkTextChoice: "yes" }, function () {});
  } else {
    linkTextContainer.style.display = "none";
    browserType.storage.local.set({ linkTextChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["linkTextChoice"], function (result) {
  if (result.linkTextChoice == "no") {
    linkTextChoice.checked = false;
  }
});

var partialLinkTextChoice = document.querySelector(".choose.partialLinkText");
partialLinkTextChoice.addEventListener("click", function () {
  var partialLinkTextContainer = document.querySelector(
    ".selectorsRow.partialLinkText"
  );
  if (partialLinkTextChoice.checked) {
    partialLinkTextContainer.style.display = "block";
    browserType.storage.local.set(
      { partialLinkTextChoice: "yes" },
      function () {}
    );
  } else {
    partialLinkTextContainer.style.display = "none";
    browserType.storage.local.set(
      { partialLinkTextChoice: "no" },
      function () {}
    );
  }
});

browserType.storage.local.get(["partialLinkTextChoice"], function (result) {
  if (result.partialLinkTextChoice == "no") {
    partialLinkTextChoice.checked = false;
  }
});

var absXpathChoice = document.querySelector(".choose.absXpath");
absXpathChoice.addEventListener("click", function () {
  var absXpathContainer = document.querySelector(".selectorsRow.absXpath");
  if (absXpathChoice.checked) {
    absXpathContainer.style.display = "block";
    browserType.storage.local.set({ absXpathChoice: "yes" }, function () {});
  } else {
    absXpathContainer.style.display = "none";
    browserType.storage.local.set({ absXpathChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["absXpathChoice"], function (result) {
  if (result.absXpathChoice == "no") {
    absXpathChoice.checked = false;
  }
});

var systemInfoChoice = document.querySelector(".choose.systemInfo");
systemInfoChoice.addEventListener("click", function () {
  if (systemInfoChoice.checked) {
    systemInfoContainer.style.display = "block";
    patronRequest.style.bottom = "13px";
    browserType.storage.local.set({ systemInfoChoice: "yes" }, function () {});
  } else {
    systemInfoContainer.style.display = "none";
    patronRequest.style.bottom = "0px";
    browserType.storage.local.set({ systemInfoChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["systemInfoChoice"], function (result) {
  if (result.systemInfoChoice == "no") {
    systemInfoChoice.checked = false;
    systemInfoContainer.style.display = "none";
    patronRequest.style.bottom = "0px";
  } else if (result.systemInfoChoice == "yes") {
    systemInfoChoice.checked = true;
    systemInfoContainer.style.display = "block";
    patronRequest.style.bottom = "13px";
  }
});

var tagNameChoice = document.querySelector(".choose.tagName");
tagNameChoice.addEventListener("click", function () {
  var tagNameContainer = document.querySelector(".selectorsRow.tagName");
  if (tagNameChoice.checked) {
    tagNameContainer.style.display = "block";
    browserType.storage.local.set({ tagNameChoice: "yes" }, function () {});
  } else {
    tagNameContainer.style.display = "none";
    browserType.storage.local.set({ tagNameChoice: "no" }, function () {});
  }
});

browserType.storage.local.get(["tagNameChoice"], function (result) {
  if (result.tagNameChoice == "no") {
    tagNameChoice.checked = false;
  }
});

var autoSuggestToggleChoice = document.querySelector(
  ".choose.autoSuggestToggle"
);
autoSuggestToggleChoice.addEventListener("click", function () {
  var autoSuggestToggleContainer = document.querySelector("#autosuggestToggle");
  if(isSidePanelView){
    autosuggestToggleAction();
    autoSuggestToggleChoice.checked = autoSuggestToggleContainer.classList.contains("inactive") ? false : true;
    return;
  }
  if (autoSuggestToggleChoice.checked) {
    autoSuggestToggleContainer.style.visibility = "visible";
    browserType.storage.local.set(
      { autoSuggestToggleChoice: "yes" },
      function () {}
    );
  } else {
    autoSuggestToggleContainer.style.visibility = "hidden";
    browserType.storage.local.set(
      { autoSuggestToggleChoice: "no" },
      function () {}
    );
  }
});

browserType.storage.local.get(["autoSuggestToggleChoice"], function (result) {
  var autoSuggestToggleContainer = document.querySelector("#autosuggestToggle");
  if (result.autoSuggestToggleChoice == "no") {
    autoSuggestToggleChoice.checked = false;
    autoSuggestToggleContainer.style.visibility = "hidden";
  }
});

var autoGenerateToggleChoice = document.querySelector(
  ".choose.autoGenerateToggle"
);
autoGenerateToggleChoice.addEventListener("click", function () {
  var autoGenerateToggleContainer = document.querySelector(".toggle-btn");
  if(isSidePanelView){
    toggleAction();
    generateSelectors();
    autoGenerateToggleChoice.checked = autoGenerateToggleContainer.classList.contains("inactive") ? false : true;
    return;
  }
  if (autoGenerateToggleChoice.checked) {
    autoGenerateToggleContainer.style.visibility = "visible";
    browserType.storage.local.set(
      { autoGenerateToggleChoice: "yes" },
      function () {}
    );
  } else {
    autoGenerateToggleContainer.style.visibility = "hidden";
    browserType.storage.local.set(
      { autoGenerateToggleChoice: "no" },
      function () {}
    );
  }
});

browserType.storage.local.get(["autoGenerateToggleChoice"], function (result) {
  var autoGenerateToggleContainer = document.querySelector(".toggle-btn");
  if (result.autoGenerateToggleChoice == "no") {
    autoGenerateToggleChoice.checked = false;
    autoGenerateToggleContainer.style.visibility = "hidden";
  }
});

var caseInsensitiveBtnChoice = document.querySelector(
  ".choose.caseInsensitiveBtn"
);
caseInsensitiveBtnChoice.addEventListener("click", function () {
  var ignoreCaseBtnContainer = document.querySelector(".ignoreCaseBtn");
  if (caseInsensitiveBtnChoice.checked) {
    ignoreCaseBtnContainer.style.visibility = "visible";
    browserType.storage.local.set(
      { caseInsensitiveBtnChoice: "yes" },
      function () {}
    );
  } else {
    ignoreCaseBtnContainer.style.visibility = "hidden";
    browserType.storage.local.set(
      { caseInsensitiveBtnChoice: "no" },
      function () {}
    );
  }
});

browserType.storage.local.get(["caseInsensitiveBtnChoice"], function (result) {
  var ignoreCaseBtnContainer = document.querySelector(".ignoreCaseBtn");
  if (result.caseInsensitiveBtnChoice == "no") {
    caseInsensitiveBtnChoice.checked = false;
    ignoreCaseBtnContainer.style.visibility = "hidden";
  }
});

function deActivateAllButtons(element) {
  var selectorsGenerator = document.querySelector(".selectorsGenerator");
  var listElements = document.querySelector("#selectorsHubEleContainer");
  selectorsGenerator.style.display = "none";
  listElements.style.display = "none";
  patronRequest.style.display = "none";

  var multiSelectorRecordBtn = document.querySelector(
    ".multiSelectorRecordBtn"
  );
  if (element != multiSelectorRecordBtn) {
    multiSelectorContainer.style.display = "none";
    multiSelectorRecordBtn.classList.add("grey");
    multiSelectorRecordBtn.classList.remove("red");
  }

  var smartFix = document.querySelector("#smartFix");
  if (element != smartFix) {
    multiSelectorContainer.style.display = "none";
    smartFix.classList.remove("defaultsmartFix");
  }

  var uiSettingBtn = document.querySelector(".uiSetting-btn");
  if (element != uiSettingBtn) {
    uiConfig.style.display = "none";
    uiSettingBtn.classList.add("inactive");
    uiSettingBtn.classList.remove("active");
  }

  var axesBtn = document.querySelector(".axes-btn");
  if (element != axesBtn) {
    axesXpathGenerator.style.display = "none";
    axesBtn.classList.add("inactive");
    axesBtn.classList.remove("active");
  }

  var nestedBlock = document.querySelector("#nestedBlock");
  nestedBlock.style.display = "none";
}

var countdownBtn = document.querySelector(".countdown-btn");
// countdownBtn.addEventListener("click", function(){
//     patronModal.style.display = "block";
// });

var debugTimeBox = document.querySelector(".choose.debugTime");
debugTimeBox.addEventListener("keyup", function (event) {
  var time = debugTimeBox.value;
  time = time ? time : 5;
  browserType.storage.local.set({ debugTime: time }, function () {});
});

browserType.storage.local.get(["debugTime"], function (result) {
  if (result.debugTime) {
    debugTimeBox.value = result.debugTime;
  }
});
var country;
var city;
function trackEvent(payload) {
  if(typeof payload !== "string"){
    fetch(`${API_URL}analytics/trackAd`, {
      method: "post",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });
  }
}
// function trackEvent(event) {
//   browserType.storage.local.get(["ext_uniq_id"], (storage) => {
//     let payload = {
//       extension: EXT_ID,
//       events: [
//         {
//           user_id: storage.ext_uniq_id,
//           event_type: event,
//           user_properties: {
//             Cohort: "Test A",
//           },
//           country: countryName,
//           // "city": response.city,
//           // "timezone": response.timezone,
//           // "region": response.regionName,
//           // "carrier": response.isp,
//           platform: platform,
//           OS: OS,
//         },
//       ],
//     };

//     fetch(`${API_URL}analytics/trackAd`, {
//       method: "post",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify(payload),
//     });
//   });
// }

window.onload = function () {
  let authenticated = false;
  var incognitoMode = browserType.extension.inIncognitoContext;
  var automatedWindow = navigator.webdriver;

  var cookies = browserType.cookies.getAll({}, function (cookies) {
    for (const cookie of cookies) {
      if (cookie.name == "selectorshub authentication") {
        authenticated = true;
      }
    }
    if (!authenticated) {
      setCookies();
    }
  });
  // document.getElementById("register_form").style.display="none";
  //document.querySelector(".container").style.display="block";
  /*
    if(true || incognitoMode || automatedWindow){
        
        document.getElementById("register_form").style.display="none";
        document.querySelector(".container").style.display="block";
    }else{
        if(isFirefox){
            browser.storage.sync.get(['cookie'],function(data){
                if(data.cookie){
                    authenticated = true;
                    document.getElementById("register_form").style.display="none";
                    document.querySelector(".container").style.display="block";
                }
                if(!authenticated){
                    document.querySelector(".container").style.display="none";
                    document.querySelector("#register_form").style.display="true";
                }
            })  
        }else{
            var cookies = browserType.cookies.getAll({},function(cookies){
                for(const cookie of cookies){
                    if(cookie.name == "selectorshub authentication"){
                        authenticated = true;
                        document.getElementById("register_form").style.display="none";
                        document.querySelector(".container").style.display="block";
                    }
                    
                }
                if(!authenticated){
                    document.querySelector(".container").style.display="none";
                    document.querySelector("#register_form").style.display="true";
                }
            });
        }
    }
    */
};

// registerBtn.addEventListener("click",function(e){
//     e.preventDefault();
//     var timeStamp = getFormattedTime();

//     if(registerBtn.value=="Register"){
//         trackEvent("Registration");
//         if(email.value !=="" && pass.value !==""){
//             if(email.value.includes("@") && email.value.includes(".")){
//                 try{
//                     OS = typeof OS == "undefined" ? "default": OS;
//                     platform = typeof platform == "undefined" ? "default": platform;
//                     city = typeof city == "undefined" ? "default": city;
//                     country = typeof country == "undefined" ? "default": country;
//                     timeStamp = typeof timeStamp == "undefined" ? "default": timeStamp;
//                     browserType.runtime.sendMessage({type:"register", OS:OS, browser:platform, city:city, country:country, email:email.value,password:"111111",company:company.value, timeStamp:timeStamp},(response)=>{

//                         setCookies();
//                     });
//                 }catch(err){
//                     browserType.runtime.sendMessage({type:"register", OS:"default", browser:"default", city:"default", country:"default", email:email.value,password:"111111",company:company.value, timeStamp:timeStamp},(response)=>{

//                         setCookies();
//                     });
//                 }
//             }else{
//                 alert("Enter valid email.");
//             }
//         }else{
//             alert("email and password required.");
//         }
//     }
//     if(registerBtn.value=="Login"){
//         if(email.value !==""){
//             browserType.runtime.sendMessage({type:"login",email:email.value},(response)=>{
//                 //alert(response.message);
//                 if(response.message=="registred"){
//                     setCookies();
//                 }else{
//                     alert("This email is not registred, please click on register to create account.");
//                 }
//             })
//         }else{
//             alert("Enter valid email.");
//         }
//     }
// })
/*
loginLink.addEventListener("click",function(){
    if(this.innerText=="Login"){
        company.style.display="none";
        pass.style.display="none";
        document.getElementById("form_title").innerHTML="Please Login To Continue";
        registerBtn.value="Login";
        spanLogin.innerHTML="Don't have an account, ";
        this.innerText="Register";
        spanLogin.append(this);
    }else{
        company.style.display="block";
        pass.style.display="block";
        document.getElementById("form_title").innerHTML="Please Register To Continue";
        registerBtn.value="Register";
        spanLogin.innerHTML="Existing User, ";
        this.innerText="Login";
        spanLogin.append(this);
    }
})*/

function setCookies() {
  const expirationdate = Math.floor(Date.now() / 1000) + 630720000;
  if (isFirefox) {
    browser.storage.sync.set({ cookie: "authenticated" }, function () {});
  } else {
    chrome.cookies.set({
      url: "https://selectorshub.com/",
      name: "selectorshub authentication",
      value: "true",
      secure: true,
      expirationDate: expirationdate,
    });
  }
}

var driverCommandInput = document.querySelector(".driver-command");
var savedCommand = document.querySelector(".savedCommand");

driverCommandInput.addEventListener("click", function (event) {
  if (savedCommand.style.display == "block") {
    savedCommand.style.display = "none";
  } else if (savedCommand.childElementCount > 0) {
    savedCommand.style.display = "block";
  }
});

var savedCommandRow = document.querySelectorAll(".savedCommandRow");
for (var i = 0; i < savedCommandRow.length; i++) {
  savedCommandRow[i].addEventListener("click", function (event) {
    driverCommandInput.value = event.target.innerHTML;
    driverCommandInput.focus();
    savedCommand.style.display = "none";
    generateSelectors(null, true);
    generateSuggestedXpath();
  });
}

function setElementType(elementType) {
  var userSelectorValue = document.querySelector(".jsSelector").value;
  var inputBox = document.querySelector(".selectors-input");
  var selectorEditBox = document.querySelector(".selector-editor-div");
  var suggestedXpathContainer = document.querySelector(
    ".selectorsRow.suggestedXpath"
  );
  var iframeXpathContainer = document.querySelector(
    ".selectorsRow.iframeXpath"
  );
  var editorTitle = document.querySelector(".editorTitle");
  var editorContent = document.querySelector(".editorContent");
  var totalMatchingCount = document.querySelector(".total-match-count");

  let iframe =
    elementType == "frame" ? true : elementType == "iframe" ? true : false;
  let svgElement = elementType === "svgelement";
  let shadowDom = elementType.includes("shadowdom");
  let notIframe = elementType.includes("notIframe");

  if (iframe || shadowDom || svgElement) {
    if (shadowDom) {
      editorTitle.innerText = "in ShadowDOM";
      insideShadowDom = true;
      selectorEditBox.style.width = selectorEditBoxWidthShadow;
      editorContent.style.backgroundColor = "#2196F3";
      editorContent.style.color = "#ffffff";
      totalMatchingCount.style.marginLeft = totalCountMarginShadow;
      inputBox.setAttribute(
        "placeholder",
        "Write & verify cssSelector as XPath doesn't support shadowDOM......Click on ➕ icon to save value ➡️"
      );
      var info = `Alert: This element is inside shadow dom which can't be accessed through XPath, use cssSelector for it.<a class="training" href="https://bit.ly/sh_courses_recordings" target="_blank"> Learn more...</a>`;
      elementInfoAlert(info, "#2196f3");
    } else if (svgElement) {
      editorContent.style.color = "#ffffff";
      selectorEditBox.style.width = selectorEditBoxWidth;
      editorTitle.innerText = "SVG element...";
      if (!shadowDom && !iframe) {
        editorContent.style.backgroundColor = "#f5388fb3";
      }
      totalMatchingCount.style.marginLeft = totalCountMarginSvg;
      inputBox.setAttribute(
        "placeholder",
        "Write & verify XPath & CSS Selector here......Click on ➕ icon to save value ➡️"
      );
      var info = `Alert: This is a svg element & it doesn't support standard XPath format.<a class="training" href="https://bit.ly/sh_courses_recordings" target="_blank"> Learn more...</a>`;
      elementInfoAlert(info, "#f5388fb3");
    } else {
      //insideShadowDom = false;
      insideFrame = true;

      //selectorEditBox.style.width = OS.includes('mac') ? "calc(100% - 104px)" : "calc(100% - 110px)";

      editorContent.style.color = "black";
      // editorTitle.innerText = " in "+message.count+" ";
      editorTitle.innerText = " inside iframe ";
      editorContent.style.backgroundColor = "#cccccc";
      totalMatchingCount.style.marginLeft =
        elementType == "frame" ? totalCountMarginFrame : totalCountMarginIframe;
      inputBox.setAttribute(
        "placeholder",
        "Write & verify XPath & CSS Selector here......Click on ➕ icon to save value ➡️"
      );
      var info = `Alert: This element is inside iframe. Switch inside iframe to access it through automation.<a class="training" href="https://bit.ly/sh_courses_recordings" target="_blank"> Learn more...</a>`;
      elementInfoAlert(info, "#747272");
    }

    if (elementType === undefined || shadowDom || svgElement || elementType.includes("notIframe")) {
      iframeXpathContainer.style.display = "none";
    }
  } else if (notIframe) {
    insideShadowDom = false;
    editorContent.style.color = "black";
    editorTitle.innerText = "XPath/cssSel..";
    editorContent.style.backgroundColor =
      themeName === "dark" ? "#f29a00db" : "#f29a00a8";
    selectorEditBox.style.width = selectorEditBoxWidth;
    iframeXpathContainer.style.display = "none";
    totalMatchingCount.style.marginLeft = totalCountMargin;
    inputBox.setAttribute(
      "placeholder",
      "Write & verify XPath & CSS Selector here......Click on ➕ icon to save value ➡️"
    );
    setElementContainerHeight();
  }
}

function setElementAlertInfo(elementInfo) {
  elementInfo = elementInfo.split("elementInfo-")[1];
  elementInfoAlert(elementInfo, "#eb3030");
}

function receiveXpathResults(message) {
  try {
    if (message.url && !pageDomainName) {
      pageDomainName = message.url.replace(/.+\/\/|www.|\..+/g, "");
    }
  } catch (err) {}

  var wrong;
  var iframeXpath;
  var suggestedSelector;
  var textAndAttr;
  var xpathOrCss = "xpath";
  var pageReload = "";
  var sanjayXpathIndex;

  var userSelectorValue = document.querySelector(".jsSelector").value;
  var inputBox = document.querySelector(".selectors-input");
  var selectorEditBox = document.querySelector(".selector-editor-div");
  var suggestedXpathContainer = document.querySelector(
    ".selectorsRow.suggestedXpath"
  );
  var iframeXpathContainer = document.querySelector(
    ".selectorsRow.iframeXpath"
  );
  var editorTitle = document.querySelector(".editorTitle");
  var editorContent = document.querySelector(".editorContent");
  var totalMatchingCount = document.querySelector(".total-match-count");
  suggestedXpathContainer.style.display = "none";

  var axesXpathWithCount;
  var elementInfo;

  //elementInfoContainer.style.display="none";

  try {
    axesXpathWithCount = message.axesXpathWithCount;
  } catch (err) {}

  try {
    wrong = message.errorDetail.includes("wrong");

    iframeXpath =
      message.iframeSelector[0] == "iframe"
        ? true
        : message.iframeSelector[0] == "frame"
        ? true
        : false;

    suggestedSelector = message.suggestedSelector.includes("suggestedSelector");

    //textAndAttr = (message.count).includes("z$*[shub]");
    //pageReload = (message.count).includes("pageReload");

    sanjayXpathIndex = message.indexBasedXpath.includes("sanjayXpathIndex");

    //elementInfo = message.count.split("elementInfo-")[1];
  } catch (err) {}

  if (axesXpathWithCount) {
    assignAxesXpath(axesXpathWithCount);
  }

  if (iframeXpath) {
    var iframeXpathBox = document.querySelector(".valueSelector.iframeXpath");
    var typeOfLocator = document.querySelector(
      ".typeOfLocator.box.iframeCopyBtn"
    );
    typeOfLocator.innerText = message.iframeSelector[0] + " XPath";

    iframeXpathBox.style.color = "white";

    if (message.iframeSelector[1][0]) {
      iframeXpathContainer.style.display = "block";
    } else {
      iframeXpathContainer.style.display = "none";
    }

    message.iframeSelector[1][0] = addDriverCommand.className.includes(
      "inactive"
    )
      ? message.iframeSelector[1][0]
      : addPreCommandInSelector(message.iframeSelector[1][0]);
    //message.count[1][0] = message.count[1][0].includes("By.xpath")?message.count[1][0].replace("By.xpath", "By.cssSelector"):message.count[1][0].includes("By(xpath")?message.count[1][0].replace("By(xpath", "By(cssSelector"):message.count[1][0].includes("ByXPath")?message.count[1][0].replace("ByXPath", "ByCssSelector"):message.count[1][0].includes("XPath")?message.count[1][0].replace("XPath", "CssSelector"):message.count[1][0].includes("Xpath")?message.count[1][0].replace("Xpath", "CssSelector"):message.count[1][0].includes("XPATH")?message.count[1][0].replace("XPATH", "CSSSELECTOR"):message.count[1][0].replace("xpath","cssSelector");
    var nestedIframe = message.iframeSelector[2];
    var nestedCode = document.querySelector("#nestedCode");
    var nestedBlock = document.querySelector("#nestedBlock");
    if (
      nestedIframe.length > 0 &&
      !multiSelectorRecord.classList.contains("red") &&
      !smartFix.classList.contains("defaultsmartFix") &&
      !uiSetting.classList.contains("active") &&
      !axesBtn.classList.contains("active")
    ) {
      nestedBlockOn = "yes";
      nestedBlock.style.display = "block";
      var finalScript =
        "//This element is inside " +
        (nestedIframe.length + 1) +
        " nested frames.";

      var eleOrXpath = addDriverCommand.className.includes("inactive")
        ? "XPath for"
        : "WebElement";
      var driverCommandBox = document.querySelector(".driver-command");
      if (
        !addDriverCommand.className.includes("inactive") &&
        driverCommandBox.value
      ) {
        eleOrXpath = "WebElement";
      } else {
        eleOrXpath = "XPath for";
      }

      for (var i = 1; i <= nestedIframe.length; i++) {
        nestedIframe[i - 1] = addDriverCommand.className.includes("inactive")
          ? nestedIframe[i - 1]
          : addPreCommandInSelector(nestedIframe[i - 1]);
        nestedIframe[i - 1] = nestedIframe[i - 1].replace(";", ""); //remove semicolon from the user command as we are adding in next step
        finalScript =
          finalScript +
          "\n" +
          eleOrXpath +
          " frame" +
          i +
          " = " +
          nestedIframe[i - 1] +
          ";";
      }
      var tempXpath = addDriverCommand.className.includes("inactive")
        ? relXpathWithCount[0]
        : addPreCommandInSelector(relXpathWithCount[0]);
      finalScript =
        finalScript +
        "\n" +
        eleOrXpath +
        " frame" +
        (nestedIframe.length + 1) +
        " = " +
        message.iframeSelector[1][0].replace(";", "") +
        ";" +
        "\n" +
        eleOrXpath +
        " inspectedElement = " +
        tempXpath.replace(";", "") +
        ";";
      nestedCode.textContent = finalScript;
    } else if (!insideShadowDom) {
      nestedBlock.style.display = "none";
      nestedBlockOn = "no";
    }

    iframeXpathBox.innerText = message.iframeSelector[1][0];
    // iframeXpathBox.setAttribute("title",message.count[1][0]);
    document.querySelector(".noOfMatch.iframeXpath").textContent =
      message.iframeSelector[1][1];
    var count = document.querySelector(".noOfMatch.iframeXpath");

    count.style.backgroundColor =
      message.iframeSelector[1][1] == "1"
        ? "#0cb9a9"
        : message.iframeSelector[1][1] == "0"
        ? "#ff0000"
        : "#f78f06";

    setElementContainerHeight();
  }
  // if(textAndAttr){
  //     bothListOfTextAndAttr = [];
  //     bothListOfTextAndAttr = message.count;
  // }
  if (sanjayXpathIndex) {
    sanjayXpathIndex = "";
    bothListOfTextAndAttr[3] = message.indexBasedXpath;
  }
  if (suggestedSelector) {
    var suggestedXpathBox = document.querySelector(
      ".valueSelector.suggestedXpath"
    );
    suggestedXpathContainer.style.display = "block";

    var suggestedXpathChoice = document.querySelector(".choose.suggestedXpath");
    if (!suggestedXpathChoice.checked) {
      suggestedXpathContainer.style.display = "none";
    }

    if (
      message.suggestedSelector[1] === undefined ||
      insideShadowDom ||
      message.suggestedSelector[1][1] == "0"
    ) {
      suggestedXpathContainer.style.display = "none";
    } else {
      message.suggestedSelector[1][0] = addDriverCommand.className.includes(
        "inactive"
      )
        ? message.suggestedSelector[1][0]
        : addPreCommandInSelector(message.suggestedSelector[1][0]);
      message.suggestedSelector[1][0] =
        message.suggestedSelector[1][0].includes("By.xpath")
          ? message.suggestedSelector[1][0].replace(
              "By.xpath",
              "By.cssSelector"
            )
          : message.suggestedSelector[1][0].includes("By(xpath")
          ? message.suggestedSelector[1][0].replace(
              "By(xpath",
              "By(cssSelector"
            )
          : message.suggestedSelector[1][0].includes("ByXPath")
          ? message.suggestedSelector[1][0].replace("ByXPath", "ByCssSelector")
          : message.suggestedSelector[1][0].includes("XPath")
          ? message.suggestedSelector[1][0].replace("XPath", "CssSelector")
          : message.suggestedSelector[1][0].includes("Xpath")
          ? message.suggestedSelector[1][0].replace("Xpath", "CssSelector")
          : message.suggestedSelector[1][0].includes("XPATH")
          ? message.suggestedSelector[1][0].replace("XPATH", "CSSSELECTOR")
          : message.suggestedSelector[1][0].replace("xpath", "cssSelector");
      suggestedXpathBox.innerText = message.suggestedSelector[1][0];
      // suggestedXpathBox.setAttribute("title",message.count[1][0]);
      document.querySelector(".noOfMatch.suggestedXpath").textContent =
        message.suggestedSelector[1][1];
      var count = document.querySelector(".noOfMatch.suggestedXpath");

      count.style.backgroundColor =
        message.suggestedSelector[1][1] == "1"
          ? "#0cb9a9"
          : message.suggestedSelector[1][1] == "0"
          ? "#ff0000"
          : "#f78f06";
    }
    setElementContainerHeight();
  }

  if (wrong) {
    suggestedXpathContainer.style.display = "none";
    highlightWrongXpath();
    showTotalResults(message.errorDetail);
    return;
  } else {
    removeWrongXpath();
    if (showTotalCount) {
      showTotalResults(message.allNodes);
    }
    try {
      if (
        document.querySelector(".jsSelector").value ||
        (message.allNodes.length === 1 &&
          !toggleElement.classList.contains("inactive"))
      ) {
        if(message.allNodes.length > 0){
          showAllMatchingNode(message.allNodes);
        }
      }
    } catch (err) {}
    // if(message.event) {
    //     if(message.event === "shown") {
    //         selectElements(xpathOrCss, false);
    //     }
    // }
  }

  //scroll selectors to top
  document.querySelector(".selectorsGenerator").scrollTop = 0;
}

//undo redo
var ctrlDown = false,
  focusText1 = false,
  focusText2 = false,
  focusText3 = false,
  shiftKeyDown = false,
  shiftKey = 16,
  vKey = 86,
  cKey = 67,
  zKey = 90;

function TempStorage() {
  this.undoStorage = [];
  this.tempStorage = [];

  this.push = function (obj) {
    this.tempStorage.push(obj);
    this.print();
  };

  this.redo = function (obj) {
    const element = this.undoStorage.pop();
    if (element) {
      element.element.value = element.value;
      this.tempStorage.push(element);
    }
  };

  //focusText
  this.pop = function (obj) {
    const element = this.tempStorage.pop();
    if (element) {
      element.element.value = element.value;
      this.undoStorage.push(element);
    } else if (obj) {
      obj.value = "";
    }
    this.print();
  };

  this.print = function () {};
}

function onKeyUp(e, searchStorage, inputBox, focusText) {
  if (e.keyCode == 17 || e.keyCode == 91) {
    if (ctrlDown && !shiftKeyDown && inputBox.value) {
      searchStorage.push({ value: inputBox.value, element: inputBox });
    }
    ctrlDown = true;
    return false;
  }

  if(e.keyCode === 13){
    if(inputBox.id === "searchbox3"){
      generateSelectors(null, true);
      generateSuggestedXpath();
      updateGAEvents();
    }
  }
  if (e.keyCode == shiftKey) {
    shiftKeyDown = true;
    return false;
  }
  if (!focusText) {
    return false;
  }

  if (ctrlDown && shiftKeyDown && e.keyCode == zKey) {
    searchStorage.redo(inputBox);
  } else if (ctrlDown && e.keyCode == zKey) {
    searchStorage.pop(inputBox);
    return false;
  } else if (
    !((ctrlDown && e.keyCode == cKey) || (ctrlDown && e.keyCode == vKey))
  ) {
    if (inputBox && inputBox.value) {
      searchStorage.push({ value: inputBox.value, element: inputBox });
    }
  } else if (
    (ctrlDown && e.keyCode == cKey) ||
    (ctrlDown && e.keyCode == vKey)
  ) {
    return;
  }
}

//selectors input box
const id1 = "searchbox1";
const searchStorage1 = new TempStorage();
const inputBox1 = document.getElementById(id1);
inputBox1.onkeydown = (e) => onKeyUp(e, searchStorage1, inputBox1, focusText1);
inputBox1.onfocus = () => {
  focusText1 = true;
};
inputBox1.onblur = () => {
  focusText1 = false;
};

//command input box
const id2 = "searchbox2";
const searchStorage2 = new TempStorage();
const inputBox2 = document.getElementById(id2);
inputBox2.onkeydown = (e) => onKeyUp(e, searchStorage2, inputBox2, focusText2);
inputBox2.onfocus = () => {
  focusText2 = true;
};
inputBox2.onblur = () => {
  focusText2 = false;
};

//attr filter input box
const id3 = "searchbox3";
const searchStorage3 = new TempStorage();
const inputBox3 = document.getElementById(id3);
inputBox3.onkeydown = (e) => onKeyUp(e, searchStorage3, inputBox3, focusText3);
inputBox3.onfocus = () => {
  focusText3 = true;
};
inputBox3.onblur = () => {
  focusText3 = false;
};

document.body.onkeydown = (e) => {
  // onKeyUp(e, searchStorage1, inputBox1, focusText1);
  // onKeyUp(e, searchStorage2, inputBox2, focusText2);
  // onKeyUp(e, searchStorage3, inputBox3, focusText3);
};

document.body.onkeyup = function (e) {
  if (e.keyCode == 17 || e.keyCode == 91) {
    ctrlDown = false;
  } else if (e.keyCode == 16) {
    shiftKeyDown = false;
  }
};
let buildAdText;
// AD Viewer - START
let adsText = document.querySelector(".ads__text");
let adsContainer = document.querySelector(".ads__container");
let adsViewer = document.querySelector(".ads__viewer");

let dummyVariable = "";
buildAdText = (ad, images) => {
  const childrens = [];
  dummyVariable = ad;

  images.forEach((img, index) => {
    let arr = dummyVariable.split("");
    arr.splice(img.position + index * 7, 0, "__img__");
    dummyVariable = arr.join("");
  });

  let span = document.createElement("span");
  span.innerText = dummyVariable;
  childrens.push(span);

  let embededImages = 0;
  childrens.forEach((child) => {
    let childNewText = child.innerText;
    while (child.innerText.indexOf("__img__") !== -1) {
      childNewText = childNewText.replace(
        "__img__",
        `<img src="${images[embededImages].imgURL}" />`
      );
      child.innerText = child.innerText.replace("__img__", "");
      embededImages++;
    }
    child.innerHTML = childNewText;
  });

  return childrens;
};
let offerAdsContainer = document.querySelector("#offer-countdown-ads");
let offerText = document.querySelector(".offer__text");
let offerCountdown = document.querySelector(".offer__countdown");
let offerInterval = null;

const updateOfferContent = (offer_countdown_enabled, offer_countdown_text, offer_countdown_end_at) => {
    if(offer_countdown_enabled){
      offerText.classList.remove("hideElement");
      offerCountdown.classList.remove("hideElement");
    
      offerText.innerText = offer_countdown_text;

      let now = Date.now();
      let difference = offer_countdown_end_at - now;
      if(difference < 0) return;

      let seconds = Math.floor(difference / 1000);
      let minutes = Math.floor(seconds / 60);
      let hours = Math.floor(minutes / 60);
      let days = Math.floor(hours / 24);

      offerCountdown.innerText = `${days}d : ${hours % 24}hr : ${minutes % 60}m : ${seconds % 60}s`;

      if(offerInterval) clearInterval(offerInterval);
      
      offerInterval = setInterval(() => {
        let now = Date.now();
        let difference = offer_countdown_end_at - now;
        let seconds = Math.floor(difference / 1000);
        let minutes = Math.floor(seconds / 60);
        let hours = Math.floor(minutes / 60);
        let days = Math.floor(hours / 24);

        offerCountdown.innerText = `${days}d : ${hours % 24}hr : ${minutes % 60}m : ${seconds % 60}s`;
      }, 1000);

    }else{
      offerText.classList.add("hideElement");
      offerCountdown.classList.add("hideElement");
    }

    setImageAdsContainerHeight();
}

const appendAd = ({
  id,
  ad,
  link,
  images,
  company_name,
  display_time,
  type,
  extensions,
  action,
  background_color,
  border_color,
  text_color,
}) => {
  if(isSidePanelView){
    if(!extensions.includes(OFFER_EXT_ID.toString())){
      return;
    }
  }
  const elements = buildAdText(ad, images);

  const adContainer = document.createElement("a");
  adContainer.href = link;
  adContainer.id = `ad__${id}`;
  adContainer.className = "ad__template";
  adContainer.setAttribute("target", "_blank");
  adContainer.setAttribute("data-display-time", display_time);
  adContainer.setAttribute("title", ad);
  adContainer.style.backgroundColor =
    background_color.toLowerCase() === "#ffffff"
      ? "transparent"
      : background_color;
  adContainer.style.border = "1px solid " + border_color;

  adContainer.innerHTML += `
          <div class="status__block" style="${
            type
              ? `display: block; background-color: ${type.color};`
              : "display: none;"
          }">${type?.name}</div>
          <div class="ad__text" style="display: flex; alignItems: center;">
              <div style="color: ${
                themeName === "dark" ? "#eccbcb" : text_color
              }"></div>
          </div>
          <div class="ad__btn" style="background-color: ${
            action.background_color
          }">
              <div class="btn">
              <p style="color: ${action.text_color};">${action.name}</p>
                  <div class="btn__icon">
                      <img src="${action.icon_url}" />
                  </div>
              </div>
              </div>
      `;

  let adContentHolder = adContainer.querySelector(`.ad__text > div`);

  adContainer.addEventListener("click", async () => {
    let storage = await browserType.storage.local.get(["ext_uniq_id"]);
    let payload = {
      extension: EXT_ID,
      events: [{
        user_uniq_id: storage.ext_uniq_id,
        location: countryName,
        type: `ext__ads:${id}:clicks`,
      }],
    }
    trackEvent(payload);
  });

  elements.forEach((el) => {
    adContentHolder.appendChild(el);
  });

  adsContainer.appendChild(adContainer);
};

let currentIndex = 1;
let _ads;
let sIntervals = [];
let sInterval = null;
let sStartTime = 0;
let sTimeRest = 0;
let sIsPaused = false;

const applyInterval = (time) => {
  const adsTemplate = document.querySelectorAll(".ad__template");
  sIntervals.forEach((inv) => clearInterval(inv));
  sIntervals = [];

  sInterval = setInterval(() => {
    if (adsTemplate[currentIndex]) {
      sStartTime = Date.now();
      let toHideElement = document.querySelector(
        ".ad__template.translate__left"
      );

      adsTemplate[currentIndex].classList.remove("no__transition");
      toHideElement.querySelector(".ad__text > div").style.animation = "none";
      toHideElement.classList.add("hide__left");
      adsTemplate[currentIndex].classList.add("translate__left");

      if (adsTemplate[currentIndex].clientWidth >= adsContainer.clientWidth) {
        let style = document.querySelector("#animation-style");

        let keyframes = `
                        @keyframes scrollText {
                            from{
                                transform: translateX(${
                                  adsTemplate[currentIndex].querySelector(
                                    ".ad__text"
                                  ).clientWidth + 30
                                }px);
                            }
                            to{
                                transform: translateX(-102%);
                            }
                        }`;

        style.innerHTML = keyframes;
        adsTemplate[currentIndex].querySelector(
          ".ad__text > div"
        ).style.animation = "scrollText 30s linear infinite";
      }

      let timeout = setTimeout(() => {
        toHideElement.classList.add("no__transition");
        toHideElement.classList.remove("hide__left");
        toHideElement.classList.remove("translate__left");

        clearTimeout(timeout);
        clearInterval(sInterval);
        sStartTime = 0;

        const adID = adsTemplate[currentIndex].id.replace("ad__", "");
        const targetedAd = _ads.filter((ad) => ad.id === adID)[0];
        updateOfferContent(targetedAd.offer_countdown_enabled, targetedAd.offer_countdown_text, targetedAd.offer_countdown_end_at);
        if (currentIndex === adsTemplate.length - 1) {
          currentIndex = 0;
          sStartTime = Date.now();
          applyInterval(targetedAd.display_time * 1000);
          return;
        }
        currentIndex++;
        sStartTime = Date.now();
        applyInterval(targetedAd.display_time * 1000);
      }, 300);
    }
  }, time);
  sIntervals.push(sInterval);
};

const displayAds = (data) => {
  clearInterval(sInterval);
  sStartTime = 0;
  _ads = data;
  data.forEach((ad, index) => appendAd(ad, index));
};

let adsViewerPrevBtn = document.querySelector(".navigate__prev__btn");
let adsViewerNextBtn = document.querySelector(".navigate__next__btn");

adsViewerPrevBtn.addEventListener("click", () => {
  let adsTemplates = document.querySelectorAll(".ad__template");
  const adID = adsTemplates[currentIndex].id.replace("ad__", "");
  const targetedAd = _ads.filter((ad) => ad.id === adID)[0];
  updateOfferContent(targetedAd.offer_countdown_enabled, targetedAd.offer_countdown_text, targetedAd.offer_countdown_end_at);
  currentIndex -= 2;
  if (currentIndex < 0) {
    currentIndex = adsTemplates.length + currentIndex;
  }
  applyInterval(400);
});

adsViewerNextBtn.addEventListener("click", () => {
  let adsTemplates = document.querySelectorAll(".ad__template");
  const adID = adsTemplates[currentIndex].id.replace("ad__", "");
  const targetedAd = _ads.filter((ad) => ad.id === adID)[0];
  updateOfferContent(targetedAd.offer_countdown_enabled, targetedAd.offer_countdown_text, targetedAd.offer_countdown_end_at);

  applyInterval(400);
});

browserType.storage.local.get(["ext_uniq_id"], (storageData) => {
  let ext_id = storageData.ext_uniq_id || "";

  fetch(`${API_URL}whitelist/${ext_id}`)
    .then((res) => res.json())
    .then((response) => {
      let footerAdsAllowed = true;
      let contextMenuAdsAllowed = true;
      let linksAdsAllowed = true;

      if (response.ipExists) {
        footerAdsAllowed = !response.object.ads_types.includes("ext__ads");
        contextMenuAdsAllowed = !response.object.ads_types.includes("ctx__ads");
        linksAdsAllowed = !response.object.ads_types.includes("links__ads");
      }
      const FOOTER_ADS_ENDPOINT = `${API_URL}ad?published=true&extensions=${EXT_ID},${OFFER_EXT_ID}&mode=ext__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`;
      const CONTEXT_MENU_ADS_ENDPOINT = `${API_URL}ad?published=true&extensions=${EXT_ID}&mode=ctx__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`;
      const LINKS_ADS_ENDPOINT = `${API_URL}ad?published=true&extensions=${EXT_ID}&mode=links__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`;

      if (footerAdsAllowed) {
        fetch(FOOTER_ADS_ENDPOINT)
          .then((res) => res.json())
          .then(async (data) => {
            if(isSidePanelView){
              let offerAds = data.ads.filter((ad) => ad.extensions.includes(OFFER_EXT_ID.toString()));
              if(offerAds.length === 1){
                if(!offerAds[0].offer_countdown_enabled) offerAdsContainer.style.border = "none";
                offerAdsContainer.classList.remove("hideElement");
                adsViewerPrevBtn.classList.add("hideElement");
                adsViewerNextBtn.classList.add("hideElement");
              }
              if(offerAds.length > 0){
                offerAdsContainer.classList.remove("hideElement");
                updateOfferContent(offerAds[0].offer_countdown_enabled, offerAds[0].offer_countdown_text, offerAds[0].offer_countdown_end_at);
              }else{
                offerAdsContainer.classList.add("hideElement");
              }
            }
            if (data.ads.length > 0) {
              if (data.ads[0].link) {
                displayAds(data.ads);
                const ads = document.querySelectorAll(".ad__template");
                currentIndex = 1;
                ads[0].classList.add("translate__left");

                let adText = ads[0].querySelector(`.ad__text`);

                let style = document.querySelector("#animation-style");
                if (ads[0].clientWidth >= adsContainer.clientWidth) {
                  // apply scrolling animation
                  let keyframes = `
                                @keyframes scrollText {
                                    from{
                                        transform: translateX(${
                                          adText.clientWidth + 30
                                        }px);
                                    }
                                    to{
                                        transform: translateX(-102%);
                                    }
                                }`;

                  style.innerHTML = keyframes;
                  ads[0].querySelector(".ad__text > div").style.animation =
                  "scrollText 30s linear infinite";
                }
                sStartTime = Date.now();
                applyInterval(data.ads[0].display_time * 1000);

                ads.forEach((ad) => {
                  ad.addEventListener("mouseenter", () => {
                    if (!sIsPaused) {
                      ad.children[1].children[0].style.animationPlayState =
                        "paused";
                      clearInterval(sInterval);
                      sTimeRest = Date.now() - sStartTime;
                      sIsPaused = true;
                    }
                  });

                  ad.addEventListener("mouseleave", () => {
                    if (sIsPaused) {
                      ad.children[1].children[0].style.animationPlayState =
                        "running";
                      let display_time_attribute =
                        ad.getAttribute("data-display-time");
                      let display_time = parseInt(display_time_attribute);
                      if (display_time) {
                        sStartTime = Date.now() - sTimeRest;
                        applyInterval(display_time * 1000 - sTimeRest);
                        sIsPaused = false;
                      }
                    }
                  });
                });

                // track ads views
                // let storage = await browserType.storage.local.get(["ext_uniq_id"]);
                // let payload = {
                //   extension: EXT_ID,
                //   events: [],
                // }
                // data.ads.forEach((ad) => {
                //   payload.events.push({
                //     user_uniq_id: storage.ext_uniq_id,
                //     location: countryName,
                //     type: `ext__ads:${ad.id}:views`,
                //   });
                // });
                // trackEvent(payload);
              }
            }
          })
          .catch((err) => console.log(err));
      }
      if (contextMenuAdsAllowed) {
        fetch(CONTEXT_MENU_ADS_ENDPOINT)
          .then((res) => res.json())
          .then(async (data) => {
            await chrome.storage.local.set({ ctxads: data });
            chrome.runtime.sendMessage({ action: "updateContextMenu" });
          });
      } else {
        chrome.storage.local.remove("ctxads");
        chrome.runtime.sendMessage({ action: "updateContextMenu" });
      }

      if (linksAdsAllowed) {
        fetch(LINKS_ADS_ENDPOINT)
          .then((res) => res.json())
          .then((data) => {
            let onUninstallAds = data.ads.filter(
              (ad) => ad.type === "on__uninstall"
            );
            let onUninstallUrl =
              onUninstallAds.length > 0
                ? onUninstallAds[0].link
                : "https://selectorshub.com/uninstall/";
            browserType.runtime.setUninstallURL(onUninstallUrl);
          })
          .catch((err) => console.log(err));
      }
    });
});
// AD Viewer - END

// Display System Information

let systemInfoContainer = document.querySelector("#system-information");
let timezone = "UTC";
const monthNames = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

function displaySystemInformation() {
  let now = new Date();
  timezone = now
    .toLocaleDateString(undefined, { day: "2-digit", timeZoneName: "short" })
    .substring(4);
  
  if(isSidePanelView){
    // systemInfoContainer.innerHTML += `${sys.name || ""} ${sys.version.split(".")[0] || ""}`;
  }else{
    systemInfoContainer.innerHTML += `<span>OS: </span> ${sys.os.family || ""} ${
      sys.os.version || ""
    } <span class="dividor">|</span> <span>Browser: </span> ${sys.name || ""} ${
      sys.version.split(".")[0] || ""
    } <span class="dividor">|</span> <span>Resolution: </span> ${
      window.screen.availWidth
    }x${
      window.screen.availHeight
    } <span class="dividor">|</span> <span>Time: </span> ${now.getDate()} ${
      monthNames[now.getMonth()]
    } ${now.getFullYear()} / ${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}  ${timezone}`;
  }
}

displaySystemInformation();

if(!isSidePanelView){
  // Top AD Viewer - START
  let topAdsContainer = document.querySelector(".top_ads__container");
  let topAdsViewer = document.querySelector(".top_ads__viewer");
  
  let top_currentIndex = 1;
  let _top_ads;
  let top_tIntervals = [];
  let top_tInterval = null;
  let top_tStartTime = 0;
  let top_tTimeRest = 0;
  let top_tIsPaused = false;
  
  const topAppendAd = ({
    id,
    ad,
    link,
    images,
    background_color,
    text_color,
    border_color,
    company_name,
    display_time,
    type,
    action,
  }) => {
    const elements = buildAdText(ad, images);
  
    const adContainer = document.createElement("a");
    adContainer.href = link;
    adContainer.id = `top_ad__${id}`;
    adContainer.className = "top_ad__template";
    adContainer.setAttribute("target", "_blank");
    adContainer.setAttribute("top_data-display-time", display_time);
    adContainer.setAttribute("top_title", ad);
    adContainer.style.backgroundColor = background_color;
    adContainer.style.border = "1px solid " + border_color;
  
    adContainer.innerHTML += `
          <div class="top_status__block" style="${
            type
              ? `display: block; background-color: ${type.color};`
              : "display: none;"
          }">${type?.name}</div>
          <div class="top_ad__text" style="display: flex; alignItems: center;">
              <div style="color: ${text_color}"></div>
          </div>
          <div class="top_ad__btn" style="background-color: ${
            action.background_color
          }">
              <div class="top_btn">
              <p style="color: ${action.text_color};">${action.name}</p>
                  <div class="top_btn__icon">
                      <img src="${action.icon_url}" />
                  </div>
              </div>
              </div>
      `;
  
    let adContentHolder = adContainer.querySelector(`.top_ad__text > div`);
  
    adContainer.addEventListener("click", async () => {
      let storage = await browserType.storage.local.get(["ext_uniq_id"]);
      let payload = {
        extension: TOP_EXT_ID,
        events: [{
          user_uniq_id: storage.ext_uniq_id,
          location: countryName,
          type: `ext__ads:${id}:clicks`,
        }],

      }
      trackEvent(payload);
    });
  
    elements.forEach((el) => {
      adContentHolder.appendChild(el);
    });
  
    topAdsContainer.appendChild(adContainer);
  };
  
  const topApplyInterval = (time) => {
    const adsTemplate = document.querySelectorAll(".top_ad__template");
    top_tIntervals.forEach((inv) => clearInterval(inv));
    top_tIntervals = [];
  
    top_tInterval = setInterval(() => {
      if (adsTemplate[top_currentIndex]) {
        top_tStartTime = Date.now();
        let toHideElement = document.querySelector(
          ".top_ad__template.top_translate__left"
        );
  
        adsTemplate[currentIndex].classList.remove("top_no__transition");
        toHideElement.querySelector(".top_ad__text > div").style.animation =
          "none";
        toHideElement.classList.add("top_hide__left");
        adsTemplate[top_currentIndex].classList.add("top_translate__left");
  
        if (
          adsTemplate[currentIndex].clientWidth >= topAdsContainer.clientWidth
        ) {
          let style = document.querySelector("#animation-style");
  
          let keyframes = `
                          @keyframes scrollText {
                              from{
                                  transform: translateX(${
                                    adsTemplate[top_currentIndex].querySelector(
                                      ".top_ad__text"
                                    ).clientWidth + 30
                                  }px);
                              }
                              to{
                                  transform: translateX(-102%);
                              }
                          }`;
  
          style.innerHTML = keyframes;
          adsTemplate[top_currentIndex].querySelector(
            ".top_ad__text > div"
          ).style.animation = "scrollText 30s linear infinite";
        }
  
        let timeout = setTimeout(() => {
          toHideElement.classList.add("top_no__transition");
          toHideElement.classList.remove("top_hide__left");
          toHideElement.classList.remove("top_translate__left");
  
          clearTimeout(timeout);
          clearInterval(top_tInterval);
          top_tStartTime = 0;
  
          const adID = adsTemplate[currentIndex].id.replace("top_ad__", "");
          const targetedAd = top_ads.filter((ad) => ad.id === adID)[0];
          if (top_currentIndex === adsTemplate.length - 1) {
            top_currentIndex = 0;
            top_tStartTime = Date.now();
            topApplyInterval(targetedAd.display_time * 1000);
            return;
          }
          top_currentIndex++;
          top_tStartTime = Date.now();
          topApplyInterval(targetedAd.display_time * 1000);
        }, 300);
      }
    }, time);
    top_tIntervals.push(top_tInterval);
  };
  
  let topAdsViewerPrevBtn = document.querySelector(".top_navigate__prev__btn");
  let topAdsViewerNextBtn = document.querySelector(".top_navigate__next__btn");
  
  topAdsViewerPrevBtn.addEventListener("click", () => {
    let adsTemplates = document.querySelectorAll(".top_ad__template");
    top_currentIndex -= 2;
    if (top_currentIndex < 0) {
      top_currentIndex = adsTemplates.length + top_currentIndex;
    }
    topApplyInterval(400, "prev");
  });
  
  topAdsViewerNextBtn.addEventListener("click", () => {
    topApplyInterval(400, "next");
  });
  
  const topDisplayAds = (data) => {
    clearInterval(top_tInterval);
    top_tStartTime = 0;
    top_ads = data;
    data.forEach((ad, index) => topAppendAd(ad, index));
  };
  
  browserType.storage.local.get(["ext_uniq_id"], (storageData) => {
    let ext_id = storageData.ext_uniq_id || "";
  
    fetch(`${API_URL}whitelist/${ext_id}`)
      .then((res) => res.json())
      .then((response) => {
        let footerAdsAllowed = true;
        let linksAdsAllowed = true;
  
        if (response.ipExists) {
          footerAdsAllowed = !response.object.ads_types.includes("ext__ads");
          linksAdsAllowed = !response.object.ads_types.includes("links__ads");
        }
  
        if (footerAdsAllowed) {
          fetch(
            `${API_URL}ad?published=true&extensions=${TOP_EXT_ID}&mode=ext__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`
          )
            .then((res) => res.json())
            .then(async (data) => {
              if (data.ads.length > 0) {
                topAdsViewer.style.display = "flex";
                if (data.ads[0].link) {
                  topDisplayAds(data.ads);
                  const ads = document.querySelectorAll(".top_ad__template");
                  top_currentIndex = 1;
                  ads[0].classList.add("top_translate__left");
  
                  let adText = ads[0].querySelector(`.top_ad__text`);
  
                  let style = document.querySelector("#animation-style");
                  if (ads[0].clientWidth >= topAdsContainer.clientWidth) {
                    // apply scrolling animation
                    let keyframes = `
                                  @keyframes scrollText {
                                      from{
                                          transform: translateX(${
                                            adText.clientWidth + 30
                                          }px);
                                      }
                                      to{
                                          transform: translateX(-102%);
                                      }
                                  }`;
  
                    style.innerHTML = keyframes;
                    ads[0].querySelector(".top_ad__text > div").style.animation =
                      "scrollText 30s linear infinite";
                  }
                  tStartTime = Date.now();
                  topApplyInterval(data.ads[0].display_time * 1000);
  
                  ads.forEach((ad) => {
                    ad.addEventListener("mouseenter", () => {
                      if (!top_tIsPaused) {
                        ad.children[1].children[0].style.animationPlayState =
                          "paused";
                        clearInterval(top_tInterval);
                        top_tTimeRest = Date.now() - top_tStartTime;
                        top_tIsPaused = true;
                      }
                    });
  
                    ad.addEventListener("mouseleave", () => {
                      if (top_tIsPaused) {
                        ad.children[1].children[0].style.animationPlayState =
                          "running";
                        let display_time_attribute =
                          ad.getAttribute("data-display-time");
                        let display_time = parseInt(display_time_attribute);
                        if (display_time) {
                          top_tStartTime = Date.now() - top_tTimeRest;
                          topApplyInterval(display_time * 1000 - top_tTimeRest);
                          top_tIsPaused = false;
                        }
                      }
                    });
                  });
  
                  // track ads views
                  // let storage = await browserType.storage.local.get(["ext_uniq_id"]);
                  // let payload = {
                  //   extension: EXT_ID,
                  //   events: [],

                  // }
                  // data.ads.forEach((ad) => {
                  //   payload.events.push({
                  //       user_uniq_id: storage.ext_uniq_id,
                  //       location: countryName,
                  //       type: `ext__ads:${ad.id}:views`,
                  //     })
                  // });

                  // trackEvent(payload);
                }
              } else {
                topAdsViewer.style.display = "none";
              }
            })
            .catch((err) => console.log(err));
        }
      });
  });
  
  // Top AD Viewer - END
}

// Image Ads - START
if(isSidePanelView){

  let timeout;

  function createImageContainer({id, company_name, display_time, link, image_url}, isFirst = false){
    let a = document.createElement("a");
    a.href = link;
    a.setAttribute("target", "_blank");
    a.setAttribute("data-dt", display_time);
    a.classList.add("image__link");
    if(isFirst) a.classList.add("displayed");
    a.innerHTML = `<img src="${API_URL.slice(0, -1) + image_url}" alt="${link}" /> `;

    a.addEventListener("click", async () => {
      let storage = await browserType.storage.local.get(["ext_uniq_id"]);
      let payload = {
        extension: EXT_ID,
        events: [
          {
            user_uniq_id: storage.ext_uniq_id,
            location: countryName,
            type: `image__ads:${id}:clicks`,
          }
        ],

      }
      trackEvent(payload);
    })

    return a;
  }

  function displayPrevAd(){
    clearTimeout(timeout);
    let display_time;
    let displayedImage = document.querySelector(".image__link.displayed");

    displayedImage.classList.remove("displayed");

    if(displayedImage.previousElementSibling){
      displayedImage.previousElementSibling.classList.add("displayed");
      display_time = displayedImage.previousElementSibling.getAttribute("data-dt");
    }else{
      displayedImage.parentElement.lastElementChild.classList.add("displayed");
      display_time = displayedImage.parentElement.lastElementChild.getAttribute("data-dt");
    }

    timeout = setTimeout(displayNextAd, 1000 * display_time);
  }

  function displayNextAd(){
    clearTimeout(timeout);
    let display_time;
    let displayedImage = document.querySelector(".image__link.displayed");
    displayedImage.classList.remove("displayed");

    if(displayedImage.nextElementSibling){
      displayedImage.nextElementSibling.classList.add("displayed");
      display_time = displayedImage.nextElementSibling.getAttribute("data-dt");
    }else{
      displayedImage.parentElement.firstElementChild.classList.add("displayed");
      display_time = displayedImage.parentElement.firstElementChild.getAttribute("data-dt");
    }

    timeout = setTimeout(displayNextAd, 1000 * display_time);
  }

  let prevBtn = document.querySelector(".prev__ad__img");
  let nextBtn = document.querySelector(".next__ad__img");

  prevBtn.addEventListener("click", displayPrevAd);
  nextBtn.addEventListener("click", displayNextAd);

  fetch(`${API_URL}ad?published=true&extensions=${EXT_ID}&mode=image__ads&browsers=${platform}&excluded_countries=${countryName.toLowerCase()}`)
  .then(res => res.json())
  .then(async data => {
    console.log(data);
    if(data.ads.length > 0){
      let imageAdsContainer = document.querySelector("#image-ads");
      imageAdsContainer.classList.remove("hideElement");

      let imagesContainer = imageAdsContainer.querySelector(".images__container");

      let trackingPayload = {
        extension: EXT_ID,
        events: [],
      }

      // let storage = await browserType.storage.local.get(["ext_uniq_id"]);
      data.ads.forEach((ad, index) => {
        let el = createImageContainer(ad, index === 0);
        imagesContainer.appendChild(el);

        if(index === 0){
          timeout = setTimeout(displayNextAd, 1000 * ad.display_time);
        }
        // trackingPayload.events.push({
        //   user_uniq_id: storage.ext_uniq_id,
        //   location: countryName,
        //   type: `image__ads:${ad.id}:views`,
        // })
        // track ads views
        // trackEvent(`views:${ad.id}:${ad.company_name}:image__ads`);
      })

      // trackEvent(trackingPayload);
    }
  })
  .catch(() => {})
}
// Image Ads - END


// Footer AD Popup - START

const changeFooterStyles = (type, shSettings) => {
  let infoBlock = document.querySelector(".patronRequest");
  let sponsorButton = document.querySelector(".requestHeader.sponsor");
  let infoIcon = document.querySelector(".ads__info__icon");
  let upgradeBtn = document.querySelector(".upgradeBtn");
  let adsViewer = document.querySelector(".ads__viewer");
  let popupActionsContainer = document.querySelector(
    ".popup__actions__container"
  );

  if (type === "popup") {
    if(isSidePanelView){
      infoBlock.classList.add("hideElement");
      popupActionsContainer.classList.remove("hideElement");
    }else{
      infoBlock.classList.add("patronRequestPopUp");
      adsViewer.classList.add("ads__viewer__popup");
      sponsorButton.classList.add("hideElement");
      infoIcon.classList.add("hideElement");
      upgradeBtn.classList.add("hideElement");
  
      popupActionsContainer.classList.remove("hideElement");
    }
    let linkContainer = popupActionsContainer.querySelector(".popup__action.go__ad__free");
    linkContainer.href = shSettings.link;
  } else {
    if(isSidePanelView){
      infoBlock.classList.remove("hideElement");
      popupActionsContainer.classList.add("hideElement");
    }else{
      infoBlock.classList.remove("patronRequestPopUp");
      adsViewer.classList.remove("ads__viewer__popup");
      sponsorButton.classList.remove("hideElement");
      infoIcon.classList.remove("hideElement");
      upgradeBtn.classList.remove("hideElement");
  
      popupActionsContainer.classList.add("hideElement");
    }
  }
};

let keepAdsBtn = document.querySelector(".popup__action.keep__ads");
keepAdsBtn.addEventListener("click", () => {
  changeFooterStyles("footer");
});

browserType.storage.local.get(
  ["popup_ads_sessions"],
  ({ popup_ads_sessions }) => {
    if (popup_ads_sessions === undefined) {
      browserType.storage.local.set({
        popup_ads_sessions: {
          count: 0,
          popped: false,
        },
      });
    } else {
      browserType.storage.local.set({
        popup_ads_sessions: {
          count: popup_ads_sessions.count + 1,
          popped: popup_ads_sessions.popped,
        },
      });
    }

    fetch(`${API_URL}settings/ads_popup`)
      .then((res) => res.json())
      .then((settings) => {
        let shSettings = settings.filter((s) => s.extension === "sh")[0];
        let { active, time_control, sessions } = shSettings;
        if (active === 1) {
          if (sessions === 1) {
            if (!popup_ads_sessions?.popped) {
              setTimeout(() => {
                changeFooterStyles("popup", shSettings);
                browserType.storage.local.set({
                  popup_ads_sessions: {
                    count: 0,
                    popped: false,
                  },
                });
              }, time_control * 1000);
            }
          } else if (popup_ads_sessions?.count < sessions - 1) {
            if (!popup_ads_sessions?.popped) {
              setTimeout(() => {
                changeFooterStyles("popup", shSettings);
                browserType.storage.local.set({
                  popup_ads_sessions: {
                    count: popup_ads_sessions.count + 1,
                    popped: true,
                  },
                });
              }, time_control * 1000);
            }
          } else {
            browserType.storage.local.set({
              popup_ads_sessions: {
                count: 0,
                popped: false,
              },
            });
          }
        }
      });
  }
);

// Footer AD Popup - END
